# AIRFRIEND SERVICE Web V1

Next.js + Supabase frontend starter สำหรับ schema ในโฟลเดอร์ `../supabase`.

## มีแล้ว
- Supabase cookie-based Auth
- Next.js 16 `proxy.ts`
- Dashboard
- ลูกค้า: list + create
- เครื่องแอร์ลูกค้า: list
- ใบงาน: list + create
- คลังสินค้า: list
- การเงิน: summary + list
- ทีมช่าง: งานที่ได้รับ + รับงาน
- ใบงานช่าง: เปลี่ยนสถานะ

## Run
```bash
cp .env.example .env.local
npm install
npm run dev
```

ตั้งค่า:
```env
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...
```

## ก่อนทดสอบ UI
1. รัน migrations ใน `../supabase/migrations`
2. สร้าง user ใน Supabase Auth
3. สร้าง row ใน `organizations`
4. เพิ่ม user เข้า `organization_members` เป็น `owner`
5. สำหรับหน้าช่าง ให้สร้าง `employees` และใส่ employee_id ใน membership
6. สร้าง `job_assignments` เพื่อมอบหมายงานให้ช่าง

## Security
Frontend ใช้ publishable key เท่านั้น และพึ่ง RLS ที่ฐานข้อมูลเป็น security boundary.
ห้ามใส่ service_role key ใน client.


## Field workflow added
- GPS check-in from mobile browser
- Field inspection form
- Camera/photo upload to private Supabase Storage
- Job timeline
- Admin/manager technician review
- Approve → completed
- Revision → in_progress

> Browser ต้องได้รับ permission สำหรับ Location และ Camera/Photos.

## Admin job management added
- Assign multiple technicians
- Bind customer equipment to job
- Issue inventory directly to job
- Calculate material/labor/misc costs and gross profit
- Create quote/invoice/receipt starter from job
- Calendar view
- Sales documents list

## Sales & finance V1.3
- Atomic document numbering in PostgreSQL
- Quote / invoice / receipt detail page
- Partial payments
- Multiple payment channels
- Withholding / discount / increase adjustments
- Credit note / debit note starter
- Printable document route
- Private branding and generated-document storage buckets
- Logo / signature / PromptPay QR settings


## Auth onboarding V1.5
- Server-only Supabase Admin client
- Invite user by email
- Link Auth user → organization membership
- Link membership → employee or customer
- Onboarding audit log
- Membership disable action
- Migration Center UI

`SUPABASE_SECRET_KEY` ต้องอยู่ server environment เท่านั้น ห้ามใช้ `NEXT_PUBLIC_`.


## Customer Portal + UAT V1.6
Customer routes:
- `/portal`
- `/portal/jobs`
- `/portal/equipment`
- `/portal/documents`
- `/portal/warranty`
- `/portal/contracts`
- `/portal/profile`

Admin UAT:
- `/settings/uat`

Login now routes through `/auth/continue` to choose customer portal or staff dashboard.


## PWA + Notifications + Hardening V1.7
- `app/manifest.ts`
- shell-only service worker
- security headers in `next.config.ts`
- `/notifications`
- `/portal/notifications`
- hardened RLS separating management / technician / customer access
- Edge Function `dispatch-notifications`
- Cron template in migration 014
