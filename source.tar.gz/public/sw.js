const CACHE="airfriend-shell-v1";
const SHELL=["/login","/auth/continue","/icons/icon-192.png","/icons/icon-512.png"];

self.addEventListener("install",event=>{
  event.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate",event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));
  self.clients.claim();
});

self.addEventListener("fetch",event=>{
  const req=event.request;
  if(req.method!=="GET")return;
  const url=new URL(req.url);
  if(url.origin!==location.origin)return;
  // Do not cache authenticated API/data responses. Only navigation fallback/static assets.
  if(url.pathname.startsWith("/api/")||url.pathname.startsWith("/_next/"))return;
  event.respondWith(
    fetch(req).then(res=>{
      if(res.ok && (req.mode==="navigate" || url.pathname.startsWith("/icons/"))){
        const copy=res.clone(); caches.open(CACHE).then(c=>c.put(req,copy));
      }
      return res;
    }).catch(()=>caches.match(req).then(r=>r||caches.match("/login")))
  );
});
