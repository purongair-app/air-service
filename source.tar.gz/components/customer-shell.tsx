import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

const links=[
 ["/portal","หน้าหลัก"],
 ["/portal/notifications","การแจ้งเตือน"],
 ["/portal/feedback","ประเมินบริการ"],
 ["/portal/jobs","งานบริการ"],
 ["/portal/claims","แจ้งปัญหา/เคลม"],
 ["/portal/equipment","เครื่องแอร์"],
 ["/portal/documents","เอกสาร"],
 ["/portal/withholding","หัก ณ ที่จ่าย"],
 ["/portal/warranty","รับประกัน/PM"],
 ["/portal/contracts","สัญญาบริการ"],
 ["/portal/profile","ข้อมูลติดต่อ"]
];

export default async function CustomerShell({children}:{children:React.ReactNode}){
 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user)redirect("/login");
 const {data:member}=await supabase.from("organization_members")
   .select("role,status,customer_id").eq("user_id",user.id).eq("status","active").limit(1).maybeSingle();
 if(!member)redirect("/login");
 if(member.role!=="customer")redirect("/dashboard");
 if(!member.customer_id)redirect("/login");

 return <div className="shell">
  <aside className="sidebar">
    <div className="brand">AIRFRIEND</div>
    <div className="brand-sub">Customer Portal</div>
    <nav className="nav">{links.map(([href,label])=><Link href={href} key={href}>{label}</Link>)}</nav>
  </aside>
  <main className="main">
    <div className="topbar"><div/><div className="muted">{user.email}</div></div>
    {children}
  </main>
 </div>
}
