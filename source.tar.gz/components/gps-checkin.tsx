"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function GpsCheckin({jobId, organizationId}:{jobId:string; organizationId:string}) {
  const [state,setState]=useState("พร้อมเช็กอิน");

  async function run(){
    setState("กำลังขอตำแหน่ง...");
    if(!navigator.geolocation){ setState("อุปกรณ์นี้ไม่รองรับ GPS"); return; }

    navigator.geolocation.getCurrentPosition(async pos=>{
      try{
        const supabase=createClient();
        const {data:{user}}=await supabase.auth.getUser();
        const {data:member}=await supabase.from("organization_members")
          .select("employee_id").eq("organization_id",organizationId).eq("user_id",user?.id).maybeSingle();
        const {error}=await supabase.from("job_checkins").insert({
          organization_id:organizationId,
          job_id:jobId,
          latitude:Number(pos.coords.latitude.toFixed(7)),
          longitude:Number(pos.coords.longitude.toFixed(7)),
          accuracy_m:Number(pos.coords.accuracy.toFixed(2)),
          checked_in_by:user?.id,
          checked_in_employee_id:member?.employee_id || null,
          checked_in_at:new Date().toISOString()
        });
        if(error) throw error;

        await supabase.from("job_timeline").insert({
          organization_id:organizationId,
          job_id:jobId,
          status:"traveling",
          detail:`เช็กอินถึงหน้างานแล้ว · GPS ${pos.coords.latitude.toFixed(7)}, ${pos.coords.longitude.toFixed(7)} · คลาดเคลื่อนประมาณ ${Math.round(pos.coords.accuracy)} เมตร`,
          actor_user_id:user?.id,
          actor_name:user?.email || "ทีมช่าง",
          occurred_at:new Date().toISOString()
        });
        setState("เช็กอินสำเร็จ");
        window.location.reload();
      }catch(err:any){
        setState("เช็กอินไม่สำเร็จ: "+(err?.message||"unknown error"));
      }
    }, err=>setState("อ่านตำแหน่งไม่ได้: "+err.message), {
      enableHighAccuracy:true, timeout:15000, maximumAge:0
    });
  }

  return <div className="card">
    <h3>GPS Check-in</h3>
    <p className="muted">{state}</p>
    <button className="btn primary" onClick={run}>เช็กอินหน้างาน</button>
  </div>;
}
