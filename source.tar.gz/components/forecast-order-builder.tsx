"use client";
import { useMemo,useState } from "react";
import { createForecastPo } from "@/app/inventory/forecast/actions";

export default function ForecastOrderBuilder({rows,suppliers}:{rows:any[];suppliers:any[]}){
 const [supplier,setSupplier]=useState("");
 const [selected,setSelected]=useState<Record<string,boolean>>({});
 const [qty,setQty]=useState<Record<string,string>>(
  Object.fromEntries(rows.map(r=>[r.inventory_item_id,String(r.suggested_order_quantity||0)]))
 );

 const filtered=supplier?rows.filter(r=>r.supplier_id===supplier):rows;
 const payload=useMemo(()=>filtered
  .filter(r=>selected[r.inventory_item_id]&&Number(qty[r.inventory_item_id])>0)
  .map(r=>({
    inventory_item_id:r.inventory_item_id,
    quantity:Number(qty[r.inventory_item_id]),
    unit_cost:Number(r.suggested_unit_cost||r.cost||0)
  })),[filtered,selected,qty]);

 return <div className="grid">
  <form action={createForecastPo} className="card">
   <input type="hidden" name="supplier_id" value={supplier}/>
   <input type="hidden" name="items_json" value={JSON.stringify(payload)}/>
   <div className="actions">
    <label>Supplier<select value={supplier} onChange={e=>{setSupplier(e.target.value);setSelected({})}}><option value="">เลือก Supplier</option>{suppliers.map((s:any)=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
    <button className="btn primary" disabled={!supplier||!payload.length}>สร้าง Forecast Draft PO ({payload.length})</button>
   </div>
  </form>

  <div className="table-wrap"><table><thead><tr>
   <th></th><th>สินค้า</th><th>Stock</th><th>30/90/180 วัน</th><th>Season</th><th>Forecast 30d</th>
   <th>Lead</th><th>Safety</th><th>Incoming</th><th>แนะนำ</th><th>Supplier</th><th>Qty PO</th>
  </tr></thead><tbody>
   {filtered.map((r:any)=><tr key={r.inventory_item_id}>
    <td><input type="checkbox" disabled={!supplier||r.supplier_id!==supplier||Number(r.suggested_order_quantity)<=0} checked={!!selected[r.inventory_item_id]} onChange={e=>setSelected(v=>({...v,[r.inventory_item_id]:e.target.checked}))}/></td>
    <td><b>{r.sku}</b><br/>{r.name}{r.reorder_now&&<div className="badge">ควรสั่ง</div>}</td>
    <td>{r.on_hand}</td>
    <td>{r.used_30d} / {r.used_90d} / {r.used_180d}</td>
    <td>×{Number(r.seasonal_factor||1).toFixed(2)}</td>
    <td>{Number(r.forecast_30d||0).toFixed(2)}</td>
    <td>{r.lead_time_days}d</td>
    <td>{Number(r.safety_stock||0).toFixed(2)}</td>
    <td>{Number(r.committed_incoming||0)+Number(r.draft_incoming||0)}</td>
    <td><b>{r.suggested_order_quantity}</b><div className="muted">≈ {Number(r.suggested_order_value||0).toLocaleString()} ฿</div></td>
    <td>{r.supplier_name||"ยังไม่มี Supplier"}</td>
    <td><input style={{width:100}} type="number" step="0.001" min="0" value={qty[r.inventory_item_id]||"0"} onChange={e=>setQty(v=>({...v,[r.inventory_item_id]:e.target.value}))}/></td>
   </tr>)}
  </tbody></table>{!filtered.length&&<div className="empty">{supplier?"ไม่มีรายการ Forecast สำหรับ Supplier นี้":"เลือก Supplier เพื่อสร้าง Draft PO จาก Forecast"}</div>}</div>
 </div>
}
