"use client";
import { useMemo,useState } from "react";
import { receiveReplacement } from "@/app/procurement/rma/[id]/actions";

export default function RmaReplacementForm({rmaId,items,bins}:{rmaId:string;items:any[];bins:any[]}){
 const [qty,setQty]=useState<Record<string,string>>(Object.fromEntries(items.map(x=>[x.id,String(Math.max(0,Number(x.quantity_shipped)-Number(x.quantity_replacement_received)))])));
 const [bin,setBin]=useState<Record<string,string>>(Object.fromEntries(items.map(x=>[x.id,x.source_bin_id])));
 const payload=useMemo(()=>items.map(x=>({
   rma_item_id:x.id,
   quantity:Number(qty[x.id]||0),
   target_bin_id:bin[x.id]||x.source_bin_id
 })).filter(x=>x.quantity>0),[items,qty,bin]);

 return <form action={receiveReplacement} className="grid">
  <input type="hidden" name="rma_id" value={rmaId}/><input type="hidden" name="items_json" value={JSON.stringify(payload)}/>
  <div className="table-wrap"><table><thead><tr><th>สินค้า</th><th>ส่งเคลม</th><th>รับทดแทนแล้ว</th><th>รับครั้งนี้</th><th>เข้าที่ Bin</th></tr></thead><tbody>
   {items.map(x=><tr key={x.id}><td>{x.inventory_items?.sku} · {x.inventory_items?.name}</td><td>{x.quantity_shipped}</td><td>{x.quantity_replacement_received}</td><td><input style={{width:100}} type="number" min="0" max={Math.max(0,Number(x.quantity_shipped)-Number(x.quantity_replacement_received))} step="0.001" value={qty[x.id]||"0"} onChange={e=>setQty(v=>({...v,[x.id]:e.target.value}))}/></td><td><select value={bin[x.id]||""} onChange={e=>setBin(v=>({...v,[x.id]:e.target.value}))}>{bins.map(b=><option key={b.id} value={b.id}>{b.warehouses?.code}/{b.code}</option>)}</select></td></tr>)}
  </tbody></table></div>
  <label>หมายเหตุ<input name="note"/></label><button className="btn primary" disabled={!payload.length}>รับสินค้าทดแทน</button>
 </form>
}
