"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function WarehouseScanOps({organizationId,bins,jobs}:{organizationId:string;bins:any[];jobs:any[]}){
 const [code,setCode]=useState("");
 const [item,setItem]=useState<any>(null);
 const [msg,setMsg]=useState("");
 const [mode,setMode]=useState("putaway");
 const supabase=createClient();

 async function lookup(){
  const {data,error}=await supabase.rpc("lookup_inventory_by_scan",{p_org:organizationId,p_code:code.trim()});
  if(error){setMsg(error.message);setItem(null);return;}
  const x=Array.isArray(data)?data[0]:data;setItem(x||null);setMsg(x?"พบสินค้า":"ไม่พบสินค้า");
 }

 async function submit(fd:FormData){
  if(!item)return;
  setMsg("กำลังบันทึก...");
  const qty=Number(fd.get("quantity")||0);
  let error:any=null;
  if(mode==="putaway"){
   ({error}=await supabase.rpc("putaway_inventory",{
    p_org:organizationId,p_item:item.id,p_bin:String(fd.get("to_bin")||""),
    p_quantity:qty,p_reference:String(fd.get("reference")||""),p_note:String(fd.get("note")||"")
   }));
  }else if(mode==="issue"){
   ({error}=await supabase.rpc("issue_inventory_from_bin",{
    p_org:organizationId,p_item:item.id,p_bin:String(fd.get("from_bin")||""),
    p_quantity:qty,p_job:String(fd.get("job_id")||"")||null,
    p_reference:String(fd.get("reference")||""),p_note:String(fd.get("note")||"")
   }));
  }else{
   ({error}=await supabase.rpc("transfer_inventory_bin",{
    p_org:organizationId,p_item:item.id,p_from_bin:String(fd.get("from_bin")||""),
    p_to_bin:String(fd.get("to_bin")||""),p_quantity:qty,p_note:String(fd.get("note")||"")
   }));
  }
  if(error){setMsg(error.message);return;}
  setMsg("บันทึกสำเร็จ");await lookup();
 }

 return <div className="grid">
  <section className="card">
   <div className="form-grid">
    <label>Barcode / QR / SKU<input value={code} onChange={e=>setCode(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"){e.preventDefault();lookup()}}}/></label>
    <div><button type="button" className="btn primary" onClick={lookup}>ค้นหา</button></div>
    <label>งาน<select value={mode} onChange={e=>setMode(e.target.value)}><option value="putaway">รับเข้าชั้น / Put-away</option><option value="issue">เบิกออก</option><option value="transfer">ย้าย Bin</option></select></label>
   </div>
   {msg&&<p className="muted">{msg}</p>}
   {item&&<div><h2>{item.sku} · {item.name}</h2><p>Stock รวม {item.quantity} {item.unit||""}</p></div>}
  </section>
  {item&&<form action={submit} className="card form-grid">
    {(mode==="issue"||mode==="transfer")&&<label>จาก Bin<select name="from_bin" required>{bins.map((b:any)=><option key={b.id} value={b.id}>{b.warehouses?.code}/{b.code}</option>)}</select></label>}
    {(mode==="putaway"||mode==="transfer")&&<label>ไป Bin<select name="to_bin" required>{bins.map((b:any)=><option key={b.id} value={b.id}>{b.warehouses?.code}/{b.code}</option>)}</select></label>}
    {mode==="issue"&&<label>Job<select name="job_id"><option value="">ไม่ผูก Job (Management เท่านั้น)</option>{jobs.map((j:any)=><option key={j.id} value={j.id}>{j.work_no} · {j.customer_name_snapshot}</option>)}</select></label>}
    <label>จำนวน<input name="quantity" type="number" step="0.001" min="0.001" required/></label>
    <label>อ้างอิง<input name="reference"/></label><label>หมายเหตุ<input name="note"/></label>
    <div><button className="btn primary">{mode==="putaway"?"รับเข้าชั้น":mode==="issue"?"เบิกออก":"ย้ายตำแหน่ง"}</button></div>
  </form>}
 </div>
}
