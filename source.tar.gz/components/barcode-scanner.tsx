"use client";
import { useEffect,useRef,useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function BarcodeScanner({organizationId}:{organizationId:string}){
 const videoRef=useRef<HTMLVideoElement|null>(null);
 const [code,setCode]=useState("");
 const [result,setResult]=useState<any>(null);
 const [msg,setMsg]=useState("");
 const [running,setRunning]=useState(false);
 const streamRef=useRef<MediaStream|null>(null);

 async function lookup(value:string){
  const v=value.trim(); if(!v)return;
  const supabase=createClient();
  const {data,error}=await supabase.rpc("lookup_inventory_by_scan",{p_org:organizationId,p_code:v});
  if(error){setMsg(error.message);setResult(null);return;}
  const row=Array.isArray(data)?data[0]:data;
  setResult(row||null); setMsg(row?"พบสินค้า":"ไม่พบรหัสนี้");
 }

 async function start(){
  setMsg("");
  if(!("BarcodeDetector" in window)){
   setMsg("เบราว์เซอร์นี้ยังไม่รองรับ BarcodeDetector — ใช้ช่องกรอกรหัสด้านล่างได้");
   return;
  }
  try{
   const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"}},audio:false});
   streamRef.current=stream;
   if(videoRef.current){videoRef.current.srcObject=stream;await videoRef.current.play();}
   setRunning(true);
   const Detector=(window as any).BarcodeDetector;
   const detector=new Detector({formats:["qr_code","code_128","ean_13","ean_8","upc_a","upc_e"]});
   const loop=async()=>{
    if(!videoRef.current||!streamRef.current)return;
    try{
     const codes=await detector.detect(videoRef.current);
     if(codes?.[0]?.rawValue){
      const v=codes[0].rawValue; setCode(v); await lookup(v); stop(); return;
     }
    }catch{}
    requestAnimationFrame(loop);
   };
   requestAnimationFrame(loop);
  }catch(e:any){setMsg(e?.message||"เปิดกล้องไม่ได้");}
 }

 function stop(){
  streamRef.current?.getTracks().forEach(t=>t.stop());
  streamRef.current=null;setRunning(false);
 }

 useEffect(()=>()=>stop(),[]);

 return <div className="grid">
  <section className="card">
   <video ref={videoRef} playsInline style={{width:"100%",maxWidth:480,borderRadius:12,background:"#111"}}/>
   <div className="actions" style={{marginTop:10}}>
    {!running?<button type="button" className="btn primary" onClick={start}>เปิดกล้องสแกน</button>:<button type="button" className="btn light" onClick={stop}>หยุดกล้อง</button>}
   </div>
  </section>
  <section className="card">
   <label>Barcode / QR / SKU<input value={code} onChange={e=>setCode(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"){e.preventDefault();lookup(code)}}}/></label>
   <button type="button" className="btn primary" onClick={()=>lookup(code)}>ค้นหา</button>
   {msg&&<p className="muted">{msg}</p>}
   {result&&<div style={{marginTop:14}}>
    <h2>{result.name}</h2><div className="badge">{result.sku}</div>
    <p>คงเหลือ <b>{result.quantity}</b> {result.unit||""}</p>
    <p>Min Stock {result.reorder_point} · Cost {Number(result.cost||0).toLocaleString()} · Price {Number(result.price||0).toLocaleString()}</p>
   </div>}
  </section>
 </div>
}
