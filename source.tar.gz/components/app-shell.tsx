import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

const common=[
  ["/dashboard","แดชบอร์ด"],
  ["/control-tower","Control Tower"],
  ["/notifications","การแจ้งเตือน"],
  ["/jobs","ใบงานบริการ"],
  ["/claims","Warranty Claims"],
  ["/calendar","ปฏิทินงาน"],
  ["/customers","ลูกค้า"],
  ["/equipment","เครื่องแอร์ลูกค้า"]
];

const management=[
  ["/inventory","คลังสินค้า"],
  ["/inventory/analytics","Inventory Analytics"],
  ["/inventory/forecast","Demand Forecast"],
  ["/inventory/cycle-count","ABC Cycle Count"],
  ["/inventory/stocktake","Stocktake / Cycle Count"],
  ["/inventory/locations","Warehouse/Bin"],
  ["/inventory/warehouse-scan","Warehouse Scan"],
  ["/inventory/labels","พิมพ์ Barcode/QR"],
  ["/inventory/bin-labels","พิมพ์ Bin Labels"],
  ["/inventory/scan","สแกน Barcode/QR"],
  ["/inventory/reorder","แนะนำสั่งซื้อ"],
  ["/suppliers","ผู้ขาย"],
  ["/procurement","จัดซื้อ / PO"],
  ["/procurement/performance","Supplier Performance"],
  ["/procurement/rma","Supplier RMA"],
  ["/procurement/requests","ขอซื้อ / PR"],
  ["/procurement/returns","คืนสินค้า Supplier"],
  ["/payables","เจ้าหนี้ / A/P"],
  ["/assets","ทรัพย์สิน/เครื่องมือ"],
  ["/finance","การเงิน"],
  ["/finance/recurring","ค่าใช้จ่ายประจำ"],
  ["/collections","ลูกหนี้/ติดตามชำระ"],
  ["/collections/messages","ข้อความติดตามชำระ"],
  ["/withholding","หัก ณ ที่จ่าย"],
  ["/payroll","เงินเดือน/ค่าแรง"],
  ["/sales","เอกสารขาย"],
  ["/contracts","สัญญา/PM"],
  ["/followups","ติดตามลูกค้า"],
  ["/reports","รายงานผู้บริหาร"],
  ["/reviews","ตรวจรับงานช่าง"],
  ["/service-quality","Service Quality"],
  ["/settings/documents","ตั้งค่าเอกสาร"],
  ["/settings/users","ผู้ใช้งาน/สิทธิ์"],
  ["/settings/migration","Migration Center"],
  ["/settings/uat","UAT / Security"],
  ["/settings/readiness","Production Readiness"],
  ["/settings/service-control","SLA / Alert Settings"],
  ["/settings/warranty-eligibility","Warranty Eligibility"]
];

export default async function AppShell({children}:{children:React.ReactNode}) {
  const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser();
  if(!user)redirect("/login");

  const {data:member}=await supabase.from("organization_members")
    .select("role,status").eq("user_id",user.id).eq("status","active").limit(1).maybeSingle();

  if(!member)redirect("/login");
  if(member.role==="customer")redirect("/portal");

  const links=member.role==="technician"
    ? [["/dashboard","แดชบอร์ด"],
  ["/control-tower","Control Tower"],["/notifications","การแจ้งเตือน"],["/technician","งานของฉัน"],["/calendar","ปฏิทินงาน"]]
    : common.concat(management);

  return <div className="shell">
    <aside className="sidebar">
      <div className="brand">AIRFRIEND SERVICE</div>
      <div className="brand-sub">ระบบบริหารธุรกิจแอร์ · {member.role}</div>
      <nav className="nav">
        {links.map(([href,label])=><Link key={href} href={href}>{label}</Link>)}
      </nav>
    </aside>
    <main className="main">
      <div className="topbar">
        <div />
        <div className="muted">{user.email}</div>
      </div>
      {children}
    </main>
  </div>
}
