"use client";
import { useMemo,useState } from "react";
import { createRma } from "@/app/procurement/rma/actions";

export default function RmaCreateForm({receipts,bills,jobs,bins,warrantyClaimId=""}:{receipts:any[];bills:any[];jobs:any[];bins:any[];warrantyClaimId?:string}){
 const [receiptId,setReceiptId]=useState("");
 const [selected,setSelected]=useState<Record<string,boolean>>({});
 const [qty,setQty]=useState<Record<string,string>>({});
 const [bin,setBin]=useState<Record<string,string>>({});
 const [fault,setFault]=useState<Record<string,string>>({});

 const receipt=receipts.find(r=>r.id===receiptId);
 const items=receipt?.goods_receipt_items||[];
 const payload=useMemo(()=>items.filter((x:any)=>selected[x.id]).map((x:any)=>({
   goods_receipt_item_id:x.id,
   quantity:Number(qty[x.id]||0),
   source_bin_id:bin[x.id]||"",
   fault_category:"quality",
   fault_description:fault[x.id]||""
 })).filter((x:any)=>x.quantity>0&&x.source_bin_id),[items,selected,qty,bin,fault]);

 const supplierBills=receiptId?bills.filter(b=>b.supplier_id===receipt?.supplier_id):[];

 return <form action={createRma} className="grid">
  <input type="hidden" name="items_json" value={JSON.stringify(payload)}/><input type="hidden" name="warranty_claim_id" value={warrantyClaimId}/>
  <section className="card"><div className="form-grid">
   <label>Goods Receipt<select name="goods_receipt_id" required value={receiptId} onChange={e=>{setReceiptId(e.target.value);setSelected({})}}><option value="">เลือก GRN</option>{receipts.map(r=><option key={r.id} value={r.id}>{r.goods_receipt_no} · {r.suppliers?.name} · {r.receipt_date}</option>)}</select></label>
   <label>A/P Bill<select name="supplier_bill_id"><option value="">ไม่ผูก Bill</option>{supplierBills.map(b=><option key={b.id} value={b.id}>{b.bill_no} · {Number(b.total||0).toLocaleString()}</option>)}</select></label>
   <label>Job ที่พบปัญหา<select name="job_id"><option value="">ไม่ผูก Job</option>{jobs.map(j=><option key={j.id} value={j.id}>{j.work_no} · {j.customer_name_snapshot}</option>)}</select></label>
   <label>ต้องการแก้ไข<select name="resolution_type"><option value="replacement">เปลี่ยนสินค้า</option><option value="credit">Credit Note</option><option value="repair">ซ่อม</option><option value="inspection">ตรวจสอบก่อน</option></select></label>
   <label style={{gridColumn:"1/-1"}}>เหตุผล<textarea name="reason" required/></label>
  </div></section>

  {receipt&&<section className="card"><h3>เลือกสินค้าที่เคลม</h3>
   <div className="table-wrap"><table><thead><tr><th></th><th>สินค้า</th><th>รับ</th><th>ต้นทุน</th><th>จำนวนเคลม</th><th>Bin ต้นทาง</th><th>อาการ/ปัญหา</th></tr></thead><tbody>
    {items.map((x:any)=><tr key={x.id}><td><input type="checkbox" checked={!!selected[x.id]} onChange={e=>setSelected(v=>({...v,[x.id]:e.target.checked}))}/></td><td>{x.inventory_items?.sku} · {x.inventory_items?.name}</td><td>{x.quantity}</td><td>{Number(x.unit_cost||0).toLocaleString()}</td><td><input style={{width:100}} type="number" min="0" max={x.quantity} step="0.001" value={qty[x.id]||""} onChange={e=>setQty(v=>({...v,[x.id]:e.target.value}))}/></td><td><select value={bin[x.id]||""} onChange={e=>setBin(v=>({...v,[x.id]:e.target.value}))}><option value="">เลือก Bin</option>{bins.map(b=><option key={b.id} value={b.id}>{b.warehouses?.code}/{b.code}</option>)}</select></td><td><input value={fault[x.id]||""} onChange={e=>setFault(v=>({...v,[x.id]:e.target.value}))}/></td></tr>)}
   </tbody></table></div>
   <button className="btn primary" disabled={!payload.length}>สร้าง Supplier RMA</button>
  </section>}
 </form>
}
