"use client";
import { useState } from "react";
import { createPurchaseReturn } from "@/app/procurement/[id]/return-actions";

export default function PurchaseReturnForm({poId,items}:{poId:string;items:any[]}){
 const [v,setV]=useState<Record<string,{quantity:string;reason:string}>>(
  Object.fromEntries(items.map((x:any)=>[x.purchase_order_item_id,{quantity:"0",reason:""}]))
 );
 const payload=items.map((x:any)=>({
  purchase_order_item_id:x.purchase_order_item_id,
  quantity:Number(v[x.purchase_order_item_id]?.quantity||0),
  unit_cost:Number(x.unit_cost||0),
  reason:v[x.purchase_order_item_id]?.reason||""
 })).filter((x:any)=>x.quantity>0);
 return <form action={createPurchaseReturn} className="grid">
  <input type="hidden" name="po_id" value={poId}/>
  <input type="hidden" name="items_json" value={JSON.stringify(payload)}/>
  <div className="form-grid">
   <label>วันที่คืน<input type="date" name="return_date" required/></label>
   <label>เลขอ้างอิง Supplier<input name="supplier_return_reference"/></label>
   <label>เหตุผลรวม<input name="reason" placeholder="ชำรุด / ส่งผิด / เกิน"/></label>
  </div>
  <div className="table-wrap"><table><thead><tr><th>สินค้า</th><th>รับแล้ว</th><th>คืนได้</th><th>คืนครั้งนี้</th><th>เหตุผล</th></tr></thead><tbody>
   {items.map((x:any)=><tr key={x.purchase_order_item_id}><td>{x.description}</td><td>{x.received_quantity}</td><td>{x.returnable_quantity}</td><td><input style={{width:110}} type="number" min="0" max={x.returnable_quantity} step="0.001" value={v[x.purchase_order_item_id]?.quantity||"0"} onChange={e=>setV(s=>({...s,[x.purchase_order_item_id]:{...s[x.purchase_order_item_id],quantity:e.target.value}}))}/></td><td><input value={v[x.purchase_order_item_id]?.reason||""} onChange={e=>setV(s=>({...s,[x.purchase_order_item_id]:{...s[x.purchase_order_item_id],reason:e.target.value}}))}/></td></tr>)}
  </tbody></table></div>
  <label>หมายเหตุ<textarea name="note"/></label>
  <div><button className="btn primary" disabled={!payload.length}>ยืนยันคืน Supplier</button></div>
 </form>
}
