"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { saveCount } from "@/app/inventory/stocktake/[id]/actions";

export default function StocktakeCounter({organizationId,stocktakeId}:{organizationId:string;stocktakeId:string}){
 const [code,setCode]=useState("");
 const [item,setItem]=useState<any>(null);
 const [msg,setMsg]=useState("");

 async function lookup(){
  const supabase=createClient();
  const {data,error}=await supabase.rpc("lookup_inventory_by_scan",{p_org:organizationId,p_code:code.trim()});
  if(error){setMsg(error.message);setItem(null);return;}
  const x=Array.isArray(data)?data[0]:data;
  setItem(x||null);setMsg(x?"พบสินค้า — กรอกยอดที่นับจริง":"ไม่พบรหัสนี้");
 }

 return <section className="card">
  <h3>สแกน / เพิ่มสินค้าที่พบ</h3>
  <div className="form-grid">
   <label>Barcode / QR / SKU<input value={code} onChange={e=>setCode(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"){e.preventDefault();lookup()}}}/></label>
   <div><button type="button" className="btn light" onClick={lookup}>ค้นหา</button></div>
  </div>
  {msg&&<p className="muted">{msg}</p>}
  {item&&<form action={saveCount} className="form-grid">
    <input type="hidden" name="stocktake_id" value={stocktakeId}/><input type="hidden" name="item_id" value={item.id}/>
    <div><b>{item.sku} · {item.name}</b></div>
    <label>ยอดนับจริง<input type="number" step="0.001" min="0" name="counted_quantity" required autoFocus/></label>
    <label>หมายเหตุ<input name="note"/></label><div><button className="btn primary">บันทึกยอดนับ</button></div>
  </form>}
 </section>
}
