"use client";
import { useState } from "react";
import { receivePo } from "@/app/procurement/[id]/actions";

export default function PoReceiveForm({poId,items}:{poId:string;items:any[]}){
 const [v,setV]=useState<Record<string,{quantity:string;unit_cost:string}>>(
  Object.fromEntries(items.map((x:any)=>[x.id,{quantity:String(Math.max(0,Number(x.quantity)-Number(x.received_quantity))),unit_cost:String(x.unit_cost||0)}]))
 );
 const payload=items.map((x:any)=>({
  purchase_order_item_id:x.id,
  quantity:Number(v[x.id]?.quantity||0),
  unit_cost:Number(v[x.id]?.unit_cost||0)
 })).filter((x:any)=>x.quantity>0);

 return <form action={receivePo} className="grid">
  <input type="hidden" name="po_id" value={poId}/>
  <input type="hidden" name="items_json" value={JSON.stringify(payload)}/>
  <div className="form-grid"><label>วันที่รับ<input type="date" name="receipt_date" required/></label><label>เลขส่งของ Supplier<input name="supplier_delivery_no"/></label></div>
  <div className="table-wrap"><table><thead><tr><th>รายการ</th><th>สั่ง</th><th>รับแล้ว</th><th>รับครั้งนี้</th><th>ต้นทุน/หน่วย</th></tr></thead><tbody>
   {items.map((x:any)=><tr key={x.id}><td>{x.description}</td><td>{x.quantity}</td><td>{x.received_quantity}</td><td><input style={{width:110}} type="number" step="0.001" min="0" max={Math.max(0,Number(x.quantity)-Number(x.received_quantity))} value={v[x.id]?.quantity||""} onChange={e=>setV(s=>({...s,[x.id]:{...s[x.id],quantity:e.target.value}}))}/></td><td><input style={{width:120}} type="number" step="0.01" min="0" value={v[x.id]?.unit_cost||""} onChange={e=>setV(s=>({...s,[x.id]:{...s[x.id],unit_cost:e.target.value}}))}/></td></tr>)}
  </tbody></table></div>
  <label>หมายเหตุ<textarea name="note"/></label>
  <div><button className="btn primary" disabled={!payload.length}>รับสินค้าเข้าสต็อก</button></div>
 </form>
}
