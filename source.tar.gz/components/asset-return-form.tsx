"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Item={assetId:string;assetNo?:string;assetName?:string};

export default function AssetReturnForm({issueId,items}:{issueId:string;items:Item[]}){
 const [values,setValues]=useState<Record<string,{condition:string;note:string}>>(
   Object.fromEntries(items.map(i=>[i.assetId,{condition:"ปกติ",note:""}]))
 );
 const [msg,setMsg]=useState("");

 async function submit(){
  const supabase=createClient();
  const payload=items.map(i=>({
    asset_id:i.assetId,
    condition:values[i.assetId]?.condition||"ปกติ",
    note:values[i.assetId]?.note||""
  }));
  setMsg("กำลังบันทึก...");
  const {error}=await supabase.rpc("return_asset_issue",{p_issue:issueId,p_items:payload});
  if(error){setMsg(error.message);return;}
  setMsg("คืนอุปกรณ์เรียบร้อย");
  window.location.reload();
 }

 return <div className="form">
  {items.map(i=><div className="form-grid" key={i.assetId}>
    <div><b>{i.assetNo||"-"} · {i.assetName||"-"}</b></div>
    <label>สภาพ<select value={values[i.assetId]?.condition||"ปกติ"} onChange={e=>setValues(v=>({...v,[i.assetId]:{...v[i.assetId],condition:e.target.value}}))}>
      <option>ปกติ</option><option>ชำรุด</option><option>เสีย</option><option>สูญหาย</option><option>ระงับใช้</option>
    </select></label>
    <label>หมายเหตุ<input value={values[i.assetId]?.note||""} onChange={e=>setValues(v=>({...v,[i.assetId]:{...v[i.assetId],note:e.target.value}}))}/></label>
  </div>)}
  <button type="button" className="btn primary" onClick={submit}>ยืนยันคืนทั้งหมด</button>
  {msg&&<div className="muted">{msg}</div>}
 </div>
}
