"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function BrandingUpload({organizationId,kind,label}:{organizationId:string;kind:"logo"|"signature"|"qr";label:string}){
 const [msg,setMsg]=useState("");
 async function change(e:React.ChangeEvent<HTMLInputElement>){
  const file=e.target.files?.[0]; if(!file)return;
  const supabase=createClient(); const ext=file.name.split(".").pop()||"png";
  const path=`${organizationId}/${kind}.${ext}`;
  setMsg("กำลังอัปโหลด...");
  const {error}=await supabase.storage.from("document-branding").upload(path,file,{upsert:true});
  if(error){setMsg(error.message);return;}
  const field:any={logo:"logo_path",signature:"signature_path",qr:"payment_qr_path"};
  const {error:db}=await supabase.from("document_branding").upsert({organization_id:organizationId,[field[kind]]:path},{onConflict:"organization_id"});
  setMsg(db?db.message:"บันทึกแล้ว");
 }
 return <label>{label}<input type="file" accept="image/*" onChange={change}/><small className="muted">{msg}</small></label>
}
