"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function PayrollProofUpload({organizationId,payrollId}:{organizationId:string;payrollId:string}){
 const [msg,setMsg]=useState("");
 async function upload(e:React.ChangeEvent<HTMLInputElement>){
  const file=e.target.files?.[0]; if(!file)return;
  const supabase=createClient();
  const ext=file.name.split(".").pop()||"jpg";
  const path=`${organizationId}/payroll/${payrollId}/proof-${Date.now()}.${ext}`;
  setMsg("กำลังอัปโหลด...");
  const {error}=await supabase.storage.from("business-documents").upload(path,file,{upsert:false});
  if(error){setMsg(error.message);return;}
  const {error:db}=await supabase.from("payroll_records").update({payment_proof_path:path}).eq("id",payrollId);
  setMsg(db?db.message:"บันทึกหลักฐานแล้ว");
 }
 return <label>หลักฐาน<input type="file" accept="image/*,application/pdf" onChange={upload}/><small className="muted">{msg}</small></label>
}
