"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

const categories=[
  ["before_install","ก่อนเริ่มงาน"],
  ["clean_indoor_before","คอยล์เย็นก่อนล้าง"],
  ["clean_indoor_after","คอยล์เย็นหลังล้าง"],
  ["repair_point_before","จุดชำรุดก่อนซ่อม"],
  ["repair_point_after","จุดซ่อมหลังดำเนินการ"],
  ["customer_check","ตรวจงานร่วมกับลูกค้า"],
  ["clean_work_area","พื้นที่หลังเก็บงาน"]
];

export default function JobPhotoUpload({jobId,organizationId}:{jobId:string;organizationId:string}){
 const [category,setCategory]=useState(categories[0][0]);
 const [file,setFile]=useState<File|null>(null);
 const [state,setState]=useState("");

 async function upload(){
  if(!file){setState("กรุณาเลือกรูป");return;}
  setState("กำลังอัปโหลด...");
  const supabase=createClient();
  const {data:{user}}=await supabase.auth.getUser();
  const ext=(file.name.split(".").pop()||"jpg").toLowerCase();
  const path=`${organizationId}/${jobId}/${category}-${Date.now()}.${ext}`;
  const {error:storageError}=await supabase.storage.from("job-photos").upload(path,file,{upsert:false});
  if(storageError){setState(storageError.message);return;}
  const label=categories.find(x=>x[0]===category)?.[1]||category;
  const {error}=await supabase.from("job_photos").insert({
    organization_id:organizationId,job_id:jobId,category,label,
    storage_path:path,mime_type:file.type,note:"",
    uploaded_by:user?.id,uploaded_at:new Date().toISOString()
  });
  if(error){setState(error.message);return;}
  await supabase.from("job_timeline").insert({
    organization_id:organizationId,job_id:jobId,
    detail:`อัปโหลดรูปหน้างาน: ${label}`,
    actor_user_id:user?.id,actor_name:user?.email||"ทีมช่าง",
    occurred_at:new Date().toISOString()
  });
  setState("อัปโหลดสำเร็จ");
  setFile(null);
  window.location.reload();
 }
 return <div className="card">
   <h3>รูปหน้างาน</h3>
   <div className="form">
    <label>ประเภทรูป<select value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label>
    <label>เลือกรูป<input type="file" accept="image/*" capture="environment" onChange={e=>setFile(e.target.files?.[0]||null)}/></label>
    <button type="button" className="btn primary" onClick={upload}>อัปโหลดรูป</button>
    {state&&<div className="muted">{state}</div>}
   </div>
 </div>
}
