"use client";
import { useMemo,useState } from "react";
import { createReorderPo } from "@/app/inventory/reorder/actions";

export default function ReorderBuilder({rows,suppliers}:{rows:any[];suppliers:any[]}){
 const [supplier,setSupplier]=useState("");
 const [selected,setSelected]=useState<Record<string,boolean>>({});
 const [qty,setQty]=useState<Record<string,string>>(Object.fromEntries(rows.map(r=>[r.inventory_item_id,String(r.suggested_order_quantity||0)])));
 const filtered=supplier?rows.filter(r=>r.suggested_supplier_id===supplier):rows;
 const payload=useMemo(()=>filtered.filter(r=>selected[r.inventory_item_id]&&Number(qty[r.inventory_item_id])>0).map(r=>({
   inventory_item_id:r.inventory_item_id,
   quantity:Number(qty[r.inventory_item_id]),
   unit_cost:Number(r.suggested_unit_cost||r.cost||0)
 })),[filtered,selected,qty]);

 return <form action={createReorderPo} className="grid">
  <input type="hidden" name="supplier_id" value={supplier}/>
  <input type="hidden" name="items_json" value={JSON.stringify(payload)}/>
  <section className="card"><div className="form-grid">
   <label>Supplier<select value={supplier} onChange={e=>{setSupplier(e.target.value);setSelected({})}}><option value="">เลือก Supplier</option>{suppliers.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
   <div><button className="btn primary" disabled={!supplier||!payload.length}>สร้าง Draft PO ({payload.length} รายการ)</button></div>
  </div></section>
  <div className="table-wrap"><table><thead><tr><th></th><th>SKU / สินค้า</th><th>คงเหลือ</th><th>Min</th><th>ใช้ 90 วัน</th><th>เฉลี่ย/เดือน</th><th>แนะนำ</th><th>Supplier ล่าสุด</th><th>จำนวนสั่ง</th></tr></thead><tbody>
   {filtered.map(r=><tr key={r.inventory_item_id}><td><input type="checkbox" checked={!!selected[r.inventory_item_id]} disabled={!supplier||r.suggested_supplier_id!==supplier} onChange={e=>setSelected(v=>({...v,[r.inventory_item_id]:e.target.checked}))}/></td><td><b>{r.sku}</b><br/>{r.name}</td><td>{r.on_hand}</td><td>{r.reorder_point}</td><td>{r.used_90d}</td><td>{r.avg_monthly_usage}</td><td><b>{r.suggested_order_quantity}</b></td><td>{r.suggested_supplier_name||"ยังไม่มีประวัติ"}</td><td><input style={{width:100}} type="number" min="0" step="0.001" value={qty[r.inventory_item_id]||"0"} onChange={e=>setQty(v=>({...v,[r.inventory_item_id]:e.target.value}))}/></td></tr>)}
  </tbody></table>{!filtered.length&&<div className="empty">{supplier?"ไม่มีสินค้าแนะนำสำหรับ Supplier นี้":"เลือก Supplier เพื่อสร้าง Draft PO จากรายการแนะนำ"}</div>}</div>
 </form>
}
