import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir:"./tests/e2e",
  timeout:30000,
  use:{
    baseURL:process.env.E2E_BASE_URL || "http://127.0.0.1:3000",
    trace:"retain-on-failure",
    screenshot:"only-on-failure"
  },
  projects:[
    {name:"chromium",use:{...devices["Desktop Chrome"]}},
    {name:"mobile-chrome",use:{...devices["Pixel 7"]}}
  ],
  webServer:{
    command:"npm run dev",
    url:"http://127.0.0.1:3000",
    reuseExistingServer:true,
    timeout:120000
  }
});
