import { createClient } from "@/lib/supabase/server";

export async function getCurrentMembership() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data } = await supabase
    .from("organization_members")
    .select("organization_id, role, status, employee_id, customer_id, permissions")
    .eq("user_id", user.id)
    .eq("status","active")
    .limit(1)
    .maybeSingle();

  return data;
}
