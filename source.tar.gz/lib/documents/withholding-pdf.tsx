import "server-only";
import React from "react";
import {Document,Page,Text,View,StyleSheet,Font,renderToBuffer} from "@react-pdf/renderer";

const THAI_FONT=process.env.PDF_THAI_FONT_URL||"https://fonts.gstatic.com/s/notosansthai/v25/iJWQBXeUZi_OHPqn4wq6kgV4bLQ.woff2";
Font.register({family:"NotoThai",src:THAI_FONT});

const s=StyleSheet.create({
 page:{fontFamily:"NotoThai",fontSize:10,padding:34,color:"#111"},
 title:{fontSize:18,fontWeight:700,textAlign:"center",marginBottom:8},
 sub:{fontSize:9,textAlign:"center",color:"#555",marginBottom:18},
 box:{borderWidth:1,borderColor:"#bbb",padding:10,marginBottom:10},
 row:{display:"flex",flexDirection:"row",justifyContent:"space-between",gap:12},
 col:{width:"49%"},
 label:{fontSize:8,color:"#666"},
 value:{fontSize:10,marginBottom:5},
 total:{fontSize:14,fontWeight:700,textAlign:"right",marginTop:10},
 footer:{position:"absolute",bottom:24,left:34,right:34,fontSize:7,color:"#666",textAlign:"center"}
});

export async function renderWithholdingPdf(w:any){
 const body=React.createElement(Document,null,
  React.createElement(Page,{size:"A4",style:s.page},
   React.createElement(Text,{style:s.title},"ข้อมูลหนังสือรับรองหัก ณ ที่จ่าย"),
   React.createElement(Text,{style:s.sub},"เอกสารจากระบบ AIRFRIEND — ให้ผู้ทำบัญชีตรวจรูปแบบก่อนใช้เป็นเอกสารทางภาษีจริง"),
   React.createElement(View,{style:s.row},
    React.createElement(View,{style:s.col},
     React.createElement(Text,{style:s.label},"เลขที่"),
     React.createElement(Text,{style:s.value},w.certificate_no||"-")
    ),
    React.createElement(View,{style:s.col},
     React.createElement(Text,{style:s.label},"วันที่"),
     React.createElement(Text,{style:s.value},w.certificate_date||"-")
    )
   ),
   React.createElement(View,{style:s.box},
    React.createElement(Text,{style:s.label},"ผู้จ่ายเงิน"),
    React.createElement(Text,{style:s.value},w.payer_name||"-"),
    React.createElement(Text,{style:s.value},`เลขประจำตัวผู้เสียภาษี ${w.payer_tax_id||"-"}`),
    React.createElement(Text,{style:s.value},w.payer_address||"-")
   ),
   React.createElement(View,{style:s.box},
    React.createElement(Text,{style:s.label},"ผู้รับเงิน"),
    React.createElement(Text,{style:s.value},w.payee_name||"-"),
    React.createElement(Text,{style:s.value},`เลขประจำตัวผู้เสียภาษี ${w.payee_tax_id||"-"}`),
    React.createElement(Text,{style:s.value},w.payee_address||"-")
   ),
   React.createElement(View,{style:s.box},
    React.createElement(Text,{style:s.label},"ประเภทเงินได้"),
    React.createElement(Text,{style:s.value},w.income_type||"-"),
    React.createElement(Text,{style:s.label},"จำนวนเงินที่จ่าย"),
    React.createElement(Text,{style:s.value},`${Number(w.gross_amount||0).toLocaleString("th-TH",{minimumFractionDigits:2})} บาท`),
    React.createElement(Text,{style:s.label},"อัตราหัก"),
    React.createElement(Text,{style:s.value},`${Number(w.withholding_rate||0)}%`),
    React.createElement(Text,{style:s.total},`ภาษีหัก ณ ที่จ่าย ${Number(w.withholding_amount||0).toLocaleString("th-TH",{minimumFractionDigits:2})} บาท`)
   ),
   w.note?React.createElement(Text,null,`หมายเหตุ: ${w.note}`):null,
   React.createElement(Text,{style:s.footer},`สร้างโดย AIRFRIEND SERVICE · ${new Date().toISOString()}`)
  )
 );
 return renderToBuffer(body);
}
