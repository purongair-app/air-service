import "server-only";
import React from "react";
import {
  Document,Page,Text,View,StyleSheet,Font,renderToBuffer
} from "@react-pdf/renderer";

const THAI_FONT=process.env.PDF_THAI_FONT_URL||"https://fonts.gstatic.com/s/notosansthai/v25/iJWQBXeUZi_OHPqn4wq6kgV4bLQ.woff2";
Font.register({family:"NotoThai",src:THAI_FONT});

const s=StyleSheet.create({
 page:{fontFamily:"NotoThai",fontSize:9,padding:30,color:"#111"},
 row:{display:"flex",flexDirection:"row"},
 between:{display:"flex",flexDirection:"row",justifyContent:"space-between"},
 title:{fontSize:18,fontWeight:700,marginBottom:8},
 h2:{fontSize:12,fontWeight:700,marginTop:12,marginBottom:5},
 muted:{color:"#555"},
 table:{marginTop:12,borderTopWidth:1,borderColor:"#bbb"},
 tr:{display:"flex",flexDirection:"row",borderBottomWidth:1,borderColor:"#ddd",paddingVertical:5},
 c1:{width:"48%"},c2:{width:"12%",textAlign:"right"},c3:{width:"18%",textAlign:"right"},c4:{width:"22%",textAlign:"right"},
 total:{fontSize:14,fontWeight:700,textAlign:"right",marginTop:15},
 footer:{position:"absolute",bottom:25,left:30,right:30,fontSize:7,color:"#666",textAlign:"center"}
});

const title:any={
 quote:"ใบเสนอราคา",invoice:"ใบแจ้งหนี้",billing:"ใบวางบิล",
 purchase_order:"ใบสั่งซื้อ",receipt:"ใบเสร็จรับเงิน",
 cash_receipt:"ใบเสร็จรับเงินสด",credit_note:"ใบลดหนี้",debit_note:"ใบเพิ่มหนี้"
};

export async function renderSalesPdf(input:any){
 const {doc,items,branding,balance}=input;
 const issuer=Object.keys(doc.issuer_snapshot||{}).length?doc.issuer_snapshot:doc.organizations||{};
 const customer=Object.keys(doc.customer_snapshot||{}).length?doc.customer_snapshot:{
   name:doc.customers?.organization_name||[doc.customers?.first_name,doc.customers?.last_name].filter(Boolean).join(" "),
   phone:doc.customers?.phone,
   email:doc.customers?.email,
   tax_id:doc.customers?.tax_id,
   address:[doc.customers?.house_no,doc.customers?.village,doc.customers?.road,doc.customers?.subdistrict,doc.customers?.district,doc.customers?.province,doc.customers?.postal_code].filter(Boolean).join(" ")
 };
 const body=React.createElement(Document,null,
  React.createElement(Page,{size:"A4",style:s.page},
   React.createElement(View,{style:s.between},
    React.createElement(View,null,
     React.createElement(Text,{style:s.title},issuer.name||"AIRFRIEND SERVICE"),
     React.createElement(Text,null,issuer.address||""),
     React.createElement(Text,null,[issuer.phone,issuer.email].filter(Boolean).join(" · ")),
     issuer.tax_id?React.createElement(Text,null,`เลขประจำตัวผู้เสียภาษี ${issuer.tax_id}`):null
    ),
    React.createElement(View,{style:{textAlign:"right"}},
     React.createElement(Text,{style:s.title},doc.tax_invoice?"ใบกำกับภาษี / "+(title[doc.document_type]||doc.document_type):(title[doc.document_type]||doc.document_type)),
     React.createElement(Text,null,`เลขที่ ${doc.document_no}`),
     React.createElement(Text,null,`วันที่ ${doc.document_date}`),
     doc.due_date?React.createElement(Text,null,`ครบกำหนด ${doc.due_date}`):null
    )
   ),
   React.createElement(Text,{style:s.h2},"ลูกค้า"),
   React.createElement(Text,null,customer.name||"-"),
   React.createElement(Text,null,customer.address||""),
   React.createElement(Text,null,[customer.phone,customer.email].filter(Boolean).join(" · ")),
   customer.tax_id?React.createElement(Text,null,`เลขประจำตัวผู้เสียภาษี ${customer.tax_id}${customer.branch_name?` · ${customer.branch_name}`:""}`):null,
   React.createElement(View,{style:s.table},
    React.createElement(View,{style:s.tr},
     React.createElement(Text,{style:s.c1},"รายการ"),
     React.createElement(Text,{style:s.c2},"จำนวน"),
     React.createElement(Text,{style:s.c3},"ราคา/หน่วย"),
     React.createElement(Text,{style:s.c4},"รวม")
    ),
    ...items.map((x:any)=>React.createElement(View,{style:s.tr,key:x.id},
      React.createElement(Text,{style:s.c1},x.description),
      React.createElement(Text,{style:s.c2},String(x.quantity)),
      React.createElement(Text,{style:s.c3},Number(x.unit_price||0).toLocaleString("th-TH",{minimumFractionDigits:2})),
      React.createElement(Text,{style:s.c4},(Number(x.quantity)*Number(x.unit_price)-Number(x.discount||0)).toLocaleString("th-TH",{minimumFractionDigits:2}))
    ))
   ),
   doc.tax_invoice?React.createElement(View,{style:{marginTop:12}},
    React.createElement(Text,{style:{textAlign:"right"}},`มูลค่าก่อนภาษี ${Number(doc.amount_before_tax||0).toLocaleString("th-TH",{minimumFractionDigits:2})} บาท`),
    React.createElement(Text,{style:{textAlign:"right"}},`VAT ${Number(doc.vat_rate||0)}% ${Number(doc.vat_amount||0).toLocaleString("th-TH",{minimumFractionDigits:2})} บาท`)
   ):null,
   React.createElement(Text,{style:s.total},`ยอดรวม ${Number(doc.total||0).toLocaleString("th-TH",{minimumFractionDigits:2})} บาท`),
   balance?React.createElement(Text,{style:{textAlign:"right"}},`คงเหลือ ${Number(balance.balance||0).toLocaleString("th-TH",{minimumFractionDigits:2})} บาท`):null,
   doc.source_document_id?React.createElement(Text,{style:{marginTop:10}},`อ้างอิงเอกสารต้นฉบับ: ${doc.reference_data?.source_document_no||"-"}${doc.reference_data?.reason?` · ${doc.reference_data.reason}`:""}`):null,
   React.createElement(View,{style:{marginTop:20}},
    React.createElement(Text,{style:s.h2},"ข้อมูลการชำระเงิน"),
    React.createElement(Text,null,[branding?.bank_name,branding?.account_name,branding?.account_number].filter(Boolean).join(" · ")),
    React.createElement(Text,null,[branding?.promptpay_name,branding?.promptpay_number].filter(Boolean).join(" · "))
   ),
   React.createElement(Text,{style:s.footer},`เอกสารสร้างจาก AIRFRIEND SERVICE · ${new Date().toISOString()}`)
  )
 );
 return renderToBuffer(body);
}
