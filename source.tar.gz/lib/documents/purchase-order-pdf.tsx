import "server-only";
import React from "react";
import {Document,Page,Text,View,StyleSheet,Font,renderToBuffer} from "@react-pdf/renderer";

const THAI_FONT=process.env.PDF_THAI_FONT_URL||"https://fonts.gstatic.com/s/notosansthai/v25/iJWQBXeUZi_OHPqn4wq6kgV4bLQ.woff2";
Font.register({family:"NotoThai",src:THAI_FONT});
const st=StyleSheet.create({
 page:{fontFamily:"NotoThai",fontSize:9,padding:30},
 title:{fontSize:18,fontWeight:700},
 row:{display:"flex",flexDirection:"row"},
 between:{display:"flex",flexDirection:"row",justifyContent:"space-between"},
 table:{marginTop:12,borderTopWidth:1,borderColor:"#bbb"},
 tr:{display:"flex",flexDirection:"row",borderBottomWidth:1,borderColor:"#ddd",paddingVertical:5},
 c1:{width:"50%"},c2:{width:"12%",textAlign:"right"},c3:{width:"18%",textAlign:"right"},c4:{width:"20%",textAlign:"right"},
 total:{fontSize:14,fontWeight:700,textAlign:"right",marginTop:12},
 muted:{color:"#555"},
 footer:{position:"absolute",bottom:24,left:30,right:30,textAlign:"center",fontSize:7,color:"#666"}
});

export async function renderPurchaseOrderPdf(po:any,items:any[],issuer:any){
 const body=React.createElement(Document,null,
  React.createElement(Page,{size:"A4",style:st.page},
   React.createElement(View,{style:st.between},
    React.createElement(View,null,
     React.createElement(Text,{style:st.title},issuer?.name||"AIRFRIEND SERVICE"),
     React.createElement(Text,null,issuer?.address||""),
     React.createElement(Text,null,[issuer?.phone,issuer?.email].filter(Boolean).join(" · ")),
     issuer?.tax_id?React.createElement(Text,null,`เลขประจำตัวผู้เสียภาษี ${issuer.tax_id}`):null
    ),
    React.createElement(View,{style:{textAlign:"right"}},
     React.createElement(Text,{style:st.title},"ใบสั่งซื้อ"),
     React.createElement(Text,null,po.purchase_order_no),
     React.createElement(Text,null,`วันที่ ${po.order_date}`),
     po.expected_date?React.createElement(Text,null,`คาดรับ ${po.expected_date}`):null
    )
   ),
   React.createElement(View,{style:{marginTop:18}},
    React.createElement(Text,{style:st.muted},"ผู้ขาย"),
    React.createElement(Text,null,po.suppliers?.name||"-"),
    React.createElement(Text,null,po.suppliers?.address||""),
    React.createElement(Text,null,[po.suppliers?.phone,po.suppliers?.email].filter(Boolean).join(" · ")),
    po.suppliers?.tax_id?React.createElement(Text,null,`เลขภาษี ${po.suppliers.tax_id}`):null
   ),
   React.createElement(View,{style:st.table},
    React.createElement(View,{style:st.tr},
     React.createElement(Text,{style:st.c1},"รายการ"),
     React.createElement(Text,{style:st.c2},"จำนวน"),
     React.createElement(Text,{style:st.c3},"ต้นทุน/หน่วย"),
     React.createElement(Text,{style:st.c4},"รวม")
    ),
    ...items.map((x:any)=>React.createElement(View,{style:st.tr,key:x.id},
     React.createElement(Text,{style:st.c1},x.description),
     React.createElement(Text,{style:st.c2},`${x.quantity} ${x.unit||""}`),
     React.createElement(Text,{style:st.c3},Number(x.unit_cost||0).toLocaleString("th-TH",{minimumFractionDigits:2})),
     React.createElement(Text,{style:st.c4},(Number(x.quantity)*Number(x.unit_cost)-Number(x.discount||0)).toLocaleString("th-TH",{minimumFractionDigits:2}))
    ))
   ),
   React.createElement(Text,{style:{textAlign:"right",marginTop:10}},`ก่อน VAT ${Number(po.subtotal||0).toLocaleString("th-TH",{minimumFractionDigits:2})} บาท`),
   React.createElement(Text,{style:{textAlign:"right"}},`VAT ${Number(po.vat_rate||0)}% ${Number(po.vat_amount||0).toLocaleString("th-TH",{minimumFractionDigits:2})} บาท`),
   React.createElement(Text,{style:st.total},`ยอดรวม ${Number(po.total||0).toLocaleString("th-TH",{minimumFractionDigits:2})} บาท`),
   po.note?React.createElement(Text,{style:{marginTop:16}},`หมายเหตุ: ${po.note}`):null,
   React.createElement(Text,{style:st.footer},`AIRFRIEND Procurement · ${new Date().toISOString()}`)
  )
 );
 return renderToBuffer(body);
}
