function required(name:string){
  const value=process.env[name];
  if(!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

export const publicEnv={
  supabaseUrl: required("NEXT_PUBLIC_SUPABASE_URL"),
  supabasePublishableKey: required("NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY"),
  siteUrl: process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"
};

export function serverEnv(){
  return {
    supabaseSecretKey:
      process.env.SUPABASE_SECRET_KEY ||
      process.env.SUPABASE_SERVICE_ROLE_KEY ||
      (()=>{throw new Error("Missing SUPABASE_SECRET_KEY")})()
  };
}
