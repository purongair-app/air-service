import "server-only";
import crypto from "node:crypto";
import { createAdminClient } from "@/lib/supabase/admin";

export function hashSupplierToken(token:string){
 return crypto.createHash("sha256").update(token).digest("hex");
}

export async function resolveSupplierToken(token:string){
 const admin=createAdminClient();
 const hash=hashSupplierToken(token);
 const {data:t,error}=await admin.from("supplier_portal_tokens")
  .select("*").eq("token_hash",hash).is("revoked_at",null)
  .gt("expires_at",new Date().toISOString()).maybeSingle();
 if(error||!t)return null;

 await admin.from("supplier_portal_tokens").update({last_opened_at:new Date().toISOString()}).eq("id",t.id);
 return t;
}
