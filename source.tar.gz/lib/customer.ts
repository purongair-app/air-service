import { createClient } from "@/lib/supabase/server";

export async function getCustomerMembership(){
 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user)return null;
 const {data}=await supabase.from("organization_members")
   .select("organization_id,customer_id,role,status")
   .eq("user_id",user.id).eq("role","customer").eq("status","active")
   .limit(1).maybeSingle();
 return data;
}
