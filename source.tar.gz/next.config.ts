import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  poweredByHeader:false,
  async headers(){
    return [{
      source:"/:path*",
      headers:[
        {key:"X-Content-Type-Options",value:"nosniff"},
        {key:"Referrer-Policy",value:"strict-origin-when-cross-origin"},
        {key:"X-Frame-Options",value:"DENY"},
        {key:"Permissions-Policy",value:"camera=(self), geolocation=(self), microphone=()"},
        {key:"Cross-Origin-Opener-Policy",value:"same-origin"},
        {key:"Cross-Origin-Resource-Policy",value:"same-origin"}
      ]
    }];
  }
};
export default nextConfig;
