import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

const severityRank:any={critical:3,warning:2,info:1};

export default async function ControlTower(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:k},{data:alerts=[]},{data:automations=[]}]=await Promise.all([
  supabase.from("operations_control_tower_v3").select("*").eq("organization_id",m.organization_id).maybeSingle(),
  supabase.from("operations_alerts_v3").select("*").eq("organization_id",m.organization_id),
  ["owner","manager"].includes(m.role)
    ? supabase.from("system_automation_runs").select("*").eq("organization_id",m.organization_id).order("started_at",{ascending:false}).limit(20)
    : Promise.resolve({data:[] as any[]})
 ]);
 const sorted=[...(alerts||[])].sort((a:any,b:any)=>(severityRank[b.severity]||0)-(severityRank[a.severity]||0)||(b.priority-a.priority));
 return <AppShell>
  <h1 className="page-title">Operations Control Tower</h1>
  <p className="muted">สิ่งที่ต้องจัดการวันนี้ในหน้าเดียว</p>
  <section className="grid cards">
   <div className="card"><div className="muted">งานวันนี้</div><div className="kpi">{k?.jobs_today||0}</div></div>
   <div className="card"><div className="muted">งานเกินกำหนด</div><div className="kpi">{k?.overdue_jobs||0}</div></div>
   <div className="card"><div className="muted">รอตรวจรับ</div><div className="kpi">{k?.jobs_waiting_review||0}</div></div>
   <div className="card"><div className="muted">A/R เกินกำหนด</div><div className="kpi">{Number(k?.ar_overdue_amount||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">A/P เกินกำหนด</div><div className="kpi">{Number(k?.ap_overdue_amount||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">Reorder Now</div><div className="kpi">{k?.reorder_now_items||0}</div></div>
   <div className="card"><div className="muted">Cycle Count Due</div><div className="kpi">{k?.cycle_count_due_bins||0}</div></div>
   <div className="card"><div className="muted">PM 7 วัน</div><div className="kpi">{k?.pm_due_7d||0}</div></div>
   <div className="card"><div className="muted">Open Supplier RMA</div><div className="kpi">{k?.open_supplier_rmas||0}</div></div>
   <div className="card"><div className="muted">Warranty Claims</div><div className="kpi">{k?.open_warranty_claims||0}</div></div>
   <div className="card"><div className="muted">Claim SLA Breach</div><div className="kpi">{k?.breached_warranty_claims||0}</div></div>
   <div className="card"><div className="muted">NPS</div><div className="kpi">{k?.nps==null?"-":Number(k.nps).toFixed(1)}</div></div>
   <div className="card"><div className="muted">Low Feedback</div><div className="kpi">{k?.low_feedback||0}</div></div>
   <div className="card"><div className="muted">Failed Notifications</div><div className="kpi">{k?.failed_notifications||0}</div></div>
   <div className="card"><div className="muted">Forecast WAPE 30d</div><div className="kpi">{k?.forecast_wape_30d==null?"-":Number(k.forecast_wape_30d).toFixed(1)+"%"}</div></div>
   <div className="card"><div className="muted">Migration Errors</div><div className="kpi">{k?.migration_errors||0}</div></div>
  </section>

  <section className="card" style={{marginTop:16}}><h3>Action Queue</h3>
   <div className="grid">{sorted.map((a:any,i:number)=><a href={a.action_url} className="card" key={i}>
    <div className="actions"><b>{a.title}</b><span className="badge">{a.severity}</span></div><div>{a.detail}</div>
   </a>)}{!sorted.length&&<div className="empty">ไม่มี Alert จาก rule ชุดปัจจุบัน</div>}</div>
  </section>

  {["owner","manager"].includes(m.role)&&<section className="card" style={{marginTop:16}}><h3>Automation Runs</h3>
   <div className="table-wrap"><table><thead><tr><th>งาน</th><th>วันที่</th><th>สถานะ</th><th>เริ่ม</th><th>ผล</th></tr></thead><tbody>
    {automations.map((x:any)=><tr key={x.id}><td>{x.run_kind}</td><td>{x.run_date}</td><td>{x.status}</td><td>{new Date(x.started_at).toLocaleString("th-TH")}</td><td><code>{JSON.stringify(x.result||{})}</code></td></tr>)}
   </tbody></table>{!automations.length&&<div className="empty">ยังไม่มี Automation Run</div>}</div>
  </section>}
 </AppShell>
}
