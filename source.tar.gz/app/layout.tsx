import PwaRegister from "@/components/pwa-register";
import "./globals.css";

export const metadata = {
  title: "AIRFRIEND SERVICE",
  description: "ระบบบริหารธุรกิจแอร์"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="th"><body><PwaRegister/>{children}</body></html>;
}
