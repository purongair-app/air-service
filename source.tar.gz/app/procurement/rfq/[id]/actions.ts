"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

async function manager(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 return m;
}

export async function saveSupplierQuote(formData:FormData){
 const m=await manager(); const supabase=await createClient();
 const rfqId=String(formData.get("rfq_id")||""); const supplierId=String(formData.get("supplier_id")||"");
 const {data:rfq}=await supabase.from("rfqs").select("purchase_request_id").eq("id",rfqId).single();
 if(!rfq)throw new Error("ไม่พบ RFQ");
 const {data:items=[]}=await supabase.from("purchase_request_items").select("*").eq("purchase_request_id",rfq.purchase_request_id).order("sort_order");
 const {data:q,error}=await supabase.from("supplier_quotes").upsert({
  organization_id:m.organization_id,rfq_id:rfqId,supplier_id:supplierId,
  quote_reference:String(formData.get("quote_reference")||""),
  quote_date:String(formData.get("quote_date")||""),
  valid_until:String(formData.get("valid_until")||"")||null,
  lead_time_days:Number(formData.get("lead_time_days")||0)||null,
  vat_rate:Number(formData.get("vat_rate")||0),
  payment_terms:String(formData.get("payment_terms")||""),
  note:String(formData.get("note")||"")
 },{onConflict:"rfq_id,supplier_id"}).select("id").single();
 if(error)throw new Error(error.message);

 await supabase.from("supplier_quote_items").delete().eq("supplier_quote_id",q.id);
 const quoteItems=items.map((x:any)=>({
  organization_id:m.organization_id,supplier_quote_id:q.id,purchase_request_item_id:x.id,
  inventory_item_id:x.inventory_item_id,description:x.description,quantity:x.quantity,
  unit:x.unit,unit_cost:Number(formData.get("cost_"+x.id)||0),discount:Number(formData.get("discount_"+x.id)||0)
 }));
 const {error:ierr}=await supabase.from("supplier_quote_items").insert(quoteItems); if(ierr)throw new Error(ierr.message);
 const {error:rerr}=await supabase.rpc("recalculate_supplier_quote",{p_quote:q.id}); if(rerr)throw new Error(rerr.message);
 await supabase.from("rfq_suppliers").update({status:"responded"}).eq("rfq_id",rfqId).eq("supplier_id",supplierId);
 await supabase.from("rfqs").update({status:"evaluating"}).eq("id",rfqId).eq("status","open");
 revalidatePath("/procurement/rfq/"+rfqId);
}

export async function awardQuote(formData:FormData){
 await manager(); const supabase=await createClient();
 const rfqId=String(formData.get("rfq_id")||""); const quoteId=String(formData.get("quote_id")||"");
 const {data,error}=await supabase.rpc("award_rfq_and_create_po",{p_rfq:rfqId,p_quote:quoteId});
 if(error)throw new Error(error.message);
 redirect("/procurement/"+data.id);
}
