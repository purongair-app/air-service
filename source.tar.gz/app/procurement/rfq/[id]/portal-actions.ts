"use server";
import crypto from "node:crypto";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { hashSupplierToken } from "@/lib/supplier-portal";

export async function createSupplierPortalLink(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const rfqId=String(formData.get("rfq_id")||"");
 const supplierId=String(formData.get("supplier_id")||"");
 const days=Math.min(30,Math.max(1,Number(formData.get("days")||7)));
 const token=crypto.randomBytes(32).toString("base64url");
 const tokenHash=hashSupplierToken(token);
 const expires=new Date(Date.now()+days*86400000).toISOString();
 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 const {error}=await supabase.from("supplier_portal_tokens").upsert({
  organization_id:m.organization_id,rfq_id:rfqId,supplier_id:supplierId,
  token_hash:tokenHash,expires_at:expires,revoked_at:null,submitted_at:null,created_by:user?.id
 },{onConflict:"rfq_id,supplier_id"});
 if(error)throw new Error(error.message);
 redirect(`/procurement/rfq/${rfqId}?supplier_token=${encodeURIComponent(token)}&supplier_id=${supplierId}`);
}
