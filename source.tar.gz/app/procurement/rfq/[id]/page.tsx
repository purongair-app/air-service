import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { saveSupplierQuote,awardQuote } from "./actions";
import { createSupplierPortalLink } from "./portal-actions";

export default async function RfqDetail({params,searchParams}:{params:Promise<{id:string}>,searchParams:Promise<{supplier_token?:string,supplier_id?:string}>}){
 const {id}=await params; const sp=await searchParams; const supabase=await createClient();
 const {data:rfq}=await supabase.from("rfqs").select("*,purchase_requests(*)").eq("id",id).maybeSingle();
 if(!rfq)notFound();
 const [{data:invitees=[]},{data:reqItems=[]},{data:comparison=[]},{data:attachments=[]}]=await Promise.all([
  supabase.from("rfq_suppliers").select("*,suppliers(*)").eq("rfq_id",id).order("invited_at"),
  supabase.from("purchase_request_items").select("*").eq("purchase_request_id",rfq.purchase_request_id).order("sort_order"),
  supabase.from("rfq_quote_comparison").select("*").eq("rfq_id",id).order("price_rank"),
  supabase.from("supplier_quote_attachments").select("*,suppliers(name)").eq("rfq_id",id).order("created_at",{ascending:false})
 ]);
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">{rfq.rfq_no}</h1><p className="muted">{rfq.title} · {rfq.status}</p></div><a className="btn light" href={"/procurement/requests/"+rfq.purchase_request_id}>กลับ PR</a></div>
  {sp.supplier_token&&<section className="card" style={{marginTop:16}}>
   <h3>Supplier Portal Link — คัดลอกตอนนี้</h3>
   <code style={{wordBreak:"break-all"}}>{"/supplier/rfq/"+sp.supplier_token}</code>
   <p className="muted">ระบบเก็บเฉพาะ hash ของ token จึงจะไม่สามารถแสดง token เดิมซ้ำได้ หากหายให้สร้างลิงก์ใหม่</p>
  </section>}
  {invitees.map((inv:any)=><section className="card" style={{marginTop:16}} key={inv.id}>
   <div className="actions"><h3>{inv.suppliers?.name}</h3><span className="badge">{inv.status}</span></div>
   <form action={createSupplierPortalLink} className="actions">
    <input type="hidden" name="rfq_id" value={rfq.id}/><input type="hidden" name="supplier_id" value={inv.supplier_id}/>
    <label>ลิงก์หมดอายุ<input style={{width:80}} type="number" min="1" max="30" name="days" defaultValue="7"/></label>
    <button className="btn light">สร้าง Supplier Link</button>
   </form>
   <form action={saveSupplierQuote} className="grid">
    <input type="hidden" name="rfq_id" value={rfq.id}/><input type="hidden" name="supplier_id" value={inv.supplier_id}/>
    <div className="form-grid">
     <label>เลขใบเสนอราคา Supplier<input name="quote_reference"/></label><label>วันที่<input type="date" name="quote_date" required/></label>
     <label>ใช้ได้ถึง<input type="date" name="valid_until"/></label><label>Lead time (วัน)<input type="number" min="0" name="lead_time_days"/></label>
     <label>VAT %<input type="number" step="0.01" min="0" name="vat_rate" defaultValue="7"/></label><label>เงื่อนไขชำระ<input name="payment_terms"/></label>
    </div>
    <div className="table-wrap"><table><thead><tr><th>รายการ</th><th>จำนวน</th><th>ราคา/หน่วย</th><th>ส่วนลด</th></tr></thead><tbody>
     {reqItems.map((x:any)=><tr key={x.id}><td>{x.description}</td><td>{x.quantity} {x.unit||""}</td><td><input style={{width:120}} type="number" step="0.01" min="0" name={"cost_"+x.id} defaultValue={x.estimated_unit_cost||0}/></td><td><input style={{width:100}} type="number" step="0.01" min="0" name={"discount_"+x.id} defaultValue="0"/></td></tr>)}
    </tbody></table></div>
    <label>หมายเหตุ<textarea name="note"/></label><div><button className="btn light">บันทึกราคา {inv.suppliers?.name}</button></div>
   </form>
  </section>)}
  <section className="card" style={{marginTop:16}}><h3>เปรียบเทียบราคา</h3>
   <div className="table-wrap"><table><thead><tr><th>อันดับ</th><th>Supplier</th><th>อ้างอิง</th><th>Lead time</th><th>Subtotal</th><th>VAT</th><th>Total</th><th></th></tr></thead><tbody>
    {comparison.map((q:any)=><tr key={q.supplier_quote_id}><td>#{q.price_rank}</td><td><b>{q.supplier_name}</b></td><td>{q.quote_reference||"-"}</td><td>{q.lead_time_days??"-"} วัน</td><td>{Number(q.subtotal).toLocaleString()}</td><td>{Number(q.vat_amount).toLocaleString()}</td><td><b>{Number(q.total).toLocaleString()}</b></td><td>{["open","evaluating"].includes(rfq.status)&&<form action={awardQuote}><input type="hidden" name="rfq_id" value={rfq.id}/><input type="hidden" name="quote_id" value={q.supplier_quote_id}/><button className="btn primary">เลือกและสร้าง Draft PO</button></form>}</td></tr>)}
   </tbody></table>{!comparison.length&&<div className="empty">ยังไม่มีราคาจาก Supplier</div>}</div>
  </section>
  <section className="card" style={{marginTop:16}}><h3>ไฟล์ใบเสนอราคาจาก Supplier</h3>
   <div className="grid">{attachments.map((a:any)=><div className="card" key={a.id}><b>{a.suppliers?.name||"-"}</b><div>{a.original_name||"Attachment"}</div><div className="muted">{Math.round(Number(a.file_size||0)/1024)} KB · SHA256 {String(a.sha256||"").slice(0,12)}…</div><a className="btn light" target="_blank" href={"/api/private-file?bucket=business-documents&path="+encodeURIComponent(a.storage_path)}>เปิดไฟล์</a></div>)}{!attachments.length&&<div className="muted">ยังไม่มีไฟล์แนบ</div>}</div>
  </section>
 </AppShell>
}
