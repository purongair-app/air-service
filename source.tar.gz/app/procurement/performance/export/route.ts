import { NextRequest,NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
const esc=(v:any)=>`"${String(v??"").replaceAll('"','""')}"`;

export async function GET(req:NextRequest){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))return new NextResponse("Forbidden",{status:403});
 const kind=req.nextUrl.searchParams.get("kind")||"scorecard";
 const supabase=await createClient();

 if(kind==="po"){
  const {data=[],error}=await supabase.from("purchase_order_performance").select("*").eq("organization_id",m.organization_id).order("order_date",{ascending:false});
  if(error)return new NextResponse(error.message,{status:500});
  const h=["purchase_order_no","supplier_name","order_date","expected_date","first_receipt_date","last_receipt_date","ordered_quantity","received_quantity","fill_rate_pct","delivery_variance_days","purchase_cost_variance","purchase_cost_variance_pct"];
  return new NextResponse("\uFEFF"+[h.join(","),...data.map((x:any)=>h.map(k=>esc(x[k])).join(","))].join("\n"),{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":'attachment; filename="airfriend-po-performance.csv"'}});
 }

 const {data=[],error}=await supabase.from("supplier_performance_scorecard_v2").select("*").eq("organization_id",m.organization_id).order("overall_score_v2",{ascending:false});
 if(error)return new NextResponse(error.message,{status:500});
 const h=["supplier_name","po_count","completed_po_count","on_time_rate_pct","avg_fill_rate_pct","avg_first_receipt_lead_days","avg_full_receipt_lead_days","avg_delivery_variance_days","purchase_cost_variance_pct","received_qty_365d","rma_count_365d","open_rma_count","defect_rate_pct","avg_resolution_days","quality_score","overall_score_v2","rating_v2"];
 return new NextResponse("\uFEFF"+[h.join(","),...data.map((x:any)=>h.map(k=>esc(x[k])).join(","))].join("\n"),{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":'attachment; filename="airfriend-supplier-scorecard.csv"'}});
}
