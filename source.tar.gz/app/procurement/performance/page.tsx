import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function SupplierPerformance(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:suppliers=[]},{data:pos=[]},{data:costs=[]},{data:terms=[]}]=await Promise.all([
  supabase.from("supplier_performance_scorecard_v2").select("*").eq("organization_id",m.organization_id).order("overall_score_v2",{ascending:false}),
  supabase.from("purchase_order_performance").select("*").eq("organization_id",m.organization_id).order("order_date",{ascending:false}).limit(300),
  supabase.from("purchase_cost_variance_by_item").select("*").eq("organization_id",m.organization_id).order("total_cost_variance",{ascending:false}).limit(200),
  supabase.from("inventory_supplier_term_variance").select("*").eq("organization_id",m.organization_id).order("lead_time_variance_days",{ascending:false,nullsFirst:false}).limit(200)
 ]);
 const totalPo=(suppliers as any[]).reduce((n:number,x:any)=>n+Number(x.po_count||0),0);
 const weightedScore=totalPo?((suppliers as any[]).reduce((n:number,x:any)=>n+Number(x.overall_score_v2||0)*Number(x.po_count||0),0)/totalPo):0;
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">Supplier Performance</h1><p className="muted">On-time · Fill Rate · Lead Time · Purchase Cost Variance</p></div><div className="actions"><a className="btn light" href="/procurement/performance/export?kind=scorecard">Export Scorecard</a><a className="btn light" href="/procurement/performance/export?kind=po">Export PO Performance</a></div></div>
  <section className="grid cards">
   <div className="card"><div className="muted">Suppliers มีประวัติ</div><div className="kpi">{suppliers.length}</div></div>
   <div className="card"><div className="muted">PO ใน Scorecard</div><div className="kpi">{totalPo}</div></div>
   <div className="card"><div className="muted">Weighted Score</div><div className="kpi">{weightedScore?weightedScore.toFixed(1):"-"}</div></div>
  </section>

  <section className="card" style={{marginTop:16}}><h3>Supplier Scorecard</h3>
   <div className="table-wrap"><table><thead><tr><th>Supplier</th><th>PO</th><th>On-time</th><th>Fill Rate</th><th>Lead</th><th>Late Variance</th><th>Cost Var</th><th>Defect</th><th>Open RMA</th><th>Quality</th><th>Score</th><th>Rating</th></tr></thead><tbody>
    {suppliers.map((x:any)=><tr key={x.supplier_id}><td><b>{x.supplier_name}</b></td><td>{x.po_count}</td><td>{x.on_time_rate_pct==null?"-":Number(x.on_time_rate_pct).toFixed(1)+"%"}</td><td>{Number(x.avg_fill_rate_pct||0).toFixed(1)}%</td><td>{x.avg_full_receipt_lead_days==null?"-":Number(x.avg_full_receipt_lead_days).toFixed(1)+"d"}</td><td>{x.avg_delivery_variance_days==null?"-":Number(x.avg_delivery_variance_days).toFixed(1)+"d"}</td><td>{x.purchase_cost_variance_pct==null?"-":Number(x.purchase_cost_variance_pct).toFixed(1)+"%"}</td><td>{x.defect_rate_pct==null?"-":Number(x.defect_rate_pct).toFixed(2)+"%"}</td><td>{x.open_rma_count||0}</td><td>{Number(x.quality_score||0).toFixed(1)}</td><td><b>{Number(x.overall_score_v2||0).toFixed(1)}</b></td><td>{x.rating_v2}</td></tr>)}
   </tbody></table>{!suppliers.length&&<div className="empty">ยังไม่มีประวัติ PO/รับของเพียงพอ</div>}</div>
  </section>

  <section className="card" style={{marginTop:16}}><h3>PO Delivery Performance</h3>
   <div className="table-wrap"><table><thead><tr><th>PO</th><th>Supplier</th><th>Order</th><th>Expected</th><th>Last Receipt</th><th>Fill</th><th>Delivery Var</th><th>Cost Var</th></tr></thead><tbody>
    {pos.map((x:any)=><tr key={x.purchase_order_id}><td><a href={"/procurement/"+x.purchase_order_id}>{x.purchase_order_no}</a></td><td>{x.supplier_name}</td><td>{x.order_date}</td><td>{x.expected_date||"-"}</td><td>{x.last_receipt_date||"-"}</td><td>{Number(x.fill_rate_pct||0).toFixed(1)}%</td><td>{x.delivery_variance_days==null?"-":x.delivery_variance_days+"d"}</td><td>{x.purchase_cost_variance_pct==null?"-":Number(x.purchase_cost_variance_pct).toFixed(1)+"%"}</td></tr>)}
   </tbody></table></div>
  </section>

  <section className="card" style={{marginTop:16}}><h3>Purchase Cost Variance by Item</h3>
   <div className="table-wrap"><table><thead><tr><th>Supplier</th><th>SKU</th><th>สินค้า</th><th>Qty รับ</th><th>PO Cost</th><th>Actual Cost</th><th>Variance</th><th>%</th></tr></thead><tbody>
    {costs.map((x:any)=><tr key={x.supplier_id+"-"+x.inventory_item_id}><td>{x.supplier_name}</td><td>{x.sku}</td><td>{x.name}</td><td>{x.received_quantity}</td><td>{Number(x.po_weighted_unit_cost||0).toFixed(2)}</td><td>{Number(x.actual_weighted_unit_cost||0).toFixed(2)}</td><td>{Number(x.total_cost_variance||0).toLocaleString()}</td><td>{x.cost_variance_pct==null?"-":Number(x.cost_variance_pct).toFixed(1)+"%"}</td></tr>)}
   </tbody></table></div>
  </section>

  <section className="card" style={{marginTop:16}}><h3>Configured vs Observed Lead Time</h3>
   <div className="table-wrap"><table><thead><tr><th>สินค้า</th><th>Supplier</th><th>Preferred</th><th>Configured</th><th>Observed Full</th><th>Lead Var</th><th>Quoted→Actual Cost</th></tr></thead><tbody>
    {terms.map((x:any)=><tr key={x.inventory_item_id+"-"+x.supplier_id}><td>{x.sku} · {x.name}</td><td>{x.supplier_name}</td><td>{x.preferred?"Yes":"-"}</td><td>{x.configured_lead_time_days}d</td><td>{x.observed_full_receipt_days==null?"-":Number(x.observed_full_receipt_days).toFixed(1)+"d"}</td><td>{x.lead_time_variance_days==null?"-":Number(x.lead_time_variance_days).toFixed(1)+"d"}</td><td>{x.quoted_to_actual_cost_variance_pct==null?"-":Number(x.quoted_to_actual_cost_variance_pct).toFixed(1)+"%"}</td></tr>)}
   </tbody></table></div>
  </section>
 </AppShell>
}
