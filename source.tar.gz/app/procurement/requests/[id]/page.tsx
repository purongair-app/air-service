import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { addRequestItem,submitRequest,actApproval,createRfq } from "./actions";

export default async function RequestDetail({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const supabase=await createClient();
 const [{data:r},{data:items=[]},{data:inventory=[]},{data:approvals=[]},{data:suppliers=[]},{data:rfqs=[]}]=await Promise.all([
  supabase.from("purchase_requests").select("*").eq("id",id).maybeSingle(),
  supabase.from("purchase_request_items").select("*").eq("purchase_request_id",id).order("sort_order"),
  supabase.from("inventory_items").select("id,sku,name,unit,cost,quantity").order("name").limit(1000),
  supabase.from("purchase_request_approvals").select("*").eq("purchase_request_id",id).order("sequence"),
  supabase.from("suppliers").select("id,supplier_no,name").eq("active",true).order("name"),
  supabase.from("rfqs").select("*").eq("purchase_request_id",id).order("created_at",{ascending:false})
 ]);
 if(!r)notFound();
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">{r.request_no}</h1><p className="muted">{r.title} · {r.status}</p></div><a className="btn light" href="/procurement/requests">กลับ</a></div>
  <section className="grid cards">
   <div className="card"><div className="muted">ประมาณการ</div><div className="kpi">{Number(r.estimated_total||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">ต้องการภายใน</div><div className="kpi" style={{fontSize:18}}>{r.required_date||"-"}</div></div>
  </section>
  {r.status==="draft"&&<section className="card" style={{marginTop:16}}><h3>เพิ่มรายการ</h3><form action={addRequestItem} className="form-grid">
   <input type="hidden" name="request_id" value={r.id}/>
   <label>สินค้าในคลัง<select name="inventory_item_id"><option value="">รายการใหม่/อื่น ๆ</option>{inventory.map((i:any)=><option key={i.id} value={i.id}>{i.sku} · {i.name} · คงเหลือ {i.quantity}</option>)}</select></label>
   <label>รายละเอียด<input name="description"/></label><label>จำนวน<input type="number" step="0.001" min="0.001" name="quantity" required/></label>
   <label>หน่วย<input name="unit"/></label><label>ราคาประมาณ/หน่วย<input type="number" step="0.01" min="0" name="estimated_unit_cost"/></label>
   <label>หมายเหตุ<input name="note"/></label><div><button className="btn primary">เพิ่มรายการ</button></div>
  </form></section>}
  <section className="card" style={{marginTop:16}}><h3>รายการขอซื้อ</h3><div className="table-wrap"><table><thead><tr><th>รายการ</th><th>จำนวน</th><th>หน่วย</th><th>ราคา/หน่วย</th><th>รวม</th></tr></thead><tbody>
   {items.map((x:any)=><tr key={x.id}><td>{x.description}</td><td>{x.quantity}</td><td>{x.unit||"-"}</td><td>{Number(x.estimated_unit_cost).toLocaleString()}</td><td>{(Number(x.quantity)*Number(x.estimated_unit_cost)).toLocaleString()}</td></tr>)}
  </tbody></table></div>
  {r.status==="draft"&&<form action={submitRequest} style={{marginTop:12}}><input type="hidden" name="request_id" value={r.id}/><button className="btn primary" disabled={!items.length}>Submit ขออนุมัติ</button></form>}
  </section>
  {!!approvals.length&&<section className="card" style={{marginTop:16}}><h3>Approval</h3>
   <div className="grid">{approvals.map((a:any)=><div className="badge" key={a.id}>#{a.sequence} {a.required_role} · {a.status}</div>)}</div>
   {["submitted","partially_approved"].includes(r.status)&&<form action={actApproval} className="form-grid" style={{marginTop:12}}>
    <input type="hidden" name="request_id" value={r.id}/><label>ความเห็น<input name="comment"/></label>
    <div className="actions"><button className="btn primary" name="action" value="approve">อนุมัติขั้นนี้</button><button className="btn light" name="action" value="reject">ปฏิเสธ</button></div>
   </form>}
  </section>}
  {r.status==="approved"&&<section className="card" style={{marginTop:16}}><h3>สร้าง RFQ</h3><form action={createRfq} className="form-grid">
   <input type="hidden" name="request_id" value={r.id}/><label>กำหนดรับราคา<input type="date" name="quote_due_date"/></label>
   <div style={{gridColumn:"1/-1"}}><b>เลือก Supplier</b><div className="grid">{suppliers.map((s:any)=><label key={s.id}><span><input type="checkbox" name="supplier_id" value={s.id}/> {s.supplier_no} · {s.name}</span></label>)}</div></div>
   <div><button className="btn primary">สร้าง RFQ</button></div>
  </form></section>}
  {!!rfqs.length&&<section className="card" style={{marginTop:16}}><h3>RFQ ที่สร้างแล้ว</h3>{rfqs.map((q:any)=><div key={q.id}><a href={"/procurement/rfq/"+q.id}><b>{q.rfq_no}</b></a> · {q.status}</div>)}</section>}
 </AppShell>
}
