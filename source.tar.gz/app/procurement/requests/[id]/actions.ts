"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

async function member(){
 const m=await getCurrentMembership(); if(!m)throw new Error("ไม่มี membership"); return m;
}

export async function addRequestItem(formData:FormData){
 const m=await member(); const supabase=await createClient();
 const req=String(formData.get("request_id")||""); const invId=String(formData.get("inventory_item_id")||"")||null;
 let description=String(formData.get("description")||"");
 let unit=String(formData.get("unit")||"");
 let cost=Number(formData.get("estimated_unit_cost")||0);
 if(invId){
  const {data:i}=await supabase.from("inventory_items").select("name,unit,cost").eq("id",invId).single();
  if(i){description=description||i.name;unit=unit||i.unit;cost=cost||Number(i.cost||0)}
 }
 const {error}=await supabase.from("purchase_request_items").insert({
  organization_id:m.organization_id,purchase_request_id:req,inventory_item_id:invId,
  description,quantity:Number(formData.get("quantity")||0),unit,estimated_unit_cost:cost,
  note:String(formData.get("note")||"")
 });
 if(error)throw new Error(error.message);
 const {error:r}=await supabase.rpc("recalculate_purchase_request",{p_request:req}); if(r)throw new Error(r.message);
 revalidatePath("/procurement/requests/"+req);
}

export async function submitRequest(formData:FormData){
 await member(); const supabase=await createClient(); const id=String(formData.get("request_id")||"");
 const {error}=await supabase.rpc("submit_purchase_request",{p_request:id}); if(error)throw new Error(error.message);
 revalidatePath("/procurement/requests/"+id);revalidatePath("/procurement/requests");
}

export async function actApproval(formData:FormData){
 await member(); const supabase=await createClient(); const id=String(formData.get("request_id")||"");
 const {error}=await supabase.rpc("act_purchase_request_approval",{
  p_request:id,p_action:String(formData.get("action")||""),p_comment:String(formData.get("comment")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/procurement/requests/"+id);revalidatePath("/procurement/requests");
}

export async function createRfq(formData:FormData){
 await member(); const supabase=await createClient(); const id=String(formData.get("request_id")||"");
 const supplierIds=formData.getAll("supplier_id").map(String).filter(Boolean);
 const {data,error}=await supabase.rpc("create_rfq_from_request",{
  p_request:id,p_supplier_ids:supplierIds,p_quote_due_date:String(formData.get("quote_due_date")||"")||null
 });
 if(error)throw new Error(error.message);
 redirect("/procurement/rfq/"+data.id);
}
