"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function createPurchaseRequest(formData:FormData){
 const m=await getCurrentMembership(); if(!m)throw new Error("ไม่มี membership");
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
 const {data:no,error:noErr}=await supabase.rpc("next_purchase_request_number",{p_org:m.organization_id});
 if(noErr)throw new Error(noErr.message);
 const {data:r,error}=await supabase.from("purchase_requests").insert({
   organization_id:m.organization_id,request_no:no,title:String(formData.get("title")||""),
   requested_by:user?.id,requested_for:String(formData.get("requested_for")||""),
   required_date:String(formData.get("required_date")||"")||null,
   reason:String(formData.get("reason")||"")
 }).select("id").single();
 if(error)throw new Error(error.message);
 redirect("/procurement/requests/"+r.id);
}

export async function seedDefaultRules(){
 const m=await getCurrentMembership(); if(!m||m.role!=="owner")throw new Error("เฉพาะ Owner");
 const supabase=await createClient();
 const rows=[
   {organization_id:m.organization_id,name:"Manager ≤ 20,000",min_amount:0,max_amount:20000,required_role:"manager",sequence:1},
   {organization_id:m.organization_id,name:"Owner > 20,000",min_amount:20000.01,max_amount:null,required_role:"owner",sequence:1}
 ];
 const {error}=await supabase.from("purchase_approval_rules").upsert(rows,{onConflict:"organization_id,name"});
 if(error)throw new Error(error.message);
 revalidatePath("/procurement/requests");
}
