import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { createPurchaseRequest,seedDefaultRules } from "./actions";

export default async function PurchaseRequests(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:rows=[]},{data:rules=[]}]=await Promise.all([
  supabase.from("purchase_requests").select("*").eq("organization_id",m.organization_id).order("created_at",{ascending:false}),
  supabase.from("purchase_approval_rules").select("*").eq("organization_id",m.organization_id).eq("active",true).order("sequence")
 ]);
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">Purchase Requests</h1><p className="muted">ขอซื้อ → อนุมัติ → RFQ → เปรียบเทียบ Supplier → Draft PO</p></div>{m.role==="owner"&&<form action={seedDefaultRules}><button className="btn light">สร้าง Approval Rule เริ่มต้น</button></form>}</div>
  <section className="card" style={{marginBottom:16}}><form action={createPurchaseRequest} className="form-grid">
   <label>หัวข้อ<input name="title" required/></label><label>ใช้สำหรับ<input name="requested_for" placeholder="งาน / แผนก / รถบริการ"/></label>
   <label>ต้องการภายใน<input type="date" name="required_date"/></label>
   <label style={{gridColumn:"1/-1"}}>เหตุผล<textarea name="reason"/></label>
   <div><button className="btn primary">สร้างคำขอซื้อ</button></div>
  </form></section>
  <section className="card" style={{marginBottom:16}}><h3>Approval Matrix</h3>{rules.map((r:any)=><div className="badge" key={r.id}>#{r.sequence} {r.name} · {r.required_role}</div>)}{!rules.length&&<div className="muted">ยังไม่มี Approval Rule — ถ้าไม่มี rule คำขอจะ Approved ทันทีเมื่อ Submit</div>}</section>
  <div className="table-wrap"><table><thead><tr><th>PR</th><th>หัวข้อ</th><th>ต้องการ</th><th>ประมาณการ</th><th>สถานะ</th></tr></thead><tbody>
   {rows.map((r:any)=><tr key={r.id}><td><a href={"/procurement/requests/"+r.id}><b>{r.request_no}</b></a></td><td>{r.title}</td><td>{r.required_date||"-"}</td><td>{Number(r.estimated_total||0).toLocaleString()}</td><td>{r.status}</td></tr>)}
  </tbody></table></div>
 </AppShell>
}
