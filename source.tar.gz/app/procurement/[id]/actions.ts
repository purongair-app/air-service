"use server";
import { revalidatePath } from "next/cache";
import crypto from "node:crypto";
import { renderPurchaseOrderPdf } from "@/lib/documents/purchase-order-pdf";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

async function staff(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 return m;
}

export async function addPoItem(formData:FormData){
 const m=await staff(); const supabase=await createClient();
 const poId=String(formData.get("po_id")||"");
 const invId=String(formData.get("inventory_item_id")||"");
 const {data:inv}=await supabase.from("inventory_items").select("name,unit,cost").eq("id",invId).single();
 if(!inv)throw new Error("ไม่พบสินค้า");
 const {error}=await supabase.from("purchase_order_items").insert({
  organization_id:m.organization_id,purchase_order_id:poId,inventory_item_id:invId,
  description:inv.name,quantity:Number(formData.get("quantity")||0),
  unit:inv.unit,unit_cost:Number(formData.get("unit_cost")||inv.cost||0),
  discount:Number(formData.get("discount")||0)
 });
 if(error)throw new Error(error.message);
 const {error:r}=await supabase.rpc("recalculate_purchase_order",{p_po:poId});
 if(r)throw new Error(r.message);
 revalidatePath("/procurement/"+poId);
}

export async function approvePo(formData:FormData){
 await staff(); const supabase=await createClient(); const id=String(formData.get("po_id")||"");
 const {error}=await supabase.rpc("approve_purchase_order",{p_po:id});
 if(error)throw new Error(error.message);
 revalidatePath("/procurement/"+id); revalidatePath("/procurement");
}

export async function receivePo(formData:FormData){
 await staff(); const supabase=await createClient(); const id=String(formData.get("po_id")||"");
 const raw=String(formData.get("items_json")||"[]");
 let items:any[]=[]; try{items=JSON.parse(raw)}catch{throw new Error("ข้อมูลรับของไม่ถูกต้อง")}
 const {error}=await supabase.rpc("receive_purchase_order",{
  p_po:id,
  p_receipt_date:String(formData.get("receipt_date")||"")||null,
  p_supplier_delivery_no:String(formData.get("supplier_delivery_no")||""),
  p_note:String(formData.get("note")||""),
  p_items:items
 });
 if(error)throw new Error(error.message);
 revalidatePath("/procurement/"+id);revalidatePath("/inventory");revalidatePath("/procurement");
}

export async function createBill(formData:FormData){
 await staff(); const supabase=await createClient(); const id=String(formData.get("po_id")||"");
 const {error}=await supabase.rpc("create_supplier_bill_from_po",{
  p_po:id,p_supplier_invoice_no:String(formData.get("supplier_invoice_no")||""),
  p_bill_date:String(formData.get("bill_date")||"")||null,
  p_due_date:String(formData.get("due_date")||"")||null,p_note:String(formData.get("note")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/procurement/"+id);revalidatePath("/payables");
}


export async function generatePoArchive(formData:FormData){
 await staff(); const supabase=await createClient();
 const id=String(formData.get("po_id")||"");
 const {data:{user}}=await supabase.auth.getUser();
 const [{data:po},{data:items=[]}]=await Promise.all([
  supabase.from("purchase_orders").select("*,suppliers(*)").eq("id",id).single(),
  supabase.from("purchase_order_items").select("*").eq("purchase_order_id",id).order("sort_order")
 ]);
 if(!po)throw new Error("ไม่พบ PO");
 if(po.status==="draft")throw new Error("กรุณาอนุมัติ PO ก่อนสร้าง PDF");

 const {data:org}=await supabase.from("organizations").select("*").eq("id",po.organization_id).single();
 const buffer=await renderPurchaseOrderPdf(po,items,org);
 const sha256=crypto.createHash("sha256").update(buffer).digest("hex");
 const {data:last}=await supabase.from("purchase_order_archives").select("version").eq("purchase_order_id",id).order("version",{ascending:false}).limit(1).maybeSingle();
 const version=Number(last?.version||0)+1;
 const safeNo=String(po.purchase_order_no).replace(/[^A-Za-z0-9._-]+/g,"-");
 const path=`${po.organization_id}/purchase-orders/${po.id}/${safeNo}-v${version}.pdf`;

 const {error:up}=await supabase.storage.from("generated-documents").upload(path,buffer,{contentType:"application/pdf",upsert:false});
 if(up)throw new Error(up.message);

 const {error:aerr}=await supabase.from("purchase_order_archives").insert({
  organization_id:po.organization_id,purchase_order_id:po.id,purchase_order_no:po.purchase_order_no,
  version,storage_path:path,file_size:buffer.length,sha256,
  snapshot:{purchase_order:po,items},generated_by:user?.id
 });
 if(aerr)throw new Error(aerr.message);
 revalidatePath("/procurement/"+id);
}
