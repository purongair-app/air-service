"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function createPurchaseReturn(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager ที่คืนสินค้า Supplier ได้");
 const supabase=await createClient(); const poId=String(formData.get("po_id")||"");
 let items:any[]=[]; try{items=JSON.parse(String(formData.get("items_json")||"[]"))}catch{throw new Error("ข้อมูลไม่ถูกต้อง")}
 const {error}=await supabase.rpc("return_purchase_items",{
  p_po:poId,p_return_date:String(formData.get("return_date")||"")||null,
  p_reason:String(formData.get("reason")||""),
  p_supplier_return_reference:String(formData.get("supplier_return_reference")||""),
  p_note:String(formData.get("note")||""),p_items:items
 });
 if(error){
  if(error.message.includes("insufficient_stock_for_return"))throw new Error("สต็อกคงเหลือไม่พอสำหรับคืน Supplier");
  if(error.message.includes("return_exceeds_received"))throw new Error("จำนวนคืนเกินจำนวนที่รับจริง");
  throw new Error(error.message);
 }
 revalidatePath("/procurement/"+poId);revalidatePath("/inventory");revalidatePath("/procurement/returns");
}
