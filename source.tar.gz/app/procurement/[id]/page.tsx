import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { addPoItem,approvePo,createBill,generatePoArchive } from "./actions";
import PurchaseReturnForm from "@/components/purchase-return-form";
import PoReceiveForm from "@/components/po-receive-form";

export default async function PurchaseOrderDetail({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const supabase=await createClient();
 const [{data:po},{data:items=[]},{data:inventory=[]},{data:receipts=[]},{data:bills=[]},{data:returnable=[]},{data:returns=[]},{data:archives=[]}]=await Promise.all([
  supabase.from("purchase_orders").select("*,suppliers(*)").eq("id",id).maybeSingle(),
  supabase.from("purchase_order_items").select("*").eq("purchase_order_id",id).order("sort_order"),
  supabase.from("inventory_items").select("id,sku,name,unit,cost,quantity").order("name").limit(1000),
  supabase.from("goods_receipts").select("*,goods_receipt_items(*)").eq("purchase_order_id",id).order("created_at",{ascending:false}),
  supabase.from("supplier_bills").select("*,supplier_bill_balance(*)").eq("purchase_order_id",id).order("created_at",{ascending:false}),
  supabase.from("purchase_order_returnable").select("*").eq("purchase_order_id",id).gt("returnable_quantity",0),
  supabase.from("purchase_returns").select("*").eq("purchase_order_id",id).order("created_at",{ascending:false}),
  supabase.from("purchase_order_archives").select("*").eq("purchase_order_id",id).order("version",{ascending:false})
 ]);
 if(!po)notFound();
 const canEdit=po.status==="draft";
 const canReceive=["approved","partially_received"].includes(po.status);
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">{po.purchase_order_no}</h1><p className="muted">{po.suppliers?.name} · {po.status}</p></div><a className="btn light" href="/procurement">กลับ</a></div>
  <section className="grid cards">
   <div className="card"><div className="muted">Subtotal</div><div className="kpi">{Number(po.subtotal||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">VAT</div><div className="kpi">{Number(po.vat_amount||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">Total</div><div className="kpi">{Number(po.total||0).toLocaleString()}</div></div>
  </section>

  {canEdit&&<section className="card" style={{marginTop:16}}><h3>เพิ่มสินค้า</h3><form action={addPoItem} className="form-grid">
   <input type="hidden" name="po_id" value={po.id}/>
   <label>สินค้า<select name="inventory_item_id">{inventory.map((x:any)=><option key={x.id} value={x.id}>{x.sku} · {x.name} · คงเหลือ {x.quantity}</option>)}</select></label>
   <label>จำนวน<input type="number" step="0.001" min="0.001" name="quantity" required/></label>
   <label>ต้นทุน/หน่วย<input type="number" step="0.01" min="0" name="unit_cost" required/></label>
   <label>ส่วนลด<input type="number" step="0.01" min="0" name="discount" defaultValue="0"/></label>
   <div><button className="btn primary">เพิ่มรายการ</button></div>
  </form></section>}

  <section className="card" style={{marginTop:16}}><h3>รายการสั่งซื้อ</h3><div className="table-wrap"><table><thead><tr><th>รายการ</th><th>จำนวน</th><th>รับแล้ว</th><th>หน่วย</th><th>ต้นทุน</th><th>ส่วนลด</th></tr></thead><tbody>
   {items.map((x:any)=><tr key={x.id}><td>{x.description}</td><td>{x.quantity}</td><td>{x.received_quantity}</td><td>{x.unit||"-"}</td><td>{Number(x.unit_cost).toLocaleString()}</td><td>{Number(x.discount).toLocaleString()}</td></tr>)}
  </tbody></table></div>
  {po.status==="draft"&&<form action={approvePo} style={{marginTop:12}}><input type="hidden" name="po_id" value={po.id}/><button className="btn primary" disabled={!items.length}>อนุมัติ PO</button></form>}
  </section>

  {canReceive&&<section className="card" style={{marginTop:16}}><h3>รับสินค้า</h3><PoReceiveForm poId={po.id} items={items}/></section>}

  {!["draft","cancelled"].includes(po.status)&&<section className="card" style={{marginTop:16}}><h3>สร้างเจ้าหนี้จาก PO</h3><form action={createBill} className="form-grid">
   <input type="hidden" name="po_id" value={po.id}/><label>เลข Invoice Supplier<input name="supplier_invoice_no"/></label>
   <label>วันที่เอกสาร<input type="date" name="bill_date" required/></label><label>ครบกำหนด<input type="date" name="due_date"/></label>
   <label>หมายเหตุ<input name="note"/></label><div><button className="btn light">สร้าง A/P Bill</button></div>
  </form></section>}



  {po.status!=="draft"&&<section className="card" style={{marginTop:16}}><h3>PDF ใบสั่งซื้อ</h3>
   <div className="actions"><form action={generatePoArchive}><input type="hidden" name="po_id" value={po.id}/><button className="btn primary">สร้าง PO PDF Archive</button></form>{po.suppliers?.email&&<a className="btn light" href={"mailto:"+po.suppliers.email+"?subject="+encodeURIComponent("Purchase Order "+po.purchase_order_no)}>เปิด Email ถึง Supplier</a>}</div>
   <div className="grid" style={{marginTop:10}}>{archives.map((a:any)=><div className="card" key={a.id}><b>Version {a.version}</b><div className="muted">{new Date(a.generated_at).toLocaleString("th-TH")} · {String(a.sha256||"").slice(0,12)}…</div><a className="btn light" target="_blank" href={"/api/private-file?bucket=generated-documents&path="+encodeURIComponent(a.storage_path)}>เปิด PDF</a></div>)}{!archives.length&&<div className="muted">ยังไม่มี Archive</div>}</div>
  </section>}

  {returnable.length>0&&<section className="card" style={{marginTop:16}}><h3>คืนสินค้า Supplier</h3><PurchaseReturnForm poId={po.id} items={returnable}/></section>}

  <section className="card" style={{marginTop:16}}><h3>ประวัติคืน Supplier</h3>
   {returns.map((r:any)=><div key={r.id} className="badge">{r.purchase_return_no} · {r.return_date} · {Number(r.total||0).toLocaleString()} · {r.status}</div>)}
   {!returns.length&&<div className="muted">ยังไม่มีรายการคืน</div>}
  </section>
  <section className="card" style={{marginTop:16}}><h3>ประวัติรับของ</h3>{receipts.map((r:any)=><div key={r.id} className="badge">{r.goods_receipt_no} · {r.receipt_date} · {r.supplier_delivery_no||"-"}</div>)}{!receipts.length&&<div className="muted">ยังไม่มีการรับสินค้า</div>}</section>
  <section className="card" style={{marginTop:16}}><h3>เจ้าหนี้ที่ผูกกับ PO</h3>{bills.map((b:any)=><div key={b.id}><a href={"/payables/"+b.id}><b>{b.bill_no}</b></a> · {b.supplier_invoice_no||"-"} · {Number(b.total).toLocaleString()} · {b.status}</div>)}{!bills.length&&<div className="muted">ยังไม่มี A/P Bill</div>}</section>
 </AppShell>
}
