import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function PurchaseReturns(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const {data=[]}=await supabase.from("purchase_returns")
  .select("*,suppliers(name),purchase_orders(purchase_order_no),purchase_return_items(*)")
  .eq("organization_id",m.organization_id).order("return_date",{ascending:false});
 return <AppShell><h1 className="page-title">คืนสินค้า Supplier</h1>
  <div className="table-wrap"><table><thead><tr><th>เลขคืน</th><th>วันที่</th><th>Supplier</th><th>PO</th><th>รายการ</th><th>ยอด</th><th>อ้างอิง</th></tr></thead><tbody>
   {data.map((r:any)=><tr key={r.id}><td>{r.purchase_return_no}</td><td>{r.return_date}</td><td>{r.suppliers?.name}</td><td><a href={"/procurement/"+r.purchase_order_id}>{r.purchase_orders?.purchase_order_no}</a></td><td>{r.purchase_return_items?.length||0}</td><td>{Number(r.total||0).toLocaleString()}</td><td>{r.supplier_return_reference||"-"}</td></tr>)}
  </tbody></table>{!data.length&&<div className="empty">ยังไม่มีรายการคืน Supplier</div>}</div>
 </AppShell>
}
