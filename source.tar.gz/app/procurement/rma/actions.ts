"use server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function createRma(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient();
 const grId=String(formData.get("goods_receipt_id")||"");
 const billId=String(formData.get("supplier_bill_id")||"")||null;
 const jobId=String(formData.get("job_id")||"")||null;
 let items:any[]=[];
 try{items=JSON.parse(String(formData.get("items_json")||"[]"))}catch{throw new Error("รายการ RMA ไม่ถูกต้อง")}
 const {data,error}=await supabase.rpc("create_supplier_rma",{
  p_goods_receipt:grId,p_supplier_bill:billId,p_job:jobId,
  p_reason:String(formData.get("reason")||""),
  p_resolution_type:String(formData.get("resolution_type")||"replacement"),
  p_items:items
 });
 if(error)throw new Error(error.message);
 const claimId=String(formData.get("warranty_claim_id")||"")||null;
 if(claimId){
   const {error:linkError}=await supabase.from("supplier_rmas").update({warranty_claim_id:claimId}).eq("id",data.id);
   if(linkError)throw new Error(linkError.message);
   await supabase.from("warranty_claims").update({status:"waiting_supplier"}).eq("id",claimId);
   await supabase.from("warranty_claim_events").insert({
     organization_id:m.organization_id,warranty_claim_id:claimId,event:"supplier_rma_created",
     detail:"สร้าง Supplier RMA "+data.rma_no,visibility:"customer"
   });
 }
 redirect("/procurement/rma/"+data.id);
}
