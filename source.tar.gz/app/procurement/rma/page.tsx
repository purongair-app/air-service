import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import RmaCreateForm from "@/components/rma-create-form";

export default async function RmaPage({searchParams}:{searchParams:Promise<{claim_id?:string}>}){
 const sp=await searchParams; const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:rmas=[]},{data:receipts=[]},{data:bills=[]},{data:jobs=[]},{data:bins=[]}]=await Promise.all([
  supabase.from("supplier_rmas").select("*,suppliers(name)").eq("organization_id",m.organization_id).order("created_at",{ascending:false}).limit(200),
  supabase.from("goods_receipts").select("id,goods_receipt_no,receipt_date,supplier_id,suppliers(name),goods_receipt_items(id,quantity,unit_cost,inventory_item_id,inventory_items(sku,name))").eq("organization_id",m.organization_id).order("receipt_date",{ascending:false}).limit(200),
  supabase.from("supplier_bills").select("id,bill_no,supplier_id,total,status").eq("organization_id",m.organization_id).neq("status","cancelled").order("bill_date",{ascending:false}).limit(300),
  supabase.from("jobs").select("id,work_no,customer_name_snapshot").eq("organization_id",m.organization_id).order("created_at",{ascending:false}).limit(200),
  supabase.from("warehouse_bins").select("id,code,warehouses(code)").eq("organization_id",m.organization_id).eq("active",true).order("code")
 ]);
 return <AppShell>
  <h1 className="page-title">Supplier Warranty / RMA</h1><p className="muted">เคลมสินค้าเสีย/มีปัญหา → ส่ง Supplier → รับของทดแทนหรือ Credit</p>
  <RmaCreateForm receipts={receipts} bills={bills} jobs={jobs} bins={bins} warrantyClaimId={sp.claim_id||""}/>
  <section className="card" style={{marginTop:16}}><h3>RMA ล่าสุด</h3><div className="table-wrap"><table><thead><tr><th>RMA</th><th>Supplier</th><th>เหตุผล</th><th>มูลค่าเคลม</th><th>Resolution</th><th>สถานะ</th></tr></thead><tbody>
   {rmas.map((r:any)=><tr key={r.id}><td><a href={"/procurement/rma/"+r.id}><b>{r.rma_no}</b></a></td><td>{r.suppliers?.name}</td><td>{r.reason}</td><td>{Number(r.claimed_value||0).toLocaleString()}</td><td>{r.resolution_type}</td><td>{r.status}</td></tr>)}
  </tbody></table>{!rmas.length&&<div className="empty">ยังไม่มี Supplier RMA</div>}</div></section>
 </AppShell>
}
