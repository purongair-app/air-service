"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import crypto from "node:crypto";
import { getCurrentMembership } from "@/lib/org";

async function management(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 return m;
}

export async function shipRma(formData:FormData){
 const m=await management();
 if(!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient();const id=String(formData.get("rma_id")||"");
 const {error}=await supabase.rpc("ship_supplier_rma",{
  p_rma:id,p_supplier_reference:String(formData.get("supplier_reference")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/procurement/rma/"+id);revalidatePath("/inventory");
}

export async function receiveReplacement(formData:FormData){
 await management(); const supabase=await createClient();const id=String(formData.get("rma_id")||"");
 let items:any[]=[];try{items=JSON.parse(String(formData.get("items_json")||"[]"))}catch{throw new Error("ข้อมูลไม่ถูกต้อง")}
 const {error}=await supabase.rpc("receive_supplier_rma_replacement",{
  p_rma:id,p_items:items,p_note:String(formData.get("note")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/procurement/rma/"+id);revalidatePath("/inventory");
}

export async function creditRma(formData:FormData){
 const m=await management();
 if(!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient();const id=String(formData.get("rma_id")||"");
 const {error}=await supabase.rpc("create_supplier_credit_from_rma",{
  p_rma:id,p_bill:String(formData.get("bill_id")||""),
  p_amount:Number(formData.get("amount")||0),
  p_supplier_reference:String(formData.get("supplier_reference")||""),
  p_reason:String(formData.get("reason")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/procurement/rma/"+id);revalidatePath("/payables");
}


export async function uploadRmaEvidence(formData:FormData){
 const m=await management(); const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 const id=String(formData.get("rma_id")||""); const file=formData.get("attachment");
 if(!(file instanceof File)||file.size<=0)throw new Error("กรุณาเลือกไฟล์");
 if(file.size>15*1024*1024)throw new Error("ไฟล์ต้องไม่เกิน 15 MB");
 if(!["image/jpeg","image/png","image/webp","application/pdf"].includes(file.type))throw new Error("รองรับ PDF/JPG/PNG/WEBP");
 const {data:r}=await supabase.from("supplier_rmas").select("organization_id").eq("id",id).single();
 if(!r)throw new Error("ไม่พบ RMA");
 const admin=createAdminClient();const bytes=Buffer.from(await file.arrayBuffer());
 const sha256=crypto.createHash("sha256").update(bytes).digest("hex");
 const safe=file.name.replace(/[^A-Za-z0-9._-]+/g,"-").slice(0,100)||"evidence";
 const path=`${m.organization_id}/rma/${id}/${Date.now()}-${safe}`;
 const {error:up}=await admin.storage.from("business-documents").upload(path,bytes,{contentType:file.type,upsert:false});
 if(up)throw new Error(up.message);
 const {error:db}=await admin.from("supplier_rma_evidence").insert({
  organization_id:m.organization_id,supplier_rma_id:id,storage_path:path,
  original_name:file.name,mime_type:file.type,file_size:file.size,sha256,
  category:String(formData.get("category")||"evidence"),note:String(formData.get("note")||""),
  uploaded_by:user?.id
 });
 if(db)throw new Error(db.message);
 revalidatePath("/procurement/rma/"+id);
}
