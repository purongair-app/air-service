import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { shipRma,creditRma,uploadRmaEvidence } from "./actions";
import RmaReplacementForm from "@/components/rma-replacement-form";

export default async function RmaDetail({params}:{params:Promise<{id:string}>}){
 const {id}=await params;const supabase=await createClient();
 const {data:r}=await supabase.from("supplier_rmas").select("*,suppliers(*),goods_receipts(goods_receipt_no),jobs(work_no),supplier_bills(bill_no)").eq("id",id).maybeSingle();
 if(!r)notFound();
 const [{data:items=[]},{data:bins=[]},{data:bills=[]},{data:credits=[]},{data:evidence=[]}]=await Promise.all([
  supabase.from("supplier_rma_items").select("*,inventory_items(sku,name,unit),warehouse_bins(code,warehouses(code))").eq("supplier_rma_id",id),
  supabase.from("warehouse_bins").select("id,code,warehouses(code)").eq("organization_id",r.organization_id).eq("active",true).order("code"),
  supabase.from("supplier_bills").select("id,bill_no,total,status").eq("supplier_id",r.supplier_id).neq("status","cancelled").order("bill_date",{ascending:false}),
  supabase.from("supplier_credit_notes").select("*").eq("supplier_rma_id",id).order("credit_date",{ascending:false}),
  supabase.from("supplier_rma_evidence").select("*").eq("supplier_rma_id",id).order("uploaded_at",{ascending:false})
 ]);
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">{r.rma_no}</h1><p className="muted">{r.suppliers?.name} · {r.status} · {r.resolution_type}</p></div><a className="btn light" href="/procurement/rma">กลับ</a></div>
  <section className="grid cards">
   <div className="card"><div className="muted">Claim Value</div><div className="kpi">{Number(r.claimed_value||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">Goods Receipt</div><div className="kpi" style={{fontSize:18}}>{r.goods_receipts?.goods_receipt_no||"-"}</div></div>
   <div className="card"><div className="muted">Job</div><div className="kpi" style={{fontSize:18}}>{r.jobs?.work_no||"-"}</div></div>
  </section>
  <section className="card" style={{marginTop:16}}><h3>รายการเคลม</h3><div className="table-wrap"><table><thead><tr><th>สินค้า</th><th>Bin</th><th>Claim</th><th>Shipped</th><th>Replacement</th><th>ต้นทุน</th><th>ปัญหา</th></tr></thead><tbody>
   {items.map((x:any)=><tr key={x.id}><td>{x.inventory_items?.sku} · {x.inventory_items?.name}</td><td>{x.warehouse_bins?.warehouses?.code}/{x.warehouse_bins?.code}</td><td>{x.quantity_claimed}</td><td>{x.quantity_shipped}</td><td>{x.quantity_replacement_received}</td><td>{Number(x.unit_cost||0).toLocaleString()}</td><td>{x.fault_description||"-"}</td></tr>)}
  </tbody></table></div></section>

  {r.status==="submitted"&&<section className="card" style={{marginTop:16}}><h3>ส่ง RMA ไป Supplier</h3><form action={shipRma} className="form-grid"><input type="hidden" name="rma_id" value={r.id}/><label>Supplier RMA/Reference<input name="supplier_reference"/></label><div><button className="btn primary">ยืนยันส่งเคลมและตัด Stock</button></div></form></section>}

  {["shipped","replacement_partial"].includes(r.status)&&r.resolution_type==="replacement"&&<section className="card" style={{marginTop:16}}><h3>รับสินค้าทดแทน</h3><RmaReplacementForm rmaId={r.id} items={items} bins={bins}/></section>}

  {["shipped","replacement_partial"].includes(r.status)&&r.resolution_type==="credit"&&<section className="card" style={{marginTop:16}}><h3>รับ Supplier Credit</h3><form action={creditRma} className="form-grid">
   <input type="hidden" name="rma_id" value={r.id}/><label>A/P Bill<select name="bill_id" required>{bills.map((b:any)=><option key={b.id} value={b.id}>{b.bill_no} · {b.status}</option>)}</select></label>
   <label>ยอด Credit<input type="number" step="0.01" min="0.01" max={r.claimed_value} name="amount" defaultValue={r.claimed_value} required/></label>
   <label>เลข Credit Supplier<input name="supplier_reference"/></label><label>เหตุผล<input name="reason" defaultValue={r.reason}/></label>
   <div><button className="btn primary">บันทึก Supplier Credit</button></div>
  </form></section>}

  {!!credits.length&&<section className="card" style={{marginTop:16}}><h3>Credit ที่เชื่อม</h3>{credits.map((c:any)=><div className="badge" key={c.id}>{c.credit_note_no} · {Number(c.amount).toLocaleString()} · {c.supplier_reference||"-"}</div>)}</section>}
  <section className="card" style={{marginTop:16}}><h3>RMA Evidence / Photos</h3>
   <form action={uploadRmaEvidence} className="form-grid"><input type="hidden" name="rma_id" value={r.id}/><label>ประเภท<select name="category"><option value="defect">รูปของเสีย</option><option value="packing">ก่อนส่ง Supplier</option><option value="shipping">หลักฐานขนส่ง</option><option value="replacement">ของทดแทน</option><option value="evidence">อื่น ๆ</option></select></label><label>ไฟล์<input type="file" name="attachment" accept="image/jpeg,image/png,image/webp,application/pdf" required/></label><label>หมายเหตุ<input name="note"/></label><div><button className="btn light">อัปโหลด Evidence</button></div></form>
   <div className="grid">{evidence.map((e:any)=><div className="card" key={e.id}><b>{e.category}</b><div>{e.original_name||"Evidence"}</div><div className="muted">SHA256 {String(e.sha256||"").slice(0,12)}…</div><a className="btn light" target="_blank" href={"/api/private-file?bucket=business-documents&path="+encodeURIComponent(e.storage_path)}>เปิดไฟล์</a></div>)}{!evidence.length&&<div className="muted">ยังไม่มีหลักฐาน RMA</div>}</div>
  </section>
 </AppShell>
}
