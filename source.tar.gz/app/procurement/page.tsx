import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { createPurchaseOrder } from "./actions";

export default async function Procurement(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:rows=[]},{data:suppliers=[]}]=await Promise.all([
  supabase.from("purchase_orders").select("*,suppliers(name)").eq("organization_id",m.organization_id).order("created_at",{ascending:false}),
  supabase.from("suppliers").select("id,supplier_no,name,payment_terms_days").eq("organization_id",m.organization_id).eq("active",true).order("name")
 ]);
 return <AppShell>
  <h1 className="page-title">จัดซื้อ / Purchase Orders</h1>
  <section className="card" style={{marginBottom:16}}><form action={createPurchaseOrder} className="form-grid">
   <label>ผู้ขาย<select name="supplier_id" required><option value="">เลือกผู้ขาย</option>{suppliers.map((s:any)=><option key={s.id} value={s.id}>{s.supplier_no} · {s.name}</option>)}</select></label>
   <label>วันที่สั่งซื้อ<input type="date" name="order_date" required/></label>
   <label>คาดว่าจะได้รับ<input type="date" name="expected_date"/></label>
   <label>VAT %<input type="number" step="0.01" min="0" name="vat_rate" defaultValue="7"/></label>
   <label style={{gridColumn:"1/-1"}}>หมายเหตุ<textarea name="note"/></label>
   <div><button className="btn primary">สร้าง PO</button></div>
  </form></section>
  <div className="table-wrap"><table><thead><tr><th>PO</th><th>ผู้ขาย</th><th>วันที่</th><th>รับของ</th><th>ยอด</th><th>สถานะ</th></tr></thead><tbody>
   {rows.map((r:any)=><tr key={r.id}><td><a href={"/procurement/"+r.id}><b>{r.purchase_order_no}</b></a></td><td>{r.suppliers?.name}</td><td>{r.order_date}</td><td>{r.expected_date||"-"}</td><td>{Number(r.total||0).toLocaleString()}</td><td>{r.status}</td></tr>)}
  </tbody></table></div>
 </AppShell>
}
