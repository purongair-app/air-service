"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function createPurchaseOrder(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
 const {data:no,error:noErr}=await supabase.rpc("next_procurement_number",{p_org:m.organization_id,p_code:"PO"});
 if(noErr)throw new Error(noErr.message);
 const {data:po,error}=await supabase.from("purchase_orders").insert({
   organization_id:m.organization_id,purchase_order_no:no,
   supplier_id:String(formData.get("supplier_id")||""),
   order_date:String(formData.get("order_date")||""),
   expected_date:String(formData.get("expected_date")||"")||null,
   vat_rate:Number(formData.get("vat_rate")||0),
   note:String(formData.get("note")||""),created_by:user?.id
 }).select("id").single();
 if(error)throw new Error(error.message);
 redirect("/procurement/"+po.id);
}
