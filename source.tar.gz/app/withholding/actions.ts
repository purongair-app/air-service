"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function createWithholdingCertificate(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
 const docId=String(formData.get("sales_document_id")||"")||null;
 let customerId=String(formData.get("customer_id")||"")||null;

 if(docId&&!customerId){
  const {data:d}=await supabase.from("sales_documents").select("customer_id").eq("id",docId).single();
  customerId=d?.customer_id||null;
 }
 const gross=Number(formData.get("gross_amount")||0);
 const rate=Number(formData.get("withholding_rate")||0);
 const amount=Math.round(gross*rate)/100;

 const no=`WHT-${new Date().toISOString().slice(2,10).replaceAll("-","")}-${Date.now().toString().slice(-4)}`;
 const {error}=await supabase.from("withholding_certificates").insert({
   organization_id:m.organization_id,certificate_no:no,customer_id:customerId,
   sales_document_id:docId,certificate_date:String(formData.get("certificate_date")||""),
   payer_name:String(formData.get("payer_name")||""),payer_tax_id:String(formData.get("payer_tax_id")||""),
   payer_address:String(formData.get("payer_address")||""),
   payee_name:String(formData.get("payee_name")||""),payee_tax_id:String(formData.get("payee_tax_id")||""),
   payee_address:String(formData.get("payee_address")||""),
   income_type:String(formData.get("income_type")||"ค่าบริการ"),
   gross_amount:gross,withholding_rate:rate,withholding_amount:amount,
   note:String(formData.get("note")||""),created_by:user?.id
 });
 if(error)throw new Error(error.message);
 revalidatePath("/withholding");
}
