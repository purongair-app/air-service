import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { createWithholdingCertificate } from "./actions";

export default async function Withholding(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:rows=[]},{data:docs=[]},{data:customers=[]}]=await Promise.all([
  supabase.from("withholding_certificates").select("*").eq("organization_id",m.organization_id).order("certificate_date",{ascending:false}),
  supabase.from("sales_documents").select("id,document_no,customer_id,total").eq("organization_id",m.organization_id).in("status",["issued","partially_paid","paid"]).order("created_at",{ascending:false}).limit(300),
  supabase.from("customers").select("id,customer_no,first_name,last_name,organization_name,tax_id").eq("organization_id",m.organization_id).limit(500)
 ]);
 return <AppShell><h1 className="page-title">หนังสือรับรองหัก ณ ที่จ่าย</h1>
  <section className="card" style={{marginBottom:16}}>
   <form action={createWithholdingCertificate} className="form-grid">
    <label>เอกสารขาย<select name="sales_document_id"><option value="">ไม่ผูกเอกสาร</option>{docs.map((d:any)=><option key={d.id} value={d.id}>{d.document_no} · {Number(d.total||0).toLocaleString()}</option>)}</select></label>
    <label>ลูกค้า<select name="customer_id"><option value="">เลือกจากเอกสาร</option>{customers.map((c:any)=><option key={c.id} value={c.id}>{c.customer_no} · {c.organization_name||[c.first_name,c.last_name].filter(Boolean).join(" ")}</option>)}</select></label>
    <label>วันที่<input type="date" name="certificate_date" required/></label>
    <label>ประเภทเงินได้<input name="income_type" defaultValue="ค่าบริการ"/></label>
    <label>ยอดก่อนหัก<input type="number" step="0.01" name="gross_amount" required/></label>
    <label>อัตราหัก %<input type="number" step="0.01" name="withholding_rate" defaultValue="3"/></label>
    <label>ผู้จ่ายเงิน<input name="payer_name"/></label><label>เลขภาษีผู้จ่าย<input name="payer_tax_id"/></label>
    <label style={{gridColumn:"1/-1"}}>ที่อยู่ผู้จ่าย<textarea name="payer_address"/></label>
    <label>ผู้รับเงิน<input name="payee_name"/></label><label>เลขภาษีผู้รับ<input name="payee_tax_id"/></label>
    <label style={{gridColumn:"1/-1"}}>ที่อยู่ผู้รับ<textarea name="payee_address"/></label>
    <label style={{gridColumn:"1/-1"}}>หมายเหตุ<textarea name="note"/></label>
    <div><button className="btn primary">สร้างรายการ WHT</button></div>
   </form>
   <p className="muted">ฟอร์มนี้เก็บข้อมูลเชิงระบบ ยังไม่ใช่การรับรองรูปแบบหนังสือรับรองภาษีตามกฎหมาย ควรให้ผู้ทำบัญชีตรวจแบบก่อนใช้งานจริง</p>
  </section>
  <div className="table-wrap"><table><thead><tr><th>เลขที่</th><th>วันที่</th><th>ผู้จ่าย</th><th>ผู้รับ</th><th>ฐาน</th><th>%</th><th>หัก</th></tr></thead><tbody>
   {rows.map((r:any)=><tr key={r.id}><td><a href={"/withholding/"+r.id}><b>{r.certificate_no}</b></a></td><td>{r.certificate_date}</td><td>{r.payer_name||"-"}</td><td>{r.payee_name||"-"}</td><td>{Number(r.gross_amount||0).toLocaleString()}</td><td>{r.withholding_rate}</td><td>{Number(r.withholding_amount||0).toLocaleString()}</td></tr>)}
  </tbody></table></div>
 </AppShell>
}
