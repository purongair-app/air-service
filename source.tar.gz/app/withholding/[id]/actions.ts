"use server";
import crypto from "node:crypto";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { renderWithholdingPdf } from "@/lib/documents/withholding-pdf";

export async function generateWithholdingPdf(formData:FormData){
 const id=String(formData.get("id")||"");
 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user)throw new Error("กรุณาเข้าสู่ระบบ");

 const {data:w,error}=await supabase.from("withholding_certificates").select("*").eq("id",id).single();
 if(error||!w)throw new Error(error?.message||"ไม่พบข้อมูล");

 const buffer=await renderWithholdingPdf(w);
 const sha256=crypto.createHash("sha256").update(buffer).digest("hex");
 const {data:last}=await supabase.from("withholding_archives").select("version")
  .eq("withholding_certificate_id",id).order("version",{ascending:false}).limit(1).maybeSingle();
 const version=Number(last?.version||0)+1;
 const safeNo=String(w.certificate_no).replace(/[^A-Za-z0-9._-]+/g,"-");
 const path=`${w.organization_id}/withholding/${w.id}/${safeNo}-v${version}.pdf`;

 const {error:up}=await supabase.storage.from("generated-documents").upload(path,buffer,{
   contentType:"application/pdf",upsert:false
 });
 if(up)throw new Error(up.message);

 const {error:aerr}=await supabase.from("withholding_archives").insert({
   organization_id:w.organization_id,withholding_certificate_id:w.id,certificate_no:w.certificate_no,
   version,storage_path:path,file_size:buffer.length,sha256,snapshot:w,generated_by:user.id
 });
 if(aerr)throw new Error(aerr.message);

 await supabase.from("withholding_certificates").update({archive_path:path}).eq("id",id);
 revalidatePath("/withholding/"+id);
 revalidatePath("/withholding");
 revalidatePath("/portal/withholding");
}
