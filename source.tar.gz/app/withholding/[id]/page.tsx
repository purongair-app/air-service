import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { generateWithholdingPdf } from "./actions";

export default async function WhtDetail({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const supabase=await createClient();
 const [{data:w},{data:archives=[]}]=await Promise.all([
   supabase.from("withholding_certificates").select("*").eq("id",id).maybeSingle(),
   supabase.from("withholding_archives").select("*").eq("withholding_certificate_id",id).order("version",{ascending:false})
 ]);
 if(!w)notFound();
 return <AppShell>
  <h1 className="page-title">{w.certificate_no}</h1>
  <section className="card">
   <div className="form-grid">
    <div><b>วันที่</b><p>{w.certificate_date}</p></div>
    <div><b>ประเภทเงินได้</b><p>{w.income_type||"-"}</p></div>
    <div><b>ผู้จ่าย</b><p>{w.payer_name||"-"}<br/>{w.payer_tax_id||"-"}</p></div>
    <div><b>ผู้รับ</b><p>{w.payee_name||"-"}<br/>{w.payee_tax_id||"-"}</p></div>
    <div><b>ฐาน</b><p>{Number(w.gross_amount||0).toLocaleString()}</p></div>
    <div><b>หัก</b><p>{w.withholding_rate}% = {Number(w.withholding_amount||0).toLocaleString()}</p></div>
   </div>
   <form action={generateWithholdingPdf}><input type="hidden" name="id" value={w.id}/><button className="btn primary">สร้าง PDF Archive</button></form>
   <p className="muted">PDF นี้เป็นเอกสารจากระบบสำหรับ workflow ภายใน ต้องให้ผู้ทำบัญชีตรวจแบบก่อนใช้เป็นเอกสารภาษีจริง</p>
  </section>
  <section className="grid" style={{marginTop:16}}>
   {archives.map((a:any)=><div className="card" key={a.id}><b>Version {a.version}</b><div className="muted">{new Date(a.generated_at).toLocaleString("th-TH")} · {String(a.sha256).slice(0,12)}…</div><a className="btn light" target="_blank" href={"/api/private-file?bucket=generated-documents&path="+encodeURIComponent(a.storage_path)}>เปิด PDF</a></div>)}
  </section>
 </AppShell>
}
