import AppShell from "@/components/app-shell";
import BarcodeScanner from "@/components/barcode-scanner";
import { getCurrentMembership } from "@/lib/org";

export default async function StockScan(){
 const m=await getCurrentMembership(); if(!m)return null;
 return <AppShell><h1 className="page-title">Barcode / QR Stock Scan</h1><p className="muted">สแกนเพื่อค้นหาสินค้าและตรวจยอดคงเหลือ รองรับกรอกรหัส/ยิงจากเครื่องสแกนเป็น fallback</p><BarcodeScanner organizationId={m.organization_id}/></AppShell>
}
