import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function InventoryPage(){
 const member=await getCurrentMembership(); const supabase=await createClient();
 const {data=[]}=member?await supabase.from("inventory_items").select("id,sku,name,unit,quantity,reorder_point,cost,price").eq("organization_id",member.organization_id).order("name"):{data:[]};
 return <AppShell><h1 className="page-title">คลังสินค้า</h1><p className="muted">สต็อก อะไหล่ และวัสดุสิ้นเปลือง</p>
 <div className="table-wrap"><table><thead><tr><th>SKU</th><th>สินค้า</th><th>คงเหลือ</th><th>จุดสั่งซื้อ</th><th>ต้นทุน</th><th>ราคาขาย</th></tr></thead><tbody>
 {data.map((x:any)=><tr key={x.id}><td>{x.sku}</td><td>{x.name}</td><td>{x.quantity} {x.unit}</td><td>{x.reorder_point}</td><td>{x.cost}</td><td>{x.price}</td></tr>)}
 </tbody></table>{!data.length&&<div className="empty">ยังไม่มีสินค้าในคลัง</div>}</div></AppShell>
}
