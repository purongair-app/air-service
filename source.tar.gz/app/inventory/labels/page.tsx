import PrintButton from "@/components/print-button";
import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import bwipjs from "bwip-js";

function imageData(code:string,bcid:"code128"|"qrcode"){
 try{
  const svg=bwipjs.toSVG({bcid,text:code,scale:2,height:bcid==="code128"?12:20,includetext:bcid==="code128",textxalign:"center"});
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
 }catch{return "";}
}

export default async function Labels({searchParams}:{searchParams:Promise<{q?:string}>}){
 const sp=await searchParams; const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 let q=supabase.from("inventory_items").select("id,sku,name,unit,barcode,qr_code").eq("organization_id",m.organization_id).order("name").limit(100);
 if(sp.q)q=q.or(`sku.ilike.%${sp.q}%,name.ilike.%${sp.q}%,barcode.ilike.%${sp.q}%`);
 const {data=[]}=await q;
 return <AppShell><h1 className="page-title">พิมพ์ Barcode / QR Labels</h1>
  <form className="actions" method="get"><input name="q" defaultValue={sp.q||""} placeholder="ค้นหา SKU / ชื่อ / Barcode"/><button className="btn primary">ค้นหา</button><PrintButton label="พิมพ์ Labels"/></form>
  <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(220px,1fr))",gap:12,marginTop:16}}>
   {data.map((x:any)=>{const code=x.barcode||x.sku;const qr=x.qr_code||x.sku;return <div key={x.id} style={{border:"1px solid #bbb",padding:12,textAlign:"center",breakInside:"avoid"}}>
    <b>{x.name}</b><div>{x.sku}</div>{imageData(code,"code128")&&<img alt={code} src={imageData(code,"code128")} style={{maxWidth:"100%",height:60,objectFit:"contain"}}/>}{imageData(qr,"qrcode")&&<img alt={qr} src={imageData(qr,"qrcode")} style={{width:100,height:100,objectFit:"contain"}}/>}<small>{code}</small>
   </div>})}
  </div>
 </AppShell>
}
