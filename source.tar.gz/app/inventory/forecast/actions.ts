"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function seedForecastDefaults(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient();
 const {error}=await supabase.rpc("seed_inventory_forecast_defaults",{p_org:m.organization_id});
 if(error)throw new Error(error.message);
 revalidatePath("/inventory/forecast");
}

export async function saveForecastSettings(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient();
 const row={
  organization_id:m.organization_id,
  target_coverage_days:Number(formData.get("target_coverage_days")||60),
  safety_days:Number(formData.get("safety_days")||14),
  default_lead_time_days:Number(formData.get("default_lead_time_days")||7),
  seasonal_factor_min:Number(formData.get("seasonal_factor_min")||0.5),
  seasonal_factor_max:Number(formData.get("seasonal_factor_max")||2),
  annual_carrying_cost_pct:Number(formData.get("annual_carrying_cost_pct")||20),
  slow_stock_provision_pct:Number(formData.get("slow_stock_provision_pct")||25),
  dead_stock_provision_pct:Number(formData.get("dead_stock_provision_pct")||75),
  updated_at:new Date().toISOString()
 };
 if(row.target_coverage_days<=0||row.safety_days<0||row.default_lead_time_days<0||
    row.seasonal_factor_min<=0||row.seasonal_factor_max<row.seasonal_factor_min||
    row.slow_stock_provision_pct<0||row.dead_stock_provision_pct<row.slow_stock_provision_pct){
   throw new Error("ค่าตั้งค่า Forecast ไม่ถูกต้อง");
 }
 const {error}=await supabase.from("inventory_forecast_settings").upsert(row,{onConflict:"organization_id"});
 if(error)throw new Error(error.message);
 revalidatePath("/inventory/forecast");
}

export async function saveSupplierTerms(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient();
 const itemId=String(formData.get("inventory_item_id")||"");
 const supplierId=String(formData.get("supplier_id")||"");
 const preferred=formData.get("preferred")==="on";

 if(preferred){
  await supabase.from("inventory_supplier_terms")
    .update({preferred:false})
    .eq("organization_id",m.organization_id)
    .eq("inventory_item_id",itemId);
 }

 const {error}=await supabase.from("inventory_supplier_terms").upsert({
  organization_id:m.organization_id,
  inventory_item_id:itemId,
  supplier_id:supplierId,
  preferred,
  lead_time_days:Number(formData.get("lead_time_days")||7),
  minimum_order_quantity:Number(formData.get("minimum_order_quantity")||0),
  order_multiple:Number(formData.get("order_multiple")||1),
  quoted_unit_cost:Number(formData.get("quoted_unit_cost")||0)||null,
  supplier_sku:String(formData.get("supplier_sku")||"")||null,
  note:String(formData.get("note")||"")||null,
  updated_at:new Date().toISOString()
 },{onConflict:"organization_id,inventory_item_id,supplier_id"});
 if(error)throw new Error(error.message);
 revalidatePath("/inventory/forecast");
}

export async function createForecastPo(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supplierId=String(formData.get("supplier_id")||"");
 let items:any[]=[];
 try{items=JSON.parse(String(formData.get("items_json")||"[]"))}catch{throw new Error("ข้อมูลสั่งซื้อไม่ถูกต้อง")}
 if(!supplierId||!items.length)throw new Error("กรุณาเลือก Supplier และสินค้า");

 const supabase=await createClient();
 const {data,error}=await supabase.rpc("create_reorder_purchase_order",{
  p_org:m.organization_id,p_supplier:supplierId,p_items:items
 });
 if(error)throw new Error(error.message);
 redirect("/procurement/"+data.id);
}
