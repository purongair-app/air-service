import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import ForecastOrderBuilder from "@/components/forecast-order-builder";
import { seedForecastDefaults,saveForecastSettings,saveSupplierTerms } from "./actions";

export default async function Forecast(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:rows=[]},{data:settings},{data:suppliers=[]},{data:items=[]},{data:terms=[]},{data:provisions=[]}]=await Promise.all([
  supabase.from("inventory_demand_forecast").select("*").eq("organization_id",m.organization_id).order("suggested_order_value",{ascending:false}),
  supabase.from("inventory_forecast_settings").select("*").eq("organization_id",m.organization_id).maybeSingle(),
  supabase.from("suppliers").select("id,name").eq("organization_id",m.organization_id).eq("active",true).order("name"),
  supabase.from("inventory_items").select("id,sku,name").eq("organization_id",m.organization_id).order("name").limit(1000),
  supabase.from("inventory_supplier_terms").select("*,inventory_items(sku,name),suppliers(name)").eq("organization_id",m.organization_id).order("updated_at",{ascending:false}).limit(200),
  supabase.from("inventory_valuation_provision").select("*").eq("organization_id",m.organization_id)
 ]);
 const totals=(provisions as any[]).reduce((a:any,x:any)=>{
  a.cost+=Number(x.stock_value_at_cost||0);
  a.carry+=Number(x.estimated_annual_carrying_cost||0);
  a.provision+=Number(x.provision_amount||0);
  a.net+=Number(x.net_inventory_value||0);
  return a;
 },{cost:0,carry:0,provision:0,net:0});

 return <AppShell>
  <div className="actions"><div><h1 className="page-title">Demand Forecast / Seasonal Reorder</h1><p className="muted">Forecast จากการใช้ 30/90/180 วัน + Seasonal Factor + Supplier Lead Time</p></div><div className="actions"><a className="btn light" href="/inventory/forecast/accuracy">Forecast Accuracy</a><a className="btn light" href="/inventory/forecast/export">Export Forecast CSV</a>{!settings&&<form action={seedForecastDefaults}><button className="btn primary">สร้าง Forecast Defaults</button></form>}</div></div>

  <section className="grid cards">
   <div className="card"><div className="muted">Stock Cost</div><div className="kpi">{totals.cost.toLocaleString()}</div></div>
   <div className="card"><div className="muted">Carrying Cost/ปี (ประมาณ)</div><div className="kpi">{totals.carry.toLocaleString()}</div></div>
   <div className="card"><div className="muted">Provision Slow/Dead</div><div className="kpi">{totals.provision.toLocaleString()}</div></div>
   <div className="card"><div className="muted">Net Inventory Value</div><div className="kpi">{totals.net.toLocaleString()}</div></div>
  </section>

  <div className="grid" style={{marginTop:16}}>
   <section className="card"><h3>Forecast Settings</h3><form action={saveForecastSettings} className="form-grid">
    <label>Target Coverage (วัน)<input type="number" min="1" max="365" name="target_coverage_days" defaultValue={settings?.target_coverage_days??60}/></label>
    <label>Safety Stock (วัน)<input type="number" min="0" max="180" name="safety_days" defaultValue={settings?.safety_days??14}/></label>
    <label>Default Lead Time<input type="number" min="0" max="365" name="default_lead_time_days" defaultValue={settings?.default_lead_time_days??7}/></label>
    <label>Season Min<input type="number" step="0.01" min="0.1" name="seasonal_factor_min" defaultValue={settings?.seasonal_factor_min??0.5}/></label>
    <label>Season Max<input type="number" step="0.01" min="0.1" name="seasonal_factor_max" defaultValue={settings?.seasonal_factor_max??2}/></label>
    <label>Carrying Cost %/ปี<input type="number" step="0.01" min="0" name="annual_carrying_cost_pct" defaultValue={settings?.annual_carrying_cost_pct??20}/></label>
    <label>Slow Provision %<input type="number" step="0.01" min="0" max="100" name="slow_stock_provision_pct" defaultValue={settings?.slow_stock_provision_pct??25}/></label>
    <label>Dead Provision %<input type="number" step="0.01" min="0" max="100" name="dead_stock_provision_pct" defaultValue={settings?.dead_stock_provision_pct??75}/></label>
    <div><button className="btn light">บันทึก Forecast Settings</button></div>
   </form></section>

   <section className="card"><h3>Supplier Terms ต่อสินค้า</h3><form action={saveSupplierTerms} className="form-grid">
    <label>สินค้า<select name="inventory_item_id">{items.map((i:any)=><option key={i.id} value={i.id}>{i.sku} · {i.name}</option>)}</select></label>
    <label>Supplier<select name="supplier_id">{suppliers.map((s:any)=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
    <label>Lead Time (วัน)<input type="number" min="0" name="lead_time_days" defaultValue="7"/></label>
    <label>MOQ<input type="number" min="0" step="0.001" name="minimum_order_quantity" defaultValue="0"/></label>
    <label>Order Multiple<input type="number" min="0.001" step="0.001" name="order_multiple" defaultValue="1"/></label>
    <label>ราคาล่าสุด/เสนอ<input type="number" min="0" step="0.01" name="quoted_unit_cost"/></label>
    <label>Supplier SKU<input name="supplier_sku"/></label>
    <label><span><input type="checkbox" name="preferred"/> Preferred Supplier</span></label>
    <label style={{gridColumn:"1/-1"}}>หมายเหตุ<input name="note"/></label>
    <div><button className="btn light">บันทึก Supplier Terms</button></div>
   </form></section>
  </div>

  <section className="card" style={{marginTop:16}}><h3>Forecast Order Builder</h3><ForecastOrderBuilder rows={rows} suppliers={suppliers}/></section>

  <section className="card" style={{marginTop:16}}><h3>Supplier Terms ล่าสุด</h3>
   <div className="table-wrap"><table><thead><tr><th>สินค้า</th><th>Supplier</th><th>Preferred</th><th>Lead</th><th>MOQ</th><th>Multiple</th><th>ราคา</th></tr></thead><tbody>
    {terms.map((t:any)=><tr key={t.id}><td>{t.inventory_items?.sku} · {t.inventory_items?.name}</td><td>{t.suppliers?.name}</td><td>{t.preferred?"Yes":"-"}</td><td>{t.lead_time_days}d</td><td>{t.minimum_order_quantity}</td><td>{t.order_multiple}</td><td>{Number(t.quoted_unit_cost||0).toLocaleString()}</td></tr>)}
   </tbody></table></div>
  </section>
 </AppShell>
}
