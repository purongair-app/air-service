import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

const esc=(v:any)=>`"${String(v??"").replaceAll('"','""')}"`;

export async function GET(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))return new NextResponse("Forbidden",{status:403});
 const supabase=await createClient();
 const {data=[],error}=await supabase.from("inventory_demand_forecast").select("*")
  .eq("organization_id",m.organization_id).order("suggested_order_value",{ascending:false});
 if(error)return new NextResponse(error.message,{status:500});
 const head=["sku","name","on_hand","used_30d","used_90d","used_180d","seasonal_factor","forecast_30d","lead_time_days","safety_stock","target_stock","committed_incoming","draft_incoming","supplier_name","suggested_unit_cost","suggested_order_quantity","suggested_order_value","reorder_now"];
 const lines=data.map((x:any)=>head.map(k=>esc(x[k])).join(","));
 return new NextResponse("\uFEFF"+[head.join(","),...lines].join("\n"),{
  headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":'attachment; filename="airfriend-demand-forecast.csv"'}
 });
}
