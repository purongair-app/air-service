"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function captureForecastSnapshot(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const horizon=Number(formData.get("horizon_days")||30);
 const supabase=await createClient();
 const {error}=await supabase.rpc("capture_inventory_forecast_snapshot",{
  p_org:m.organization_id,p_horizon_days:horizon
 });
 if(error)throw new Error(error.message);
 revalidatePath("/inventory/forecast/accuracy");
}
