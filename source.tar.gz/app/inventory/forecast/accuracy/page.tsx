import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { captureForecastSnapshot } from "./actions";

export default async function ForecastAccuracy(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:summary=[]},{data:items=[]},{data:snapshots=[]}]=await Promise.all([
  supabase.from("inventory_forecast_accuracy_summary").select("*").eq("organization_id",m.organization_id).order("horizon_days"),
  supabase.from("inventory_forecast_accuracy_by_item").select("*").eq("organization_id",m.organization_id).order("wape_pct",{ascending:false,nullsFirst:false}).limit(200),
  supabase.from("inventory_forecast_accuracy").select("*").eq("organization_id",m.organization_id).order("snapshot_date",{ascending:false}).limit(300)
 ]);
 const s30=(summary as any[]).find((x:any)=>Number(x.horizon_days)===30);
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">Forecast Accuracy</h1><p className="muted">เก็บ Forecast Snapshot ก่อน แล้วเทียบกับการใช้จริงเมื่อครบ Horizon · ระบบ Dispatch V3.7 capture 30 วันให้อัตโนมัติวันละครั้งแบบ idempotent</p></div>
   <form action={captureForecastSnapshot} className="actions"><select name="horizon_days" defaultValue="30"><option value="7">7 วัน</option><option value="30">30 วัน</option><option value="60">60 วัน</option><option value="90">90 วัน</option></select><button className="btn primary">Capture Snapshot วันนี้</button></form>
  </div>
  <section className="grid cards">
   <div className="card"><div className="muted">Evaluated 30d</div><div className="kpi">{s30?.evaluated_snapshots||0}</div></div>
   <div className="card"><div className="muted">WAPE 30d</div><div className="kpi">{s30?.wape_pct==null?"-":Number(s30.wape_pct).toFixed(1)+"%"}</div></div>
   <div className="card"><div className="muted">Bias 30d</div><div className="kpi">{s30?.bias_pct==null?"-":Number(s30.bias_pct).toFixed(1)+"%"}</div></div>
   <div className="card"><div className="muted">Forecast / Actual</div><div className="kpi" style={{fontSize:18}}>{Number(s30?.forecast_total||0).toFixed(0)} / {Number(s30?.actual_total||0).toFixed(0)}</div></div>
  </section>
  <section className="card" style={{marginTop:16}}><h3>Accuracy by Item</h3>
   <div className="table-wrap"><table><thead><tr><th>SKU</th><th>สินค้า</th><th>Horizon</th><th>Samples</th><th>Forecast</th><th>Actual</th><th>WAPE</th><th>Bias</th></tr></thead><tbody>
    {items.map((x:any)=><tr key={x.inventory_item_id+"-"+x.horizon_days}><td>{x.sku}</td><td>{x.name}</td><td>{x.horizon_days}d</td><td>{x.evaluated_snapshots}</td><td>{Number(x.forecast_total||0).toFixed(1)}</td><td>{Number(x.actual_total||0).toFixed(1)}</td><td>{x.wape_pct==null?"-":Number(x.wape_pct).toFixed(1)+"%"}</td><td>{x.bias_pct==null?"-":Number(x.bias_pct).toFixed(1)+"%"}</td></tr>)}
   </tbody></table>{!items.length&&<div className="empty">ยังไม่มี Snapshot ที่ครบ Horizon</div>}</div>
  </section>
  <section className="card" style={{marginTop:16}}><h3>Snapshots ล่าสุด</h3>
   <div className="table-wrap"><table><thead><tr><th>วันที่</th><th>SKU</th><th>Horizon</th><th>Forecast</th><th>Actual</th><th>Error</th><th>Season</th><th>สถานะ</th></tr></thead><tbody>
    {snapshots.map((x:any)=><tr key={x.snapshot_id}><td>{x.snapshot_date}</td><td>{x.sku}</td><td>{x.horizon_days}d</td><td>{Number(x.forecast_quantity||0).toFixed(2)}</td><td>{x.matured?Number(x.actual_usage||0).toFixed(2):"-"}</td><td>{x.matured?Number(x.error_quantity||0).toFixed(2):"-"}</td><td>×{Number(x.seasonal_factor||1).toFixed(2)}</td><td>{x.matured?"Evaluated":"Waiting"}</td></tr>)}
   </tbody></table></div>
  </section>
 </AppShell>
}
