"use server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function startCycleCount(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient();
 const {data,error}=await supabase.rpc("create_stocktake_for_bin_v2",{
  p_org:m.organization_id,p_bin:String(formData.get("bin_id")||""),
  p_count_type:"cycle",
  p_note:String(formData.get("note")||"สร้างจาก ABC Cycle Count Planner"),
  p_blind_count:true
 });
 if(error){
  if(error.message.includes("open_stocktake_exists_for_bin"))throw new Error("Bin นี้มี Stocktake ที่ยังไม่ปิด");
  throw new Error(error.message);
 }
 redirect("/inventory/stocktake/"+data.id);
}
