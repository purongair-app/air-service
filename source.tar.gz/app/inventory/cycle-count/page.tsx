import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { startCycleCount } from "./actions";

export default async function CycleCountPlanner(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:due=[]},{data:bins=[]}]=await Promise.all([
  supabase.from("inventory_cycle_count_due").select("*").eq("organization_id",m.organization_id).eq("is_due",true)
    .order("abc_class").order("overdue_days",{ascending:false}),
  supabase.from("cycle_count_bin_priority").select("*").eq("organization_id",m.organization_id).gt("due_item_count",0)
    .order("due_a_count",{ascending:false}).order("max_overdue_days",{ascending:false})
 ]);
 return <AppShell>
  <h1 className="page-title">ABC Cycle Count Planner</h1>
  <p className="muted">A นับถี่กว่า B/C; เริ่ม Cycle Count จาก Bin ที่มี Class A หรือเกินกำหนดมากที่สุด</p>
  <section className="card"><h3>Bin ที่ควรนับ</h3>
   <div className="table-wrap"><table><thead><tr><th>Warehouse/Bin</th><th>Due Items</th><th>A</th><th>B</th><th>C</th><th>เกินกำหนดสูงสุด</th><th></th></tr></thead><tbody>
    {bins.map((b:any)=><tr key={b.warehouse_bin_id}><td>{b.warehouse_code}/{b.bin_code}</td><td>{b.due_item_count}</td><td>{b.due_a_count}</td><td>{b.due_b_count}</td><td>{b.due_c_count}</td><td>{b.max_overdue_days} วัน</td><td><form action={startCycleCount}><input type="hidden" name="bin_id" value={b.warehouse_bin_id}/><button className="btn primary">เริ่ม Blind Count</button></form></td></tr>)}
   </tbody></table>{!bins.length&&<div className="empty">ยังไม่มี Bin ที่ถึงรอบนับ</div>}</div>
  </section>
  <section className="card" style={{marginTop:16}}><h3>รายการที่ถึงรอบ</h3>
   <div className="table-wrap"><table><thead><tr><th>Class</th><th>Warehouse/Bin</th><th>SKU</th><th>สินค้า</th><th>Qty</th><th>นับล่าสุด</th><th>รอบ</th><th>เกินกำหนด</th></tr></thead><tbody>
    {due.map((x:any)=><tr key={x.inventory_item_id+"-"+x.warehouse_bin_id}><td><span className="badge">{x.abc_class}</span></td><td>{x.warehouse_code}/{x.bin_code}</td><td>{x.sku}</td><td>{x.name}</td><td>{x.bin_quantity}</td><td>{x.last_approved_at?new Date(x.last_approved_at).toLocaleDateString("th-TH"):"ไม่เคยนับ"}</td><td>{x.interval_days} วัน</td><td>{x.overdue_days} วัน</td></tr>)}
   </tbody></table></div>
  </section>
 </AppShell>
}
