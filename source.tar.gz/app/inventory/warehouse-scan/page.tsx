import AppShell from "@/components/app-shell";
import WarehouseScanOps from "@/components/warehouse-scan-ops";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function WarehouseScan(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:bins=[]},{data:jobs=[]}]=await Promise.all([
  supabase.from("warehouse_bins").select("id,code,warehouses(code)").eq("organization_id",m.organization_id).eq("active",true).order("code"),
  supabase.from("jobs").select("id,work_no,customer_name_snapshot").eq("organization_id",m.organization_id).not("status","in","(completed,cancelled)").order("created_at",{ascending:false}).limit(200)
 ]);
 return <AppShell><h1 className="page-title">Warehouse Scan Operations</h1><p className="muted">Put-away หลังรับ PO, เบิกสินค้าออกจาก Bin หรือย้ายตำแหน่ง โดยใช้ Barcode/QR/SKU</p><WarehouseScanOps organizationId={m.organization_id} bins={bins} jobs={jobs}/></AppShell>
}
