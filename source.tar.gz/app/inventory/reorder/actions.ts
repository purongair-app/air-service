"use server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function createReorderPo(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supplierId=String(formData.get("supplier_id")||"");
 let items:any[]=[]; try{items=JSON.parse(String(formData.get("items_json")||"[]"))}catch{throw new Error("ข้อมูลไม่ถูกต้อง")}
 if(!supplierId||!items.length)throw new Error("กรุณาเลือก Supplier และสินค้า");
 const supabase=await createClient();
 const {data,error}=await supabase.rpc("create_reorder_purchase_order",{
  p_org:m.organization_id,p_supplier:supplierId,p_items:items
 });
 if(error)throw new Error(error.message);
 redirect("/procurement/"+data.id);
}
