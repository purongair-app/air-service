import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import ReorderBuilder from "@/components/reorder-builder";

export default async function Reorder(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:rows=[]},{data:suppliers=[]}]=await Promise.all([
  supabase.from("inventory_reorder_suggestions").select("*").eq("organization_id",m.organization_id).order("suggested_order_quantity",{ascending:false}),
  supabase.from("suppliers").select("id,name").eq("organization_id",m.organization_id).eq("active",true).order("name")
 ]);
 return <AppShell><h1 className="page-title">Reorder Suggestions</h1><p className="muted">คำนวณจาก Min Stock และการเบิกใช้งานย้อนหลัง 90 วัน; PO ที่สร้างจะเป็น Draft และต้องตรวจ/อนุมัติก่อน</p>
  <ReorderBuilder rows={rows} suppliers={suppliers}/>
 </AppShell>
}
