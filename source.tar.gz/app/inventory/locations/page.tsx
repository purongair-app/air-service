import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { addWarehouse,addBin } from "./actions";

export default async function Locations(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:warehouses=[]},{data:bins=[]},{data:stock=[]},{data:summary=[]}]=await Promise.all([
  supabase.from("warehouses").select("*").eq("organization_id",m.organization_id).order("code"),
  supabase.from("warehouse_bins").select("*,warehouses(code,name)").eq("organization_id",m.organization_id).order("code"),
  supabase.from("inventory_bin_stock").select("*,inventory_items(sku,name,unit),warehouse_bins(code,warehouses(code))").eq("organization_id",m.organization_id).gt("quantity",0),
  supabase.from("inventory_location_summary").select("*").eq("organization_id",m.organization_id).gt("unallocated_quantity",0)
 ]);
 return <AppShell><h1 className="page-title">Warehouse / Bin Locations</h1>
  <div className="grid">
   <section className="card"><h3>เพิ่ม Warehouse</h3><form action={addWarehouse} className="form-grid">
    <label>Code<input name="code" required/></label><label>ชื่อ<input name="name" required/></label><label style={{gridColumn:"1/-1"}}>ที่อยู่<textarea name="address"/></label><div><button className="btn primary">เพิ่ม Warehouse</button></div>
   </form></section>
   <section className="card"><h3>เพิ่ม Bin</h3><form action={addBin} className="form-grid">
    <label>Warehouse<select name="warehouse_id">{warehouses.map((w:any)=><option key={w.id} value={w.id}>{w.code} · {w.name}</option>)}</select></label>
    <label>Bin Code<input name="code" required/></label><label>ชื่อ<input name="name"/></label><label>Zone<input name="zone"/></label><label>Barcode<input name="barcode"/></label><div><button className="btn primary">เพิ่ม Bin</button></div>
   </form></section>
  </div>
  <section className="card" style={{marginTop:16}}><h3>Stock ตาม Bin</h3><div className="table-wrap"><table><thead><tr><th>Warehouse/Bin</th><th>SKU</th><th>สินค้า</th><th>จำนวน</th></tr></thead><tbody>
   {stock.map((x:any)=><tr key={x.inventory_item_id+"-"+x.warehouse_bin_id}><td>{x.warehouse_bins?.warehouses?.code}/{x.warehouse_bins?.code}</td><td>{x.inventory_items?.sku}</td><td>{x.inventory_items?.name}</td><td>{x.quantity} {x.inventory_items?.unit||""}</td></tr>)}
  </tbody></table></div></section>
  <section className="card" style={{marginTop:16}}><h3>Stock ยังไม่ได้จัด Bin</h3>{summary.map((x:any)=><div className="badge" key={x.inventory_item_id}>{x.sku} · {x.name} · {x.unallocated_quantity} {x.unit||""}</div>)}{!summary.length&&<div className="muted">Stock ทั้งหมดถูกจัดตำแหน่งแล้ว</div>}</section>
 </AppShell>
}
