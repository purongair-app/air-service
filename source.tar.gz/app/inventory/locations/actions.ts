"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

async function management(){
 const m=await getCurrentMembership(); if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์"); return m;
}

export async function addWarehouse(formData:FormData){
 const m=await management(); const supabase=await createClient();
 const {error}=await supabase.from("warehouses").insert({
  organization_id:m.organization_id,code:String(formData.get("code")||"").toUpperCase(),
  name:String(formData.get("name")||""),address:String(formData.get("address")||"")
 });
 if(error)throw new Error(error.message);revalidatePath("/inventory/locations");
}

export async function addBin(formData:FormData){
 const m=await management(); const supabase=await createClient();
 const {error}=await supabase.from("warehouse_bins").insert({
  organization_id:m.organization_id,warehouse_id:String(formData.get("warehouse_id")||""),
  code:String(formData.get("code")||"").toUpperCase(),name:String(formData.get("name")||""),
  zone:String(formData.get("zone")||""),barcode:String(formData.get("barcode")||"")
 });
 if(error)throw new Error(error.message);revalidatePath("/inventory/locations");
}
