import AppShell from "@/components/app-shell";
import PrintButton from "@/components/print-button";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import bwipjs from "bwip-js";

function qrData(code:string){
 try{
  const svg=bwipjs.toSVG({bcid:"qrcode",text:code,scale:3});
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
 }catch{return "";}
}
function barcodeData(code:string){
 try{
  const svg=bwipjs.toSVG({bcid:"code128",text:code,scale:2,height:12,includetext:true,textxalign:"center"});
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
 }catch{return "";}
}

export default async function BinLabels(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const {data=[]}=await supabase.from("warehouse_bins").select("id,code,name,zone,barcode,warehouses(code,name)").eq("organization_id",m.organization_id).eq("active",true).order("code");
 return <AppShell><div className="actions"><div><h1 className="page-title">พิมพ์ Bin Labels</h1><p className="muted">Barcode + QR สำหรับชั้น/ช่องเก็บสินค้า</p></div><PrintButton label="พิมพ์ Bin Labels"/></div>
  <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:12,marginTop:16}}>
   {data.map((b:any)=>{const code=b.barcode||`${b.warehouses?.code}-${b.code}`;return <div key={b.id} style={{border:"1px solid #bbb",padding:14,textAlign:"center",breakInside:"avoid"}}>
    <div style={{fontSize:18,fontWeight:700}}>{b.warehouses?.code}/{b.code}</div><div>{b.name||b.zone||""}</div>
    {barcodeData(code)&&<img alt={code} src={barcodeData(code)} style={{maxWidth:"100%",height:70,objectFit:"contain"}}/>}
    {qrData(code)&&<img alt={code} src={qrData(code)} style={{width:110,height:110,objectFit:"contain"}}/>}
    <small>{code}</small>
   </div>})}
  </div>
 </AppShell>
}
