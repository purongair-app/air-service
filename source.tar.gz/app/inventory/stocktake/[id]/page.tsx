import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { notFound } from "next/navigation";
import StocktakeCounter from "@/components/stocktake-counter";
import { saveCount,submitStocktake,approveStocktake,rejectStocktake } from "./actions";

export default async function StocktakeDetail({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:st},{data:rows=[]},{data:events=[]}]=await Promise.all([
  supabase.from("stocktakes").select("*,warehouse_bins(code,name,warehouses(code,name))").eq("id",id).maybeSingle(),
  supabase.from("stocktake_count_sheet").select("*").eq("stocktake_id",id).order("sku"),
  supabase.from("stocktake_events").select("*").eq("stocktake_id",id).order("occurred_at",{ascending:false})
 ]);
 if(!st)notFound();
 const uncounted=rows.filter((x:any)=>x.counted_quantity===null).length;
 const varianceRows=rows.filter((x:any)=>Number(x.variance||0)!==0);
 const varianceAbs=varianceRows.reduce((sum:number,x:any)=>sum+Math.abs(Number(x.variance||0)),0);
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">{st.stocktake_no}</h1><p className="muted">{st.warehouse_bins?.warehouses?.code}/{st.warehouse_bins?.code} · {st.count_type} · {st.status} · {st.blind_count?"Blind Count":"Visible Count"}</p></div><a className="btn light" href="/inventory/stocktake">กลับ</a></div>
  <section className="grid cards">
   <div className="card"><div className="muted">รายการ</div><div className="kpi">{rows.length}</div></div>
   <div className="card"><div className="muted">ยังไม่ได้นับ</div><div className="kpi">{uncounted}</div></div>
   <div className="card"><div className="muted">รายการมีผลต่าง</div><div className="kpi">{st.blind_count&&["draft","in_progress"].includes(st.status)?"ซ่อน":varianceRows.length}</div></div>
   <div className="card"><div className="muted">ผลต่างรวม (abs)</div><div className="kpi">{st.blind_count&&["draft","in_progress"].includes(st.status)?"ซ่อน":varianceAbs}</div></div>
  </section>

  {["draft","in_progress"].includes(st.status)&&<StocktakeCounter organizationId={m.organization_id} stocktakeId={st.id}/>}

  <section className="card" style={{marginTop:16}}><h3>รายการตรวจนับ</h3>
   <div className="table-wrap"><table><thead><tr><th>SKU</th><th>สินค้า</th><th>ระบบ</th><th>นับจริง</th><th>ผลต่าง</th><th>สถานะ</th><th>บันทึก</th></tr></thead><tbody>
    {rows.map((x:any)=><tr key={x.stocktake_item_id}><td>{x.sku}</td><td>{x.name}</td><td>{x.expected_quantity===null?"•••":x.expected_quantity}</td><td>{x.counted_quantity===null?"-":x.counted_quantity}</td><td><b>{x.variance===null?(st.blind_count&&["draft","in_progress"].includes(st.status)?"•••":"-"):x.variance}</b></td><td>{x.variance_status}</td><td>
      {["draft","in_progress"].includes(st.status)&&<form action={saveCount} className="actions"><input type="hidden" name="stocktake_id" value={st.id}/><input type="hidden" name="item_id" value={x.inventory_item_id}/><input style={{width:100}} type="number" step="0.001" min="0" name="counted_quantity" defaultValue={x.counted_quantity??""} required/><input style={{width:160}} name="note" defaultValue={x.note||""}/><button className="btn light">บันทึก</button></form>}
    </td></tr>)}
   </tbody></table></div>
   {["draft","in_progress"].includes(st.status)&&<form action={submitStocktake} style={{marginTop:12}}><input type="hidden" name="stocktake_id" value={st.id}/><button className="btn primary" disabled={uncounted>0}>ส่งผลตรวจนับเพื่ออนุมัติ</button></form>}
  </section>

  {st.status==="submitted"&&["owner","manager"].includes(m.role)&&<section className="card" style={{marginTop:16}}><h3>อนุมัติผลต่าง</h3>
   <p className="muted">เมื่ออนุมัติ ระบบจะปรับยอด Bin และ Stock รวม พร้อมสร้าง Inventory Adjustment/Audit ทันที</p>
   <div className="form-grid">
    <form action={approveStocktake}><input type="hidden" name="stocktake_id" value={st.id}/><label>ความเห็น<input name="comment"/></label><button className="btn primary">อนุมัติและปรับ Stock</button></form>
    <form action={rejectStocktake}><input type="hidden" name="stocktake_id" value={st.id}/><label>เหตุผลปฏิเสธ<input name="reason" required/></label><button className="btn light">ปฏิเสธ</button></form>
   </div>
  </section>}

  <section className="card" style={{marginTop:16}}><h3>Audit</h3>{events.map((e:any)=><div key={e.id} style={{borderBottom:"1px solid #eee",padding:"8px 0"}}><b>{e.event}</b> · {e.detail||"-"}<div className="muted">{new Date(e.occurred_at).toLocaleString("th-TH")}</div></div>)}</section>
 </AppShell>
}
