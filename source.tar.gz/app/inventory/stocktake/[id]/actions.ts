"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

async function member(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 return m;
}

export async function saveCount(formData:FormData){
 await member(); const supabase=await createClient();
 const stocktakeId=String(formData.get("stocktake_id")||"");
 const itemId=String(formData.get("item_id")||"");
 const {error}=await supabase.rpc("record_stocktake_count",{
  p_stocktake:stocktakeId,p_item:itemId,
  p_counted:Number(formData.get("counted_quantity")||0),
  p_note:String(formData.get("note")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/inventory/stocktake/"+stocktakeId);
}

export async function submitStocktake(formData:FormData){
 await member(); const supabase=await createClient();
 const id=String(formData.get("stocktake_id")||"");
 const {error}=await supabase.rpc("submit_stocktake",{p_stocktake:id});
 if(error){
  if(error.message.includes("uncounted_items_remain"))throw new Error("ยังมีรายการที่ยังไม่ได้ตรวจนับ");
  throw new Error(error.message);
 }
 revalidatePath("/inventory/stocktake/"+id);
}

export async function approveStocktake(formData:FormData){
 const m=await member();
 if(!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient(); const id=String(formData.get("stocktake_id")||"");
 const {error}=await supabase.rpc("approve_stocktake",{
  p_stocktake:id,p_comment:String(formData.get("comment")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/inventory/stocktake/"+id);revalidatePath("/inventory");revalidatePath("/inventory/locations");
}

export async function rejectStocktake(formData:FormData){
 const m=await member();
 if(!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient(); const id=String(formData.get("stocktake_id")||"");
 const {error}=await supabase.rpc("reject_stocktake",{
  p_stocktake:id,p_reason:String(formData.get("reason")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/inventory/stocktake/"+id);
}
