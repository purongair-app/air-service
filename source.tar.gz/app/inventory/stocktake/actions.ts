"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

async function management(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 return m;
}

export async function createStocktake(formData:FormData){
 const m=await management(); const supabase=await createClient();
 const {data,error}=await supabase.rpc("create_stocktake_for_bin_v2",{
  p_org:m.organization_id,p_bin:String(formData.get("bin_id")||""),
  p_count_type:String(formData.get("count_type")||"cycle"),
  p_note:String(formData.get("note")||""),
  p_blind_count:formData.get("blind_count")==="on"
 });
 if(error){
  if(error.message.includes("open_stocktake_exists_for_bin"))throw new Error("Bin นี้มี Stocktake ที่ยังไม่ปิดอยู่");
  throw new Error(error.message);
 }
 redirect("/inventory/stocktake/"+data.id);
}
