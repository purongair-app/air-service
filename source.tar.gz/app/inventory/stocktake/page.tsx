import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { createStocktake } from "./actions";

export default async function Stocktake(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:bins=[]},{data:rows=[]}]=await Promise.all([
  supabase.from("warehouse_bins").select("id,code,name,zone,warehouses(code,name)").eq("organization_id",m.organization_id).eq("active",true).order("code"),
  supabase.from("stocktakes").select("*,warehouse_bins(code,warehouses(code))").eq("organization_id",m.organization_id).order("created_at",{ascending:false}).limit(200)
 ]);
 return <AppShell>
  <h1 className="page-title">Stocktake / Cycle Count</h1><p className="muted">Snapshot ยอดใน Bin → ตรวจนับจริง → ส่งอนุมัติ → ปรับผลต่าง</p>
  <section className="card" style={{marginBottom:16}}><form action={createStocktake} className="form-grid">
   <label>Bin<select name="bin_id" required><option value="">เลือก Bin</option>{bins.map((b:any)=><option key={b.id} value={b.id}>{b.warehouses?.code}/{b.code} · {b.name||b.zone||"-"}</option>)}</select></label>
   <label>ประเภท<select name="count_type"><option value="cycle">Cycle Count</option><option value="full">Full Count</option><option value="spot">Spot Check</option></select></label>
   <label><span><input type="checkbox" name="blind_count" defaultChecked/> Blind Count — ซ่อนยอดระบบระหว่างนับ</span></label><label style={{gridColumn:"1/-1"}}>หมายเหตุ<textarea name="note"/></label>
   <div><button className="btn primary">เริ่มตรวจนับ</button></div>
  </form></section>
  <div className="table-wrap"><table><thead><tr><th>เลขที่</th><th>Warehouse/Bin</th><th>ประเภท</th><th>Snapshot</th><th>โหมด</th><th>สถานะ</th></tr></thead><tbody>
   {rows.map((r:any)=><tr key={r.id}><td><a href={"/inventory/stocktake/"+r.id}><b>{r.stocktake_no}</b></a></td><td>{r.warehouse_bins?.warehouses?.code}/{r.warehouse_bins?.code}</td><td>{r.count_type}</td><td>{new Date(r.snapshot_at).toLocaleString("th-TH")}</td><td>{r.blind_count?"Blind":"Visible"}</td><td>{r.status}</td></tr>)}
  </tbody></table>{!rows.length&&<div className="empty">ยังไม่มี Stocktake</div>}</div>
 </AppShell>
}
