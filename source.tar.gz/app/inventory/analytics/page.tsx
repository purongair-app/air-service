import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { seedDefaults,saveAnalysisSettings,saveCycleRules } from "./actions";

export default async function InventoryAnalytics(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:rows=[]},{data:warehouses=[]},{data:settings},{data:rules=[]}]=await Promise.all([
  supabase.from("inventory_movement_analysis").select("*").eq("organization_id",m.organization_id).order("annualized_usage_value",{ascending:false}),
  supabase.from("warehouse_valuation_summary").select("*").eq("organization_id",m.organization_id).order("value_at_cost",{ascending:false}),
  supabase.from("inventory_analysis_settings").select("*").eq("organization_id",m.organization_id).maybeSingle(),
  supabase.from("inventory_cycle_count_rules").select("*").eq("organization_id",m.organization_id).order("abc_class")
 ]);
 const totals=(rows as any[]).reduce((a:any,x:any)=>{
  a.cost+=Number(x.stock_value_at_cost||0);
  a.sale+=Number(x.stock_value_at_sale||0);
  a[x.abc_class]=(a[x.abc_class]||0)+1;
  a[x.movement_status]=(a[x.movement_status]||0)+1;
  return a;
 },{cost:0,sale:0,A:0,B:0,C:0,dead:0,slow:0,moving:0,low_movement:0,out_of_stock:0});
 const ruleMap=Object.fromEntries((rules as any[]).map((x:any)=>[x.abc_class,x.interval_days]));
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">Inventory Analytics</h1><p className="muted">ABC Classification · Stock Valuation · Slow/Dead Stock</p></div><div className="actions"><a className="btn light" href="/inventory/analytics/export?kind=movement">Export Movement CSV</a><a className="btn light" href="/inventory/analytics/export?kind=valuation">Export Valuation CSV</a>{!settings&&<form action={seedDefaults}><button className="btn primary">สร้างค่าเริ่มต้น</button></form>}</div></div>
  <section className="grid cards">
   <div className="card"><div className="muted">มูลค่า Stock ตามต้นทุน</div><div className="kpi">{totals.cost.toLocaleString()}</div></div>
   <div className="card"><div className="muted">มูลค่าตามราคาขาย</div><div className="kpi">{totals.sale.toLocaleString()}</div></div>
   <div className="card"><div className="muted">Class A</div><div className="kpi">{totals.A}</div></div>
   <div className="card"><div className="muted">Class B</div><div className="kpi">{totals.B}</div></div>
   <div className="card"><div className="muted">Class C</div><div className="kpi">{totals.C}</div></div>
   <div className="card"><div className="muted">Slow / Dead</div><div className="kpi">{totals.slow+totals.dead}</div></div>
  </section>

  <div className="grid" style={{marginTop:16}}>
   <section className="card"><h3>ABC / Movement Settings</h3><form action={saveAnalysisSettings} className="form-grid">
    <label>A cumulative %<input type="number" step="0.01" min="1" max="99" name="abc_a_cumulative_pct" defaultValue={settings?.abc_a_cumulative_pct??80}/></label>
    <label>B cumulative %<input type="number" step="0.01" min="1" max="100" name="abc_b_cumulative_pct" defaultValue={settings?.abc_b_cumulative_pct??95}/></label>
    <label>Slow-moving (วัน)<input type="number" min="1" name="slow_moving_days" defaultValue={settings?.slow_moving_days??90}/></label>
    <label>Dead-stock (วัน)<input type="number" min="2" name="dead_stock_days" defaultValue={settings?.dead_stock_days??180}/></label>
    <div><button className="btn light">บันทึก Settings</button></div>
   </form></section>
   <section className="card"><h3>Cycle Count Frequency</h3><form action={saveCycleRules} className="form-grid">
    <label>Class A ทุกกี่วัน<input type="number" min="1" name="days_A" defaultValue={ruleMap.A??30}/></label>
    <label>Class B ทุกกี่วัน<input type="number" min="1" name="days_B" defaultValue={ruleMap.B??90}/></label>
    <label>Class C ทุกกี่วัน<input type="number" min="1" name="days_C" defaultValue={ruleMap.C??180}/></label>
    <div><button className="btn light">บันทึกรอบนับ</button></div>
   </form></section>
  </div>

  <section className="card" style={{marginTop:16}}><h3>Warehouse Valuation</h3>
   <div className="table-wrap"><table><thead><tr><th>Warehouse</th><th>SKU</th><th>Qty</th><th>มูลค่าต้นทุน</th><th>มูลค่าขาย</th></tr></thead><tbody>
    {warehouses.map((x:any)=><tr key={x.warehouse_id}><td>{x.warehouse_code} · {x.warehouse_name}</td><td>{x.sku_count}</td><td>{x.quantity_total}</td><td>{Number(x.value_at_cost||0).toLocaleString()}</td><td>{Number(x.value_at_sale||0).toLocaleString()}</td></tr>)}
   </tbody></table>{!warehouses.length&&<div className="empty">ยังไม่มี Stock ที่จัด Bin</div>}</div>
  </section>

  <section className="card" style={{marginTop:16}}><h3>ABC / Slow-Dead Stock</h3>
   <div className="table-wrap"><table><thead><tr><th>Class</th><th>SKU</th><th>สินค้า</th><th>คงเหลือ</th><th>ใช้ 90 วัน</th><th>Annual Value</th><th>Last Issue</th><th>ไม่ได้เคลื่อนไหว</th><th>สถานะ</th><th>มูลค่าคงเหลือ</th></tr></thead><tbody>
    {rows.map((x:any)=><tr key={x.inventory_item_id}><td><span className="badge">{x.abc_class}</span></td><td>{x.sku}</td><td>{x.name}</td><td>{x.on_hand} {x.unit||""}</td><td>{x.used_90d}</td><td>{Number(x.annualized_usage_value||0).toLocaleString()}</td><td>{x.last_issue_at?new Date(x.last_issue_at).toLocaleDateString("th-TH"):"-"}</td><td>{x.days_since_last_issue} วัน</td><td>{x.movement_status}</td><td>{Number(x.stock_value_at_cost||0).toLocaleString()}</td></tr>)}
   </tbody></table></div>
  </section>
 </AppShell>
}
