import { NextRequest,NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

const esc=(v:any)=>`"${String(v??"").replaceAll('"','""')}"`;

export async function GET(req:NextRequest){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))return new NextResponse("Forbidden",{status:403});
 const kind=req.nextUrl.searchParams.get("kind")||"movement";
 const supabase=await createClient();

 if(kind==="valuation"){
  const {data=[],error}=await supabase.from("warehouse_stock_valuation").select("*").eq("organization_id",m.organization_id).order("warehouse_code").order("bin_code");
  if(error)return new NextResponse(error.message,{status:500});
  const head=["warehouse","bin","sku","name","unit","quantity","average_cost","value_at_cost","value_at_sale"];
  const body=data.map((x:any)=>[x.warehouse_code,x.bin_code,x.sku,x.name,x.unit,x.quantity,x.average_cost,x.value_at_cost,x.value_at_sale].map(esc).join(","));
  return new NextResponse("\uFEFF"+[head.join(","),...body].join("\n"),{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":'attachment; filename="airfriend-stock-valuation.csv"'}});
 }

 const {data=[],error}=await supabase.from("inventory_movement_analysis").select("*").eq("organization_id",m.organization_id).order("annualized_usage_value",{ascending:false});
 if(error)return new NextResponse(error.message,{status:500});
 const head=["abc_class","sku","name","on_hand","cost","used_30d","used_90d","used_180d","annualized_usage_value","last_issue_at","days_since_last_issue","movement_status","stock_value_at_cost"];
 const body=data.map((x:any)=>head.map(k=>esc(x[k])).join(","));
 return new NextResponse("\uFEFF"+[head.join(","),...body].join("\n"),{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":'attachment; filename="airfriend-inventory-movement.csv"'}});
}
