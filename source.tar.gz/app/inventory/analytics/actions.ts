"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function seedDefaults(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient();
 const {error}=await supabase.rpc("seed_inventory_analysis_defaults",{p_org:m.organization_id});
 if(error)throw new Error(error.message);
 revalidatePath("/inventory/analytics");
 revalidatePath("/inventory/cycle-count");
}

export async function saveAnalysisSettings(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient();
 const a=Number(formData.get("abc_a_cumulative_pct")||80);
 const b=Number(formData.get("abc_b_cumulative_pct")||95);
 const slow=Number(formData.get("slow_moving_days")||90);
 const dead=Number(formData.get("dead_stock_days")||180);
 if(!(a>0&&a<100&&b>a&&b<=100&&slow>0&&dead>slow))throw new Error("ค่าตั้งค่าไม่ถูกต้อง");
 const {error}=await supabase.from("inventory_analysis_settings").upsert({
  organization_id:m.organization_id,abc_a_cumulative_pct:a,abc_b_cumulative_pct:b,
  slow_moving_days:slow,dead_stock_days:dead,updated_at:new Date().toISOString()
 },{onConflict:"organization_id"});
 if(error)throw new Error(error.message);
 revalidatePath("/inventory/analytics");
}

export async function saveCycleRules(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient();
 const rows=["A","B","C"].map(c=>({
  organization_id:m.organization_id,abc_class:c,
  interval_days:Number(formData.get("days_"+c)||({"A":30,"B":90,"C":180} as any)[c]),
  active:true,updated_at:new Date().toISOString()
 }));
 if(rows.some(x=>x.interval_days<=0))throw new Error("จำนวนวันต้องมากกว่า 0");
 const {error}=await supabase.from("inventory_cycle_count_rules").upsert(rows,{onConflict:"organization_id,abc_class"});
 if(error)throw new Error(error.message);
 revalidatePath("/inventory/analytics");
 revalidatePath("/inventory/cycle-count");
}
