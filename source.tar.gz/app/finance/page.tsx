import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function FinancePage(){
 const member=await getCurrentMembership(); const supabase=await createClient(); const org=member?.organization_id;
 const {data=[]}=org?await supabase.from("finance_transactions").select("id,transaction_no,type,party,amount,status,transaction_date,note").eq("organization_id",org).order("transaction_date",{ascending:false}).limit(100):{data:[]};
 const income=data.filter((x:any)=>x.type==="income").reduce((s:number,x:any)=>s+Number(x.amount||0),0);
 const expense=data.filter((x:any)=>x.type==="expense").reduce((s:number,x:any)=>s+Number(x.amount||0),0);
 return <AppShell><h1 className="page-title">การเงิน</h1><p className="muted">รายรับ รายจ่าย และกระแสเงิน</p>
 <section className="grid cards" style={{marginBottom:16}}><div className="card"><div className="muted">รายรับ</div><div className="kpi">{income.toLocaleString()}</div></div><div className="card"><div className="muted">รายจ่าย</div><div className="kpi">{expense.toLocaleString()}</div></div><div className="card"><div className="muted">สุทธิ</div><div className="kpi">{(income-expense).toLocaleString()}</div></div></section>
 <div className="table-wrap"><table><thead><tr><th>เลขรายการ</th><th>วันที่</th><th>ประเภท</th><th>คู่ค้า/ลูกค้า</th><th>ยอด</th><th>สถานะ</th></tr></thead><tbody>
 {data.map((x:any)=><tr key={x.id}><td>{x.transaction_no}</td><td>{x.transaction_date||"-"}</td><td>{x.type}</td><td>{x.party||"-"}</td><td>{Number(x.amount).toLocaleString()}</td><td>{x.status||"-"}</td></tr>)}
 </tbody></table>{!data.length&&<div className="empty">ยังไม่มีรายการการเงิน</div>}</div></AppShell>
}
