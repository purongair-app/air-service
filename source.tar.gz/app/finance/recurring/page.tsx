import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { saveRecurringExpense,runRecurringExpenses } from "./actions";

export default async function Recurring(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:rows=[]},{data:cats=[]}]=await Promise.all([
   supabase.from("recurring_expenses").select("*,finance_categories(name)").eq("organization_id",m.organization_id).order("next_run_date"),
   supabase.from("finance_categories").select("id,name").eq("organization_id",m.organization_id).eq("type","expense").order("name")
 ]);
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">ค่าใช้จ่ายประจำ</h1><p className="muted">ค่าเช่า อินเทอร์เน็ต ค่างวด ซอฟต์แวร์ และรายจ่ายตามรอบ</p></div><form action={runRecurringExpenses}><button className="btn primary">สร้างรายการที่ถึงรอบวันนี้</button></form></div>
  <section className="card" style={{marginBottom:16}}><form action={saveRecurringExpense} className="form-grid">
   <label>ชื่อรายการ<input name="name" required/></label>
   <label>หมวด<select name="category_id"><option value="">-</option>{cats.map((c:any)=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
   <label>คู่ค้า/ผู้รับเงิน<input name="party"/></label>
   <label>จำนวนเงิน<input type="number" step="0.01" name="amount" required/></label>
   <label>ความถี่<select name="frequency"><option value="monthly">รายเดือน</option><option value="quarterly">ทุก 3 เดือน</option><option value="yearly">รายปี</option></select></label>
   <label>รอบถัดไป<input type="date" name="next_run_date" required/></label>
   <label><span><input type="checkbox" name="auto_post"/> บันทึกเป็นจ่ายแล้วอัตโนมัติ</span></label>
   <label>หมายเหตุ<input name="note"/></label>
   <div><button className="btn primary">เพิ่มค่าใช้จ่ายประจำ</button></div>
  </form></section>
  <div className="table-wrap"><table><thead><tr><th>รายการ</th><th>หมวด</th><th>จำนวน</th><th>ความถี่</th><th>รอบถัดไป</th><th>Auto</th><th>สถานะ</th></tr></thead><tbody>
   {rows.map((r:any)=><tr key={r.id}><td>{r.name}</td><td>{r.finance_categories?.name||"-"}</td><td>{Number(r.amount||0).toLocaleString()}</td><td>{r.frequency}</td><td>{r.next_run_date}</td><td>{r.auto_post?"จ่ายแล้ว":"รอตรวจ"}</td><td>{r.active?"Active":"Off"}</td></tr>)}
  </tbody></table></div>
 </AppShell>
}
