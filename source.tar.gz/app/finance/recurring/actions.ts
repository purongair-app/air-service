"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function saveRecurringExpense(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
 const {error}=await supabase.from("recurring_expenses").insert({
  organization_id:m.organization_id,name:String(formData.get("name")||""),
  category_id:String(formData.get("category_id")||"")||null,
  party:String(formData.get("party")||""),amount:Number(formData.get("amount")||0),
  frequency:String(formData.get("frequency")||"monthly"),
  next_run_date:String(formData.get("next_run_date")||""),
  due_day:Number(formData.get("due_day")||0)||null,
  auto_post:formData.get("auto_post")==="on",active:true,
  note:String(formData.get("note")||""),created_by:user?.id
 });
 if(error)throw new Error(error.message);
 revalidatePath("/finance/recurring");
}

export async function runRecurringExpenses(){
 const m=await getCurrentMembership(); if(!m)throw new Error("ไม่มี membership");
 const supabase=await createClient();
 const {error}=await supabase.rpc("generate_recurring_expenses",{p_org:m.organization_id,p_run_date:new Date().toISOString().slice(0,10)});
 if(error)throw new Error(error.message);
 revalidatePath("/finance/recurring"); revalidatePath("/finance");
}
