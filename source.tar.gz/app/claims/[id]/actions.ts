"use server";
import crypto from "node:crypto";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getCurrentMembership } from "@/lib/org";

async function management(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 return m;
}

export async function triageClaim(formData:FormData){
 await management(); const supabase=await createClient();
 const id=String(formData.get("claim_id")||"");
 const assignee=String(formData.get("assigned_to_user_id")||"")||null;
 const {error}=await supabase.rpc("triage_warranty_claim",{
  p_claim:id,p_priority:String(formData.get("priority")||"normal"),
  p_assigned_to:assignee,p_detail:String(formData.get("detail")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/claims/"+id);revalidatePath("/claims");revalidatePath("/control-tower");
}

export async function createClaimJob(formData:FormData){
 await management(); const supabase=await createClient(); const id=String(formData.get("claim_id")||"");
 const {error}=await supabase.rpc("create_job_from_warranty_claim",{
  p_claim:id,p_appointment_date:String(formData.get("appointment_date")||"")||null,
  p_appointment_time_label:String(formData.get("appointment_time_label")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/claims/"+id);revalidatePath("/jobs");revalidatePath("/control-tower");
}

export async function changeClaimStatus(formData:FormData){
 await management(); const supabase=await createClient(); const id=String(formData.get("claim_id")||"");
 const {error}=await supabase.rpc("resolve_warranty_claim",{
  p_claim:id,p_status:String(formData.get("status")||""),
  p_summary:String(formData.get("summary")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/claims/"+id);revalidatePath("/claims");revalidatePath("/control-tower");
}

export async function uploadClaimEvidence(formData:FormData){
 const m=await management(); const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser(); const id=String(formData.get("claim_id")||"");
 const file=formData.get("attachment");
 if(!(file instanceof File)||file.size<=0)throw new Error("กรุณาเลือกไฟล์");
 if(file.size>15*1024*1024)throw new Error("ไฟล์ต้องไม่เกิน 15 MB");
 if(!["image/jpeg","image/png","image/webp","application/pdf"].includes(file.type))throw new Error("รองรับ PDF/JPG/PNG/WEBP");
 const {data:c}=await supabase.from("warranty_claims").select("id,organization_id,customer_id").eq("id",id).single();
 if(!c)throw new Error("ไม่พบเคส");
 const admin=createAdminClient(); const bytes=Buffer.from(await file.arrayBuffer());
 const sha256=crypto.createHash("sha256").update(bytes).digest("hex");
 const safe=file.name.replace(/[^A-Za-z0-9._-]+/g,"-").slice(0,100)||"evidence";
 const path=`${m.organization_id}/warranty-claims/${c.customer_id}/${c.id}/${Date.now()}-staff-${safe}`;
 const {error:up}=await admin.storage.from("business-documents").upload(path,bytes,{contentType:file.type,upsert:false});
 if(up)throw new Error(up.message);
 const {error:db}=await admin.from("warranty_claim_attachments").insert({
  organization_id:m.organization_id,warranty_claim_id:c.id,customer_id:c.customer_id,
  storage_path:path,original_name:file.name,mime_type:file.type,file_size:file.size,sha256,
  category:"staff_evidence",uploaded_by:user?.id
 });
 if(db)throw new Error(db.message);
 revalidatePath("/claims/"+id);
}


export async function recheckEligibility(formData:FormData){
 await management(); const supabase=await createClient();
 const id=String(formData.get("claim_id")||"");
 const {error}=await supabase.rpc("reevaluate_warranty_claim_eligibility",{p_claim:id});
 if(error)throw new Error(error.message);
 revalidatePath("/claims/"+id);
}
