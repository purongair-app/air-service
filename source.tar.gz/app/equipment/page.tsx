import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function EquipmentPage(){
 const member=await getCurrentMembership(); const supabase=await createClient();
 const {data=[]}=member?await supabase.from("customer_equipment")
   .select("id,equipment_no,brand,model,btu,install_location,customers(first_name,last_name,organization_name)")
   .eq("organization_id",member.organization_id).order("created_at",{ascending:false}).limit(100):{data:[]};
 return <AppShell>
  <h1 className="page-title">เครื่องแอร์ลูกค้า</h1><p className="muted">ทะเบียนเครื่อง รุ่น Serial และตำแหน่งติดตั้ง</p>
  <div className="table-wrap"><table><thead><tr><th>รหัส</th><th>ลูกค้า</th><th>ยี่ห้อ</th><th>รุ่น</th><th>BTU</th><th>ตำแหน่ง</th></tr></thead>
  <tbody>{data.map((x:any)=>{const c:any=x.customers||{};return <tr key={x.id}><td>{x.equipment_no||"-"}</td><td>{c.organization_name||[c.first_name,c.last_name].filter(Boolean).join(" ")||"-"}</td><td>{x.brand||"-"}</td><td>{x.model||"-"}</td><td>{x.btu||"-"}</td><td>{x.install_location||"-"}</td></tr>})}</tbody></table>
  {!data.length&&<div className="empty">ยังไม่มีทะเบียนเครื่องแอร์</div>}</div>
 </AppShell>
}
