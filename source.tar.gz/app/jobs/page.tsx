import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { createJob } from "./actions";

const statusLabel:any={new:"รับงานใหม่",awaiting_confirmation:"รอยืนยันนัดหมาย",scheduled:"นัดหมายแล้ว",assigned:"มอบหมายช่างแล้ว",traveling:"กำลังเดินทาง",in_progress:"กำลังดำเนินงาน",waiting_parts:"รออะไหล่",technician_submitted:"ช่างส่งงาน",under_review:"รอตรวจสอบ",completed:"เสร็จสิ้น",cancelled:"ยกเลิก"};

export default async function JobsPage(){
 const member=await getCurrentMembership(); const supabase=await createClient();
 const org=member?.organization_id;
 const [{data:jobs=[]},{data:customers=[]}]=org?await Promise.all([
   supabase.from("jobs").select("id,work_no,customer_name_snapshot,service_name,appointment_date,appointment_time_label,status").eq("organization_id",org).order("created_at",{ascending:false}).limit(100),
   supabase.from("customers").select("id,customer_no,first_name,last_name,organization_name").eq("organization_id",org).order("created_at",{ascending:false}).limit(500)
 ]):[{data:[]},{data:[]}];
 return <AppShell>
  <h1 className="page-title">ใบงานบริการ</h1><p className="muted">รับงาน นัดหมาย และติดตามสถานะงาน</p>
  <div className="card" style={{marginBottom:16}}>
   <form action={createJob} className="form-grid">
    <label>ลูกค้า<select name="customer_id" required><option value="">เลือกลูกค้า</option>{customers.map((c:any)=><option key={c.id} value={c.id}>{c.customer_no} · {c.organization_name||[c.first_name,c.last_name].filter(Boolean).join(" ")}</option>)}</select></label>
    <label>บริการ<select name="service_name"><option>ล้างแอร์</option><option>ซ่อมแอร์</option><option>ติดตั้งแอร์</option><option>ย้ายแอร์</option></select></label>
    <label>วันที่นัด<input name="appointment_date" type="date"/></label>
    <label>ช่วงเวลา<input name="appointment_time_label" placeholder="เช่น 09:00–11:00"/></label>
    <label style={{gridColumn:"1/-1"}}>รายละเอียด<textarea name="note"/></label>
    <div><button className="btn primary">สร้างใบงาน</button></div>
   </form>
  </div>
  <div className="table-wrap"><table><thead><tr><th>ใบงาน</th><th>ลูกค้า</th><th>บริการ</th><th>นัดหมาย</th><th>สถานะ</th></tr></thead>
  <tbody>{jobs.map((j:any)=><tr key={j.id}><td><a href={"/jobs/"+j.id}><b>{j.work_no}</b></a></td><td>{j.customer_name_snapshot}</td><td>{j.service_name}</td><td>{j.appointment_date||"-"} {j.appointment_time_label||""}</td><td><span className="badge">{statusLabel[j.status]||j.status}</span></td></tr>)}</tbody></table>
  {!jobs.length&&<div className="empty">ยังไม่มีใบงาน</div>}</div>
 </AppShell>
}
