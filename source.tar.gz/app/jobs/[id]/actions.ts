"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

async function requireStaff(){
  const member=await getCurrentMembership();
  if(!member || !["owner","manager","admin"].includes(member.role)) throw new Error("ไม่มีสิทธิ์จัดการใบงาน");
  return member;
}

export async function assignTechnician(formData:FormData){
  const member=await requireStaff();
  const supabase=await createClient();
  const jobId=String(formData.get("job_id")||"");
  const employeeId=String(formData.get("employee_id")||"");
  if(!jobId||!employeeId) throw new Error("กรุณาเลือกช่าง");

  const {data:{user}}=await supabase.auth.getUser();
  const {error}=await supabase.from("job_assignments").upsert({
    organization_id:member.organization_id,
    job_id:jobId,
    employee_id:employeeId,
    role_label:String(formData.get("role_label")||"ช่างบริการ"),
    assigned_by:user?.id,
    assigned_at:new Date().toISOString()
  },{onConflict:"job_id,employee_id"});
  if(error) throw new Error(error.message);

  await supabase.from("jobs").update({status:"assigned"}).eq("id",jobId);
  const {data:emp}=await supabase.from("employees").select("full_name").eq("id",employeeId).maybeSingle();
  await supabase.from("job_timeline").insert({
    organization_id:member.organization_id,job_id:jobId,status:"assigned",
    detail:`มอบหมายงานให้ ${emp?.full_name||"ทีมช่าง"}`,
    actor_user_id:user?.id,actor_name:user?.email||"แอดมิน",occurred_at:new Date().toISOString()
  });
  revalidatePath("/jobs/"+jobId);
  revalidatePath("/technician");
}

export async function removeTechnician(formData:FormData){
  await requireStaff();
  const supabase=await createClient();
  const jobId=String(formData.get("job_id")||"");
  const assignmentId=String(formData.get("assignment_id")||"");
  const {error}=await supabase.from("job_assignments").delete().eq("id",assignmentId);
  if(error) throw new Error(error.message);
  revalidatePath("/jobs/"+jobId);
}

export async function attachEquipment(formData:FormData){
  await requireStaff();
  const supabase=await createClient();
  const jobId=String(formData.get("job_id")||"");
  const equipmentId=String(formData.get("equipment_id")||"");
  if(!equipmentId) throw new Error("กรุณาเลือกเครื่องแอร์");
  const {error}=await supabase.from("job_equipment").upsert({job_id:jobId,equipment_id:equipmentId});
  if(error) throw new Error(error.message);
  revalidatePath("/jobs/"+jobId);
}

export async function detachEquipment(formData:FormData){
  await requireStaff();
  const supabase=await createClient();
  const jobId=String(formData.get("job_id")||"");
  const equipmentId=String(formData.get("equipment_id")||"");
  const {error}=await supabase.from("job_equipment").delete().eq("job_id",jobId).eq("equipment_id",equipmentId);
  if(error) throw new Error(error.message);
  revalidatePath("/jobs/"+jobId);
}

export async function issueInventoryToJob(formData:FormData){
  const member=await requireStaff();
  const supabase=await createClient();
  const jobId=String(formData.get("job_id")||"");
  const itemId=String(formData.get("item_id")||"");
  const qty=Number(formData.get("quantity")||0);
  if(!itemId||!Number.isFinite(qty)||qty<=0) throw new Error("จำนวนเบิกไม่ถูกต้อง");

  const {data:item}=await supabase.from("inventory_items")
    .select("id,name,quantity,cost").eq("id",itemId).eq("organization_id",member.organization_id).single();
  if(!item) throw new Error("ไม่พบสินค้า");
  if(Number(item.quantity)<qty) throw new Error(`สต็อก ${item.name} ไม่เพียงพอ`);

  const {data:{user}}=await supabase.auth.getUser();
  const next=Number(item.quantity)-qty;
  const {error:updateError}=await supabase.from("inventory_items").update({quantity:next}).eq("id",itemId);
  if(updateError) throw new Error(updateError.message);

  const {error:txError}=await supabase.from("inventory_transactions").insert({
    organization_id:member.organization_id,
    item_id:itemId,
    job_id:jobId,
    transaction_type:"out",
    quantity:qty,
    unit_cost:Number(item.cost||0),
    source_type:"job_issue",
    source_id:jobId,
    note:"เบิกใช้ในใบงาน",
    occurred_at:new Date().toISOString(),
    created_by:user?.id
  });
  if(txError) throw new Error(txError.message);

  await supabase.from("job_timeline").insert({
    organization_id:member.organization_id,job_id:jobId,
    detail:`เบิกอะไหล่/สินค้า ${item.name} จำนวน ${qty}`,
    actor_user_id:user?.id,actor_name:user?.email||"แอดมิน",occurred_at:new Date().toISOString()
  });
  revalidatePath("/jobs/"+jobId);
  revalidatePath("/inventory");
}

export async function updateJobCosts(formData:FormData){
  await requireStaff();
  const supabase=await createClient();
  const jobId=String(formData.get("job_id")||"");
  const patch={
    estimated_revenue:Number(formData.get("estimated_revenue")||0),
    labor_cost:Number(formData.get("labor_cost")||0),
    misc_cost:Number(formData.get("misc_cost")||0)
  };
  const {error}=await supabase.from("jobs").update(patch).eq("id",jobId);
  if(error) throw new Error(error.message);
  revalidatePath("/jobs/"+jobId);
}

export async function createDocumentFromJob(formData:FormData){
  const member=await requireStaff();
  const supabase=await createClient();
  const jobId=String(formData.get("job_id")||"");
  const documentType=String(formData.get("document_type")||"quote");
  if(!["quote","invoice","receipt"].includes(documentType)) throw new Error("ประเภทเอกสารไม่ถูกต้อง");

  const {data:job}=await supabase.from("jobs")
    .select("id,work_no,customer_id,customer_name_snapshot,service_name,estimated_revenue,amount")
    .eq("id",jobId).single();
  if(!job) throw new Error("ไม่พบใบงาน");

  const {data:docNo,error:noError}=await supabase.rpc("next_document_number",{p_org:member.organization_id,p_type:documentType});
  if(noError) throw new Error(noError.message);
  const total=Number(job.estimated_revenue||job.amount||0);
  const {data:{user}}=await supabase.auth.getUser();

  const {data:doc,error}=await supabase.from("sales_documents").insert({
    organization_id:member.organization_id,
    document_type:documentType,
    document_no:docNo,
    customer_id:job.customer_id,
    job_id:jobId,
    status:documentType==="quote"?"draft":documentType==="invoice"?"issued":"unpaid",
    document_date:new Date().toISOString().slice(0,10),
    subtotal:total,total,
    reference_data:{work_no:job.work_no,customer_name:job.customer_name_snapshot},
    created_by:user?.id
  }).select("id").single();
  if(error) throw new Error(error.message);

  const {error:itemError}=await supabase.from("sales_document_items").insert({
    document_id:doc.id,
    item_type:"service",
    description:job.service_name||`บริการตามใบงาน ${job.work_no}`,
    quantity:1,unit_price:total,discount:0,sort_order:1
  });
  if(itemError) throw new Error(itemError.message);

  revalidatePath("/jobs/"+jobId);
  revalidatePath("/sales");
}
