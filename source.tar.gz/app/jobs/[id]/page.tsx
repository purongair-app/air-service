import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { notFound } from "next/navigation";
import {
 assignTechnician,removeTechnician,attachEquipment,detachEquipment,
 issueInventoryToJob,updateJobCosts,createDocumentFromJob
} from "./actions";

export default async function JobDetail({params}:{params:Promise<{id:string}>}){
 const {id}=await params;
 const member=await getCurrentMembership();
 const supabase=await createClient();
 if(!member) notFound();

 const {data:job}=await supabase.from("jobs").select("*").eq("id",id).eq("organization_id",member.organization_id).maybeSingle();
 if(!job) notFound();

 const [assignmentsRes,employeesRes,eqLinksRes,equipmentRes,inventoryRes,costRes,docsRes] = await Promise.all([
   supabase.from("job_assignments").select("id,employee_id,role_label,accepted_at,employees(full_name,position)").eq("job_id",id),
   supabase.from("employees").select("id,full_name,position,availability_status").eq("organization_id",member.organization_id).neq("employment_status","resigned").order("full_name"),
   supabase.from("job_equipment").select("equipment_id,customer_equipment(id,equipment_no,brand,model,btu,install_location)").eq("job_id",id),
   job.customer_id ? supabase.from("customer_equipment").select("id,equipment_no,brand,model,btu,install_location").eq("customer_id",job.customer_id).order("created_at") : Promise.resolve({data:[]}),
   supabase.from("inventory_items").select("id,sku,name,quantity,unit,cost").eq("organization_id",member.organization_id).gt("quantity",0).order("name"),
   supabase.from("job_cost_summary").select("*").eq("job_id",id).maybeSingle(),
   supabase.from("sales_documents").select("id,document_no,document_type,status,total,document_date").eq("job_id",id).order("created_at",{ascending:false})
 ]);

 const assignments:any[]=assignmentsRes.data||[];
 const employees:any[]=employeesRes.data||[];
 const links:any[]=eqLinksRes.data||[];
 const equipment:any[]=equipmentRes.data||[];
 const inventory:any[]=inventoryRes.data||[];
 const cost:any=costRes.data||{revenue:0,labor_cost:0,misc_cost:0,material_cost:0,gross_profit:0};
 const docs:any[]=docsRes.data||[];

 return <AppShell>
  <div className="topbar">
   <div><h1 className="page-title">{job.work_no}</h1><div className="muted">{job.customer_name_snapshot} · {job.service_name}</div></div>
   <span className="badge">{job.status}</span>
  </div>

  <div className="grid">
   <section className="card">
    <h3>ข้อมูลใบงาน</h3>
    <div className="form-grid">
      <div><b>โทรศัพท์</b><p>{job.phone_snapshot||"-"}</p></div>
      <div><b>นัดหมาย</b><p>{job.appointment_date||"-"} {job.appointment_time_label||""}</p></div>
      <div><b>สถานที่</b><p>{job.address_snapshot||"-"}</p></div>
      <div><b>รายละเอียด</b><p>{job.note||"-"}</p></div>
    </div>
   </section>

   <section className="card">
    <h3>มอบหมายทีมช่าง</h3>
    <form action={assignTechnician} className="form-grid">
      <input type="hidden" name="job_id" value={job.id}/>
      <label>พนักงาน<select name="employee_id" required><option value="">เลือกช่าง</option>{employees.map(e=><option key={e.id} value={e.id}>{e.full_name} · {e.position||"-"}</option>)}</select></label>
      <label>บทบาท<select name="role_label"><option>หัวหน้าทีม</option><option>ช่างบริการ</option><option>ผู้ช่วยช่าง</option></select></label>
      <div><button className="btn primary">เพิ่มเข้าทีมงาน</button></div>
    </form>
    <div style={{marginTop:14}} className="grid">{assignments.map((a:any)=><div key={a.id} className="actions">
      <span className="badge">{a.employees?.full_name||"-"} · {a.role_label||"-"} {a.accepted_at?"✓ รับงานแล้ว":""}</span>
      <form action={removeTechnician}><input type="hidden" name="job_id" value={job.id}/><input type="hidden" name="assignment_id" value={a.id}/><button className="btn light">นำออก</button></form>
    </div>)}</div>
   </section>

   <section className="card">
    <h3>เครื่องแอร์ในใบงาน</h3>
    <form action={attachEquipment} className="actions">
      <input type="hidden" name="job_id" value={job.id}/>
      <select name="equipment_id" required><option value="">เลือกเครื่องของลูกค้า</option>{equipment.map((e:any)=><option key={e.id} value={e.id}>{e.equipment_no||"-"} · {e.brand||"-"} {e.model||""} · {e.btu||"-"} BTU · {e.install_location||"-"}</option>)}</select>
      <button className="btn primary">ผูกเครื่องกับใบงาน</button>
    </form>
    <div className="grid" style={{marginTop:14}}>
      {links.map((x:any)=>{const e=x.customer_equipment||{};return <div key={x.equipment_id} className="actions">
       <span className="badge">{e.equipment_no||"-"} · {e.brand||"-"} {e.model||""} · {e.install_location||"-"}</span>
       <form action={detachEquipment}><input type="hidden" name="job_id" value={job.id}/><input type="hidden" name="equipment_id" value={x.equipment_id}/><button className="btn light">เอาออก</button></form>
      </div>})}
      {!links.length&&<div className="muted">ยังไม่ได้ผูกเครื่องแอร์กับใบงาน</div>}
    </div>
   </section>

   <section className="card">
    <h3>เบิกอะไหล่ / สินค้าเข้าใบงาน</h3>
    <form action={issueInventoryToJob} className="form-grid">
      <input type="hidden" name="job_id" value={job.id}/>
      <label>สินค้า<select name="item_id" required><option value="">เลือกสินค้า</option>{inventory.map((i:any)=><option key={i.id} value={i.id}>{i.sku} · {i.name} · คงเหลือ {i.quantity} {i.unit||""}</option>)}</select></label>
      <label>จำนวน<input name="quantity" type="number" step="0.01" min="0.01" required/></label>
      <div><button className="btn primary">เบิกเข้าหน้างาน</button></div>
    </form>
   </section>

   <section className="card">
    <h3>ต้นทุนและกำไรใบงาน</h3>
    <form action={updateJobCosts} className="form-grid">
      <input type="hidden" name="job_id" value={job.id}/>
      <label>รายได้ประมาณการ<input name="estimated_revenue" type="number" step="0.01" defaultValue={job.estimated_revenue||job.amount||0}/></label>
      <label>ค่าแรง<input name="labor_cost" type="number" step="0.01" defaultValue={job.labor_cost||0}/></label>
      <label>ค่าใช้จ่ายอื่น<input name="misc_cost" type="number" step="0.01" defaultValue={job.misc_cost||0}/></label>
      <div><button className="btn primary">บันทึกต้นทุน</button></div>
    </form>
    <div className="grid cards" style={{marginTop:16}}>
      <div className="card"><div className="muted">รายได้</div><div className="kpi">{Number(cost.revenue||0).toLocaleString()}</div></div>
      <div className="card"><div className="muted">ต้นทุนวัสดุ</div><div className="kpi">{Number(cost.material_cost||0).toLocaleString()}</div></div>
      <div className="card"><div className="muted">ค่าแรง + อื่น ๆ</div><div className="kpi">{(Number(cost.labor_cost||0)+Number(cost.misc_cost||0)).toLocaleString()}</div></div>
      <div className="card"><div className="muted">กำไรขั้นต้น</div><div className="kpi">{Number(cost.gross_profit||0).toLocaleString()}</div></div>
    </div>
   </section>

   <section className="card">
    <h3>เอกสารจากใบงาน</h3>
    <form action={createDocumentFromJob} className="actions">
      <input type="hidden" name="job_id" value={job.id}/>
      <select name="document_type"><option value="quote">ใบเสนอราคา</option><option value="invoice">ใบแจ้งหนี้</option><option value="receipt">ใบเสร็จรับเงิน</option></select>
      <button className="btn primary">สร้างเอกสาร</button>
    </form>
    <div className="table-wrap" style={{marginTop:14}}><table>
      <thead><tr><th>เลขเอกสาร</th><th>ประเภท</th><th>วันที่</th><th>ยอด</th><th>สถานะ</th></tr></thead>
      <tbody>{docs.map((d:any)=><tr key={d.id}><td>{d.document_no}</td><td>{d.document_type}</td><td>{d.document_date}</td><td>{Number(d.total||0).toLocaleString()}</td><td>{d.status}</td></tr>)}</tbody>
    </table>{!docs.length&&<div className="empty">ยังไม่มีเอกสารจากใบงานนี้</div>}</div>
   </section>
  </div>
 </AppShell>
}
