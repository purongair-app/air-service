"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function createJob(formData: FormData) {
  const member=await getCurrentMembership(); if(!member) throw new Error("ไม่พบองค์กร");
  const supabase=await createClient();
  const customerId=String(formData.get("customer_id")||"");
  const {data:customer}=await supabase.from("customers").select("first_name,last_name,organization_name,phone,area").eq("id",customerId).single();
  if(!customer) throw new Error("ไม่พบลูกค้า");
  const {error}=await supabase.from("jobs").insert({
    organization_id:member.organization_id,
    work_no:"AF-"+Date.now().toString().slice(-8),
    customer_id:customerId,
    customer_name_snapshot:customer.organization_name||[customer.first_name,customer.last_name].filter(Boolean).join(" "),
    phone_snapshot:customer.phone,
    service_name:String(formData.get("service_name")||""),
    address_snapshot:customer.area||"",
    appointment_date:String(formData.get("appointment_date")||"")||null,
    appointment_time_label:String(formData.get("appointment_time_label")||""),
    note:String(formData.get("note")||""),
    status:"new",
    received_at:new Date().toISOString()
  });
  if(error) throw new Error(error.message);
  revalidatePath("/jobs");
}
