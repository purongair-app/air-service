"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function paySupplier(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager ที่บันทึกการจ่ายเจ้าหนี้ได้");
 const supabase=await createClient(); const id=String(formData.get("bill_id")||"");
 const {error}=await supabase.rpc("record_supplier_payment",{
  p_bill:id,p_amount:Number(formData.get("amount")||0),
  p_method:String(formData.get("method")||"transfer"),
  p_reference:String(formData.get("reference")||""),
  p_note:String(formData.get("note")||"")
 });
 if(error){
  if(error.message.includes("payment_exceeds_balance"))throw new Error("ยอดจ่ายมากกว่ายอดคงเหลือ");
  throw new Error(error.message);
 }
 revalidatePath("/payables/"+id);revalidatePath("/payables");revalidatePath("/finance");
}


export async function createSupplierCredit(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient(); const billId=String(formData.get("bill_id")||"");
 const retId=String(formData.get("purchase_return_id")||"")||null;
 const {error}=await supabase.rpc("create_supplier_credit_note",{
  p_bill:billId,p_purchase_return:retId,p_amount:Number(formData.get("amount")||0),
  p_supplier_reference:String(formData.get("supplier_reference")||""),
  p_reason:String(formData.get("reason")||"")
 });
 if(error){
  if(error.message.includes("credit_exceeds_balance"))throw new Error("Credit มากกว่ายอดเจ้าหนี้คงเหลือ");
  throw new Error(error.message);
 }
 revalidatePath("/payables/"+billId);revalidatePath("/payables");
}
