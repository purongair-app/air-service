import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { paySupplier,createSupplierCredit } from "./actions";

export default async function PayableDetail({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const supabase=await createClient();
 const {data:b}=await supabase.from("supplier_bills").select("*,suppliers(*),purchase_orders(purchase_order_no)").eq("id",id).maybeSingle();
 if(!b)notFound();
 const [{data:bal},{data:payments=[]},{data:returns=[]},{data:credits=[]}]=await Promise.all([
  supabase.from("supplier_bill_balance").select("*").eq("supplier_bill_id",id).maybeSingle(),
  supabase.from("supplier_payments").select("*").eq("supplier_bill_id",id).order("paid_at",{ascending:false}),
  supabase.from("purchase_returns").select("*").eq("supplier_id",b.supplier_id).eq("status","completed").order("created_at",{ascending:false}).limit(100),
  supabase.from("supplier_credit_notes").select("*").eq("supplier_bill_id",id).order("credit_date",{ascending:false})
 ]);
 return <AppShell><h1 className="page-title">{b.bill_no}</h1><p className="muted">{b.suppliers?.name} · PO {b.purchase_orders?.purchase_order_no||"-"}</p>
  <section className="grid cards">
   <div className="card"><div className="muted">ยอดเจ้าหนี้</div><div className="kpi">{Number(bal?.total||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">จ่ายแล้ว</div><div className="kpi">{Number(bal?.paid_amount||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">Supplier Credit</div><div className="kpi">{Number(bal?.credit_amount||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">คงเหลือ</div><div className="kpi">{Number(bal?.balance||0).toLocaleString()}</div></div>
  </section>
  {Number(bal?.balance||0)>0&&<div className="grid" style={{marginTop:16}}>
   <section className="card"><h3>จ่ายเจ้าหนี้</h3><form action={paySupplier} className="form-grid">
    <input type="hidden" name="bill_id" value={b.id}/>
    <label>จำนวน<input type="number" step="0.01" min="0.01" max={bal?.balance} name="amount" required/></label>
    <label>ช่องทาง<select name="method"><option value="transfer">โอนเงิน</option><option value="cash">เงินสด</option><option value="cheque">เช็ค</option><option value="promptpay">พร้อมเพย์</option></select></label>
    <label>เลขอ้างอิง<input name="reference"/></label><label>หมายเหตุ<input name="note"/></label>
    <div><button className="btn primary">บันทึกจ่าย</button></div>
   </form></section>
   <section className="card"><h3>Supplier Credit Note</h3><form action={createSupplierCredit} className="form-grid">
    <input type="hidden" name="bill_id" value={b.id}/>
    <label>รายการคืน<select name="purchase_return_id"><option value="">ไม่ผูก Return</option>{returns.map((r:any)=><option key={r.id} value={r.id}>{r.purchase_return_no} · {Number(r.total||0).toLocaleString()}</option>)}</select></label>
    <label>ยอด Credit<input type="number" step="0.01" min="0.01" max={bal?.balance} name="amount" required/></label>
    <label>เลข Credit Supplier<input name="supplier_reference"/></label><label>เหตุผล<input name="reason"/></label>
    <div><button className="btn light">บันทึก Credit</button></div>
   </form></section>
  </div>}
  <section className="card" style={{marginTop:16}}><h3>Supplier Credits</h3>{credits.map((c:any)=><div className="badge" key={c.id}>{c.credit_note_no} · {Number(c.amount).toLocaleString()} · {c.supplier_reference||"-"}</div>)}{!credits.length&&<div className="muted">ยังไม่มี Credit</div>}</section>
  <section className="card" style={{marginTop:16}}><h3>ประวัติการจ่าย</h3><div className="table-wrap"><table><thead><tr><th>เลขที่</th><th>วันที่</th><th>จำนวน</th><th>ช่องทาง</th><th>อ้างอิง</th></tr></thead><tbody>
   {payments.map((p:any)=><tr key={p.id}><td>{p.payment_no}</td><td>{new Date(p.paid_at).toLocaleString("th-TH")}</td><td>{Number(p.amount).toLocaleString()}</td><td>{p.method||"-"}</td><td>{p.reference||"-"}</td></tr>)}
  </tbody></table></div></section>
 </AppShell>
}
