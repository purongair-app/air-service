import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function Payables(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const {data=[]}=await supabase.from("accounts_payable_aging").select("*").eq("organization_id",m.organization_id).gt("balance",0).order("days_overdue",{ascending:false});
 const totals=(data as any[]).reduce((a:any,x:any)=>{a.total+=Number(x.balance||0);a[x.aging_bucket]=(a[x.aging_bucket]||0)+Number(x.balance||0);return a},{total:0,current:0,"1-30":0,"31-60":0,"61-90":0,"90+":0});
 return <AppShell><h1 className="page-title">เจ้าหนี้ / Accounts Payable</h1>
  <section className="grid cards">
   <div className="card"><div className="muted">คงค้างรวม</div><div className="kpi">{totals.total.toLocaleString()}</div></div>
   <div className="card"><div className="muted">Current</div><div className="kpi">{totals.current.toLocaleString()}</div></div>
   <div className="card"><div className="muted">1–30</div><div className="kpi">{totals["1-30"].toLocaleString()}</div></div>
   <div className="card"><div className="muted">31–60</div><div className="kpi">{totals["31-60"].toLocaleString()}</div></div>
   <div className="card"><div className="muted">61–90</div><div className="kpi">{totals["61-90"].toLocaleString()}</div></div>
   <div className="card"><div className="muted">90+</div><div className="kpi">{totals["90+"].toLocaleString()}</div></div>
  </section>
  <div className="table-wrap" style={{marginTop:16}}><table><thead><tr><th>Bill</th><th>ผู้ขาย</th><th>Invoice Supplier</th><th>ครบกำหนด</th><th>ยอด</th><th>จ่ายแล้ว</th><th>คงเหลือ</th><th>Aging</th></tr></thead><tbody>
   {data.map((x:any)=><tr key={x.supplier_bill_id}><td><a href={"/payables/"+x.supplier_bill_id}><b>{x.bill_no}</b></a></td><td>{x.supplier_name}</td><td>{x.supplier_invoice_no||"-"}</td><td>{x.due_date||"-"}</td><td>{Number(x.total).toLocaleString()}</td><td>{Number(x.paid_amount).toLocaleString()}</td><td>{Number(x.balance).toLocaleString()}</td><td>{x.aging_bucket}</td></tr>)}
  </tbody></table>{!data.length&&<div className="empty">ไม่มีเจ้าหนี้คงค้าง</div>}</div>
 </AppShell>
}
