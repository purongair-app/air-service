"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function saveFollowup(formData:FormData){
 const m=await getCurrentMembership(); if(!m)throw new Error("ไม่มี membership");
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
 const {error}=await supabase.from("customer_followups").insert({
  organization_id:m.organization_id,customer_id:String(formData.get("customer_id")||""),
  channel:String(formData.get("channel")||"phone"),subject:String(formData.get("subject")||""),
  detail:String(formData.get("detail")||""),owner_user_id:user?.id,priority:String(formData.get("priority")||"normal"),
  status:"open",followup_date:String(formData.get("followup_date")||""),next_followup_date:String(formData.get("followup_date")||""),
  recurring_enabled:formData.get("recurring_enabled")==="on",
  interval_months:Number(formData.get("interval_months")||0)||null,
  advance_notice_days:Number(formData.get("advance_notice_days")||7)
 });
 if(error)throw new Error(error.message); revalidatePath("/followups");
}

export async function addFollowupEvent(formData:FormData){
 const m=await getCurrentMembership(); if(!m)throw new Error("ไม่มี membership");
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
 const id=String(formData.get("followup_id")||"");
 const next=String(formData.get("next_followup_date")||"")||null;
 const {error}=await supabase.from("followup_events").insert({
  organization_id:m.organization_id,followup_id:id,channel:String(formData.get("channel")||"phone"),
  outcome:String(formData.get("outcome")||""),detail:String(formData.get("detail")||""),
  next_followup_date:next,actor_user_id:user?.id
 });
 if(error)throw new Error(error.message);
 await supabase.from("customer_followups").update({next_followup_date:next,status:next?"open":"done"}).eq("id",id);
 revalidatePath("/followups");
}
