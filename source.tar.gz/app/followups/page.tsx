import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { saveFollowup,addFollowupEvent } from "./actions";

export default async function Followups(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:rows=[]},{data:customers=[]}]=await Promise.all([
  supabase.from("customer_followups").select("*,customers(first_name,last_name,organization_name,phone)").eq("organization_id",m.organization_id).order("next_followup_date"),
  supabase.from("customers").select("id,customer_no,first_name,last_name,organization_name").eq("organization_id",m.organization_id).order("created_at",{ascending:false}).limit(500)
 ]);
 return <AppShell><h1 className="page-title">ติดตามลูกค้า</h1>
 <section className="card" style={{marginBottom:16}}><form action={saveFollowup} className="form-grid">
  <label>ลูกค้า<select name="customer_id">{customers.map((c:any)=><option key={c.id} value={c.id}>{c.customer_no} · {c.organization_name||[c.first_name,c.last_name].filter(Boolean).join(" ")}</option>)}</select></label>
  <label>หัวข้อ<input name="subject" required/></label><label>ช่องทาง<select name="channel"><option value="phone">โทรศัพท์</option><option value="line">LINE</option><option value="email">Email</option></select></label>
  <label>ความสำคัญ<select name="priority"><option value="normal">ปกติ</option><option value="high">สูง</option></select></label>
  <label>วันติดตาม<input type="date" name="followup_date" required/></label><label>รอบเดือน<input type="number" name="interval_months" defaultValue="3"/></label>
  <label><span><input type="checkbox" name="recurring_enabled"/> ติดตามตามรอบ</span></label>
  <label>แจ้งล่วงหน้า (วัน)<input type="number" name="advance_notice_days" defaultValue="7"/></label>
  <label style={{gridColumn:"1/-1"}}>รายละเอียด<textarea name="detail"/></label><div><button className="btn primary">เพิ่มรายการติดตาม</button></div>
 </form></section>
 <div className="grid">{rows.map((f:any)=><article className="card" key={f.id}>
  <div className="actions"><b>{f.subject}</b><span className="badge">{f.status}</span></div>
  <h3>{f.customers?.organization_name||[f.customers?.first_name,f.customers?.last_name].filter(Boolean).join(" ")}</h3>
  <div className="muted">{f.customers?.phone||"-"} · นัดถัดไป {f.next_followup_date||"-"}</div><p>{f.detail||""}</p>
  <form action={addFollowupEvent} className="form-grid">
   <input type="hidden" name="followup_id" value={f.id}/>
   <label>ช่องทาง<select name="channel"><option value="phone">โทรศัพท์</option><option value="line">LINE</option><option value="email">Email</option></select></label>
   <label>ผลการติดตาม<input name="outcome" required/></label><label>นัดครั้งถัดไป<input type="date" name="next_followup_date"/></label>
   <label>รายละเอียด<input name="detail"/></label><div><button className="btn light">บันทึกผล</button></div>
  </form>
 </article>)}{!rows.length&&<div className="card empty">ยังไม่มีรายการติดตาม</div>}</div>
 </AppShell>
}
