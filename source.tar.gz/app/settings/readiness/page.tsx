import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function Readiness(){
 const m=await getCurrentMembership(); if(!m)return null;
 const supabase=await createClient();
 const {data,error}=await supabase.rpc("organization_readiness",{p_org:m.organization_id});
 return <AppShell>
  <h1 className="page-title">Production Readiness</h1>
  <p className="muted">ภาพรวมสิ่งที่ต้องผ่านก่อน Go-Live</p>
  {error?<div className="card">{error.message}</div>:<section className="grid cards">
    <div className="card"><div className="muted">Owner active</div><div className="kpi">{data?.owners??0}</div></div>
    <div className="card"><div className="muted">สมาชิก active</div><div className="kpi">{data?.active_members??0}</div></div>
    <div className="card"><div className="muted">Migration errors</div><div className="kpi">{data?.migration_errors??0}</div></div>
    <div className="card"><div className="muted">Storage pending/error</div><div className="kpi">{data?.storage_pending??0}</div></div>
    <div className="card"><div className="muted">Membership ไม่เชื่อม</div><div className="kpi">{data?.unlinked_members??0}</div></div>
    <div className="card"><div className="muted">สถานะ</div><div className="kpi">{data?.ready?"READY":"CHECK"}</div></div>
  </section>}
 </AppShell>
}
