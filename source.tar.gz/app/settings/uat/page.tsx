import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

const expected:any={
 customers:185,equipment:16,jobs:28,timeline:137,job_photos:61,
 employees:5,inventory_items:2,job_checkins:5,audit_logs:2331
};

export default async function UatPage(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:counts},{data:risks=[]},{data:members=[]}]=await Promise.all([
  supabase.from("uat_data_counts").select("*").eq("organization_id",m.organization_id).maybeSingle(),
  supabase.from("uat_open_risks").select("*").eq("organization_id",m.organization_id),
  supabase.from("organization_members").select("id,role,status,employee_id,customer_id").eq("organization_id",m.organization_id)
 ]);
 const rows=Object.keys(expected).map(k=>({key:k,expected:expected[k],actual:Number((counts as any)?.[k]||0)}));
 return <AppShell>
  <h1 className="page-title">UAT & Security Check</h1>
  <p className="muted">ตรวจ baseline หลัง migration และตรวจการเชื่อมบัญชีตาม role</p>
  <section className="card" style={{marginBottom:16}}>
   <h3>Data reconciliation</h3>
   <div className="table-wrap"><table><thead><tr><th>Entity</th><th>เดิม</th><th>Supabase</th><th>ผล</th></tr></thead><tbody>
   {rows.map(r=><tr key={r.key}><td>{r.key}</td><td>{r.expected}</td><td>{r.actual}</td><td><span className="badge">{r.actual===r.expected?"PASS":"CHECK"}</span></td></tr>)}
   </tbody></table></div>
  </section>
  <section className="grid cards" style={{marginBottom:16}}>
   {["owner","manager","admin","technician","customer"].map(role=><div className="card" key={role}><div className="muted">{role}</div><div className="kpi">{members.filter((x:any)=>x.role===role&&x.status==="active").length}</div></div>)}
  </section>
  <section className="card">
   <h3>Open risks</h3>
   <div className="grid">{risks.map((r:any)=><div className="badge" key={r.record_id}>{r.role}: {r.message}</div>)}{!risks.length&&<div className="muted">ไม่พบ membership risk จาก rule ชุดนี้</div>}</div>
  </section>
 </AppShell>
}
