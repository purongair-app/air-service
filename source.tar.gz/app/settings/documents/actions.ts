"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function saveBranding(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role)) throw new Error("เฉพาะเจ้าของ/ผู้จัดการ");
 const supabase=await createClient();
 const {error}=await supabase.from("document_branding").upsert({
  organization_id:m.organization_id,
  bank_name:String(formData.get("bank_name")||""),
  account_name:String(formData.get("account_name")||""),
  account_number:String(formData.get("account_number")||""),
  promptpay_name:String(formData.get("promptpay_name")||""),
  promptpay_number:String(formData.get("promptpay_number")||"")
 },{onConflict:"organization_id"});
 if(error)throw new Error(error.message);
 revalidatePath("/settings/documents");
}
