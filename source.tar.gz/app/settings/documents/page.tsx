import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import BrandingUpload from "@/components/branding-upload";
import { saveBranding } from "./actions";

export default async function DocSettings(){
 const m=await getCurrentMembership(); const supabase=await createClient();
 const {data:b}=m?await supabase.from("document_branding").select("*").eq("organization_id",m.organization_id).maybeSingle():{data:null};
 if(!m)return null;
 return <AppShell>
  <h1 className="page-title">ตั้งค่าเอกสาร</h1><p className="muted">โลโก้ ลายเซ็น QR และบัญชีรับเงิน</p>
  <div className="grid">
   <section className="card form-grid">
    <BrandingUpload organizationId={m.organization_id} kind="logo" label="โลโก้ร้าน"/>
    <BrandingUpload organizationId={m.organization_id} kind="signature" label="ลายเซ็น"/>
    <BrandingUpload organizationId={m.organization_id} kind="qr" label="QR PromptPay"/>
   </section>
   <section className="card">
    <form action={saveBranding} className="form-grid">
     <label>ธนาคาร<input name="bank_name" defaultValue={b?.bank_name||""}/></label>
     <label>ชื่อบัญชี<input name="account_name" defaultValue={b?.account_name||""}/></label>
     <label>เลขบัญชี<input name="account_number" defaultValue={b?.account_number||""}/></label>
     <label>ชื่อพร้อมเพย์<input name="promptpay_name" defaultValue={b?.promptpay_name||""}/></label>
     <label>หมายเลขพร้อมเพย์<input name="promptpay_number" defaultValue={b?.promptpay_number||""}/></label>
     <div><button className="btn primary">บันทึก</button></div>
    </form>
   </section>
  </div>
 </AppShell>
}
