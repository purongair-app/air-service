import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { inviteUser,disableMembership } from "./actions";

export default async function UsersSettings(){
 const m=await getCurrentMembership(); if(!m)return null;
 const supabase=await createClient();
 const [membersRes,employeesRes,customersRes,logsRes]=await Promise.all([
   supabase.from("organization_members")
    .select("id,user_id,role,status,employee_id,customer_id,permissions,profiles:user_id(display_name)")
    .eq("organization_id",m.organization_id).order("created_at"),
   supabase.from("employees").select("id,full_name,email,position").eq("organization_id",m.organization_id).order("full_name"),
   supabase.from("customers").select("id,customer_no,first_name,last_name,organization_name,email").eq("organization_id",m.organization_id).order("created_at",{ascending:false}).limit(500),
   supabase.from("user_onboarding_log").select("*").eq("organization_id",m.organization_id).order("created_at",{ascending:false}).limit(50)
 ]);
 const members:any[]=membersRes.data||[],employees:any[]=employeesRes.data||[],customers:any[]=customersRes.data||[],logs:any[]=logsRes.data||[];

 return <AppShell>
  <h1 className="page-title">ผู้ใช้งานและสิทธิ์</h1>
  <p className="muted">เชิญ Supabase Auth user และเชื่อมกับพนักงาน/ลูกค้า</p>

  <section className="card" style={{marginBottom:16}}>
   <h3>เชิญผู้ใช้</h3>
   <form action={inviteUser} className="form-grid">
    <label>อีเมล<input name="email" type="email" required/></label>
    <label>ชื่อแสดง<input name="display_name"/></label>
    <label>Role<select name="role"><option value="technician">Technician</option><option value="admin">Admin</option><option value="customer">Customer</option>{m.role==="owner"&&<><option value="manager">Manager</option><option value="owner">Owner</option></>}</select></label>
    <label>เชื่อมพนักงาน<select name="employee_id"><option value="">ไม่เชื่อม</option>{employees.map((e:any)=><option key={e.id} value={e.id}>{e.full_name} · {e.position||"-"} · {e.email||"-"}</option>)}</select></label>
    <label>เชื่อมลูกค้า<select name="customer_id"><option value="">ไม่เชื่อม</option>{customers.map((c:any)=><option key={c.id} value={c.id}>{c.customer_no} · {c.organization_name||[c.first_name,c.last_name].filter(Boolean).join(" ")} · {c.email||"-"}</option>)}</select></label>
    <label>Permissions (คั่นด้วย comma)<input name="permissions" placeholder="dashboard,jobs,technicianJobs"/></label>
    <div><button className="btn primary">ส่งคำเชิญ / เชื่อมบัญชี</button></div>
   </form>
  </section>

  <section className="card" style={{marginBottom:16}}>
   <h3>Membership</h3>
   <div className="table-wrap"><table><thead><tr><th>User ID</th><th>ชื่อ</th><th>Role</th><th>สถานะ</th><th>Employee</th><th>Customer</th><th></th></tr></thead><tbody>
    {members.map((x:any)=><tr key={x.id}><td>{String(x.user_id).slice(0,8)}…</td><td>{x.profiles?.display_name||"-"}</td><td>{x.role}</td><td>{x.status}</td><td>{x.employee_id?"เชื่อมแล้ว":"-"}</td><td>{x.customer_id?"เชื่อมแล้ว":"-"}</td><td>{x.status==="active"&&(m.role==="owner"||!["owner","manager"].includes(x.role))&&<form action={disableMembership}><input type="hidden" name="membership_id" value={x.id}/><button className="btn light">ระงับ</button></form>}</td></tr>)}
   </tbody></table></div>
  </section>

  <section className="card">
   <h3>ประวัติ Onboarding</h3>
   <div className="table-wrap"><table><thead><tr><th>อีเมล</th><th>Role</th><th>สถานะ</th><th>เวลา</th><th>ปัญหา</th></tr></thead><tbody>
    {logs.map((x:any)=><tr key={x.id}><td>{x.email}</td><td>{x.requested_role}</td><td>{x.status}</td><td>{new Date(x.created_at).toLocaleString("th-TH")}</td><td>{x.error_message||"-"}</td></tr>)}
   </tbody></table>{!logs.length&&<div className="empty">ยังไม่มีประวัติ</div>}</div>
  </section>
 </AppShell>
}
