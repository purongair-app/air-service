"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getCurrentMembership } from "@/lib/org";

async function requireOwnerManager(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role)) throw new Error("เฉพาะเจ้าของหรือผู้จัดการ");
 return m;
}

export async function inviteUser(formData:FormData){
 const m=await requireOwnerManager();
 const client=await createClient();
 const admin=createAdminClient();
 const {data:{user:actor}}=await client.auth.getUser();

 const email=String(formData.get("email")||"").trim().toLowerCase();
 const displayName=String(formData.get("display_name")||"").trim();
 const role=String(formData.get("role")||"technician");
 const employeeId=String(formData.get("employee_id")||"")||null;
 const customerId=String(formData.get("customer_id")||"")||null;
 if(!email||!email.includes("@"))throw new Error("อีเมลไม่ถูกต้อง");
 if(!["owner","manager","admin","technician","customer"].includes(role))throw new Error("Role ไม่ถูกต้อง");
 if(m.role==="manager"&&["owner","manager"].includes(role))throw new Error("Manager ไม่สามารถสร้างหรือเลื่อนสิทธิ์ Owner/Manager ได้");
 if(role==="technician"&&!employeeId)throw new Error("Technician ต้องเชื่อมกับพนักงาน");
 if(role==="customer"&&!customerId)throw new Error("Customer ต้องเชื่อมกับลูกค้า");

 let authUser:any=null;
 let inviteStatus="invited";
 let inviteError:string|null=null;

 const {data:list,error:listError}=await admin.auth.admin.listUsers({page:1,perPage:1000});
 if(listError)throw new Error(listError.message);
 authUser=list.users.find(u=>u.email?.toLowerCase()===email)||null;

 if(authUser){
   inviteStatus="existing";
 }else{
   const redirectTo=(process.env.NEXT_PUBLIC_SITE_URL||"http://localhost:3000").replace(/\/$/,"");
   const {data,error}=await admin.auth.admin.inviteUserByEmail(email,{
     redirectTo,
     data:{display_name:displayName}
   });
   if(error){inviteError=error.message;}
   else authUser=data.user;
 }
 if(inviteError||!authUser){
   await client.from("user_onboarding_log").insert({
     organization_id:m.organization_id,email,requested_role:role,
     employee_id:employeeId,customer_id:customerId,status:"error",
     error_message:inviteError||"Auth user not returned",created_by:actor?.id
   });
   throw new Error(inviteError||"สร้างคำเชิญไม่สำเร็จ");
 }

 const permissions=String(formData.get("permissions")||"")
   .split(",").map(x=>x.trim()).filter(Boolean);

 const {error:memberError}=await client.from("organization_members").upsert({
   organization_id:m.organization_id,user_id:authUser.id,
   role,status:"active",employee_id:employeeId,customer_id:customerId,permissions
 },{onConflict:"organization_id,user_id"});
 if(memberError)throw new Error(memberError.message);

 await admin.from("profiles").upsert({
   id:authUser.id,display_name:displayName||email
 },{onConflict:"id"});

 await client.from("user_onboarding_log").insert({
   organization_id:m.organization_id,email,requested_role:role,
   employee_id:employeeId,customer_id:customerId,auth_user_id:authUser.id,
   status:inviteStatus==="existing"?"existing":"linked",
   invited_at:inviteStatus==="invited"?new Date().toISOString():null,
   linked_at:new Date().toISOString(),created_by:actor?.id
 });

 revalidatePath("/settings/users");
}

export async function disableMembership(formData:FormData){
 const m=await requireOwnerManager();
 const client=await createClient();
 const membershipId=String(formData.get("membership_id")||"");
 const {data:target,error:targetError}=await client.from("organization_members")
   .select("id,user_id,role,status")
   .eq("id",membershipId).eq("organization_id",m.organization_id).maybeSingle();
 if(targetError)throw new Error(targetError.message);
 if(!target)throw new Error("ไม่พบ Membership");
 if(m.role==="manager"&&["owner","manager"].includes(target.role))throw new Error("Manager ไม่สามารถระงับ Owner/Manager ได้");
 if(target.role==="owner"){
   if(m.role!=="owner")throw new Error("เฉพาะ Owner เท่านั้น");
   const {count,error:countError}=await client.from("organization_members")
     .select("id",{count:"exact",head:true})
     .eq("organization_id",m.organization_id).eq("role","owner").eq("status","active");
   if(countError)throw new Error(countError.message);
   if((count||0)<=1)throw new Error("ไม่สามารถระงับ Owner คนสุดท้ายขององค์กรได้");
 }
 const {error}=await client.from("organization_members").update({status:"disabled"})
   .eq("id",membershipId).eq("organization_id",m.organization_id);
 if(error)throw new Error(error.message);
 revalidatePath("/settings/users");
}
