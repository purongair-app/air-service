import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function MigrationStatus(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:runs=[]},{data:files=[]}]=await Promise.all([
   supabase.from("migration_runs").select("*").eq("organization_id",m.organization_id).order("started_at",{ascending:false}).limit(20),
   supabase.from("file_migration_items").select("*").eq("organization_id",m.organization_id).order("updated_at",{ascending:false}).limit(500)
 ]);
 const stats=(files||[]).reduce((a:any,x:any)=>{a[x.status]=(a[x.status]||0)+1;return a;},{});
 return <AppShell>
  <h1 className="page-title">Migration Center</h1>
  <p className="muted">ติดตามการย้ายข้อมูลและไฟล์จากระบบเดิม</p>
  <section className="grid cards" style={{marginBottom:16}}>
   {["copied","pending","error","skipped"].map(k=><div className="card" key={k}><div className="muted">{k}</div><div className="kpi">{stats[k]||0}</div></div>)}
  </section>
  <section className="card" style={{marginBottom:16}}><h3>Data migration runs</h3><div className="table-wrap"><table><thead><tr><th>Source</th><th>Mode</th><th>Status</th><th>เริ่ม</th><th>จบ</th></tr></thead><tbody>{runs.map((x:any)=><tr key={x.id}><td>{x.source_name}</td><td>{x.mode}</td><td>{x.status}</td><td>{new Date(x.started_at).toLocaleString("th-TH")}</td><td>{x.completed_at?new Date(x.completed_at).toLocaleString("th-TH"):"-"}</td></tr>)}</tbody></table></div></section>
  <section className="card"><h3>Drive → Storage</h3><div className="table-wrap"><table><thead><tr><th>Entity</th><th>Legacy ID</th><th>Drive ID</th><th>Bucket</th><th>Status</th><th>Error</th></tr></thead><tbody>{files.map((x:any)=><tr key={x.id}><td>{x.source_entity}</td><td>{x.source_legacy_id||"-"}</td><td>{x.source_file_id}</td><td>{x.destination_bucket}</td><td>{x.status}</td><td>{x.error_message||"-"}</td></tr>)}</tbody></table>{!files.length&&<div className="empty">ยังไม่มีผลการย้ายไฟล์</div>}</div></section>
 </AppShell>
}
