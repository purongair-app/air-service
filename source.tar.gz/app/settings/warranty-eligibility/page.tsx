import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { saveEligibilityPolicy,seedEligibility } from "./actions";

export default async function WarrantyEligibilitySettings(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const {data:p}=await supabase.from("warranty_eligibility_policies").select("*").eq("organization_id",m.organization_id).maybeSingle();
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">Warranty Eligibility</h1><p className="muted">กำหนดหลักการตรวจสิทธิ์เคลมอัตโนมัติ</p></div>{!p&&<form action={seedEligibility}><button className="btn primary">สร้างค่าเริ่มต้น</button></form>}</div>
  <section className="card">
   <form action={saveEligibilityPolicy} className="form-grid">
    <label><span><input type="checkbox" name="allow_active_warranty" defaultChecked={p?.allow_active_warranty??true}/> รับสิทธิ์จาก Warranty ที่ยังไม่หมด</span></label>
    <label><span><input type="checkbox" name="allow_active_service_contract" defaultChecked={p?.allow_active_service_contract??true}/> รับสิทธิ์จาก Service Contract ที่ยังเหลือครั้ง</span></label>
    <label><span><input type="checkbox" name="allow_workmanship_warranty" defaultChecked={p?.allow_workmanship_warranty??true}/> รับประกันผลงานจาก Job ล่าสุด</span></label>
    <label>รับประกันผลงานกี่วัน<input type="number" min="0" max="3650" name="workmanship_days" defaultValue={p?.workmanship_days??30}/></label>
    <label><span><input type="checkbox" name="require_registered_equipment" defaultChecked={p?.require_registered_equipment??false}/> Claim ต้องระบุเครื่องที่ลงทะเบียน</span></label>
    <div><button className="btn primary">บันทึก Policy</button></div>
   </form>
  </section>
  <p className="muted">Eligibility Engine ช่วยคัดกรองเบื้องต้น ไม่ควรใช้แทนเงื่อนไขรับประกันตามสัญญา/กฎหมายที่กิจการกำหนดจริง</p>
 </AppShell>
}
