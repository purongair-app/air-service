"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function saveEligibilityPolicy(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient();
 const {error}=await supabase.from("warranty_eligibility_policies").upsert({
  organization_id:m.organization_id,
  allow_active_warranty:formData.get("allow_active_warranty")==="on",
  allow_active_service_contract:formData.get("allow_active_service_contract")==="on",
  allow_workmanship_warranty:formData.get("allow_workmanship_warranty")==="on",
  workmanship_days:Number(formData.get("workmanship_days")||30),
  require_registered_equipment:formData.get("require_registered_equipment")==="on",
  updated_at:new Date().toISOString()
 },{onConflict:"organization_id"});
 if(error)throw new Error(error.message);
 revalidatePath("/settings/warranty-eligibility");
}

export async function seedEligibility(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 const supabase=await createClient();
 const {error}=await supabase.rpc("seed_warranty_eligibility_defaults",{p_org:m.organization_id});
 if(error)throw new Error(error.message);
 revalidatePath("/settings/warranty-eligibility");
}
