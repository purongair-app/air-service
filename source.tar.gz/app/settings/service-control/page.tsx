import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { seedDefaults,saveSla,saveTower } from "./actions";

export default async function ServiceControlSettings(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:sla=[]},{data:tower}]=await Promise.all([
  supabase.from("warranty_claim_sla_policies").select("*").eq("organization_id",m.organization_id).order("priority"),
  supabase.from("control_tower_settings").select("*").eq("organization_id",m.organization_id).maybeSingle()
 ]);
 const map=Object.fromEntries((sla as any[]).map((x:any)=>[x.priority,x]));
 return <AppShell>
  <div className="actions"><div><h1 className="page-title">Service SLA & Control Tower</h1><p className="muted">ตั้ง SLA เคลมและ Threshold ของ Alert</p></div>{(!sla.length||!tower)&&<form action={seedDefaults}><button className="btn primary">สร้างค่าเริ่มต้น</button></form>}</div>
  <div className="grid">
   <section className="card"><h3>Warranty Claim SLA (ชั่วโมง)</h3><form action={saveSla} className="form-grid">
    {["low","normal","high","urgent"].map(p=><div key={p} style={{display:"contents"}}><label>{p} · Response<input type="number" min="1" name={"response_"+p} defaultValue={map[p]?.response_hours??({low:8,normal:4,high:2,urgent:1} as any)[p]}/></label><label>{p} · Resolution<input type="number" min="1" name={"resolution_"+p} defaultValue={map[p]?.resolution_hours??({low:72,normal:48,high:24,urgent:8} as any)[p]}/></label></div>)}
    <div><button className="btn light">บันทึก SLA</button></div>
   </form></section>
   <section className="card"><h3>Control Tower Thresholds</h3><form action={saveTower} className="form-grid">
    <label>งานเกินกำหนด (วัน)<input type="number" min="0" name="overdue_job_warn_days" defaultValue={tower?.overdue_job_warn_days??1}/></label>
    <label>A/R เกินกำหนดขั้นต่ำ (บาท)<input type="number" min="0" step="0.01" name="ar_overdue_warn_amount" defaultValue={tower?.ar_overdue_warn_amount??1}/></label>
    <label>A/P เกินกำหนดขั้นต่ำ (บาท)<input type="number" min="0" step="0.01" name="ap_overdue_warn_amount" defaultValue={tower?.ap_overdue_warn_amount??1}/></label>
    <label>Failed Notification<input type="number" min="0" name="failed_notification_warn_count" defaultValue={tower?.failed_notification_warn_count??1}/></label>
    <label>Reorder Items<input type="number" min="0" name="reorder_item_warn_count" defaultValue={tower?.reorder_item_warn_count??1}/></label>
    <label>Cycle Count Bins<input type="number" min="0" name="cycle_count_bin_warn_count" defaultValue={tower?.cycle_count_bin_warn_count??1}/></label>
    <label>Open RMA<input type="number" min="0" name="open_rma_warn_count" defaultValue={tower?.open_rma_warn_count??1}/></label>
    <label>Supplier Score ต่ำกว่า<input type="number" min="0" max="100" step="0.01" name="supplier_score_warn_below" defaultValue={tower?.supplier_score_warn_below??60}/></label>
    <label>Forecast WAPE มากกว่า %<input type="number" min="0" step="0.01" name="forecast_wape_warn_pct" defaultValue={tower?.forecast_wape_warn_pct??40}/></label>
    <label>Open/Breached Claims<input type="number" min="0" name="warranty_claim_warn_count" defaultValue={tower?.warranty_claim_warn_count??1}/></label>
    <div><button className="btn light">บันทึก Threshold</button></div>
   </form></section>
  </div>
 </AppShell>
}
