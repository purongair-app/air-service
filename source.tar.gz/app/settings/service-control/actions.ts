"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

async function ownerManager(){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("เฉพาะ Owner/Manager");
 return m;
}

export async function seedDefaults(){
 const m=await ownerManager(); const supabase=await createClient();
 const {error}=await supabase.rpc("seed_warranty_claim_sla_defaults",{p_org:m.organization_id});
 if(error)throw new Error(error.message);
 revalidatePath("/settings/service-control");revalidatePath("/control-tower");
}

export async function saveSla(formData:FormData){
 const m=await ownerManager(); const supabase=await createClient();
 const rows=["low","normal","high","urgent"].map(p=>({
  organization_id:m.organization_id,priority:p,
  response_hours:Number(formData.get("response_"+p)||1),
  resolution_hours:Number(formData.get("resolution_"+p)||8),
  active:true,updated_at:new Date().toISOString()
 }));
 if(rows.some(x=>x.response_hours<=0||x.resolution_hours<=0))throw new Error("SLA ต้องมากกว่า 0 ชั่วโมง");
 const {error}=await supabase.from("warranty_claim_sla_policies").upsert(rows,{onConflict:"organization_id,priority"});
 if(error)throw new Error(error.message);
 revalidatePath("/settings/service-control");
}

export async function saveTower(formData:FormData){
 const m=await ownerManager(); const supabase=await createClient();
 const row={
  organization_id:m.organization_id,
  overdue_job_warn_days:Number(formData.get("overdue_job_warn_days")||1),
  ar_overdue_warn_amount:Number(formData.get("ar_overdue_warn_amount")||1),
  ap_overdue_warn_amount:Number(formData.get("ap_overdue_warn_amount")||1),
  failed_notification_warn_count:Number(formData.get("failed_notification_warn_count")||1),
  reorder_item_warn_count:Number(formData.get("reorder_item_warn_count")||1),
  cycle_count_bin_warn_count:Number(formData.get("cycle_count_bin_warn_count")||1),
  open_rma_warn_count:Number(formData.get("open_rma_warn_count")||1),
  supplier_score_warn_below:Number(formData.get("supplier_score_warn_below")||60),
  forecast_wape_warn_pct:Number(formData.get("forecast_wape_warn_pct")||40),
  warranty_claim_warn_count:Number(formData.get("warranty_claim_warn_count")||1),
  updated_at:new Date().toISOString()
 };
 const {error}=await supabase.from("control_tower_settings").upsert(row,{onConflict:"organization_id"});
 if(error)throw new Error(error.message);
 revalidatePath("/settings/service-control");revalidatePath("/control-tower");
}
