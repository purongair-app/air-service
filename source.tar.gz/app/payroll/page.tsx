import PayrollProofUpload from "@/components/payroll-proof-upload";
import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { savePayroll } from "./actions";

export default async function Payroll(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:rows=[]},{data:employees=[]}]=await Promise.all([
   supabase.from("payroll_records").select("*,employees(full_name)").eq("organization_id",m.organization_id).order("pay_date",{ascending:false}).limit(200),
   supabase.from("employees").select("id,full_name,position").eq("organization_id",m.organization_id).neq("employment_status","resigned").order("full_name")
 ]);
 return <AppShell>
  <h1 className="page-title">เงินเดือนและค่าแรง</h1><p className="muted">เงินเดือน ค่าแรง OT โบนัส และรายการหัก</p>
  <section className="card" style={{marginBottom:16}}>
   <form action={savePayroll} className="form-grid">
    <label>พนักงาน<select name="employee_id" required><option value="">เลือกพนักงาน</option>{employees.map((e:any)=><option key={e.id} value={e.id}>{e.full_name} · {e.position||"-"}</option>)}</select></label>
    <label>รอบจ่าย<input name="period" placeholder="2026-10" required/></label>
    <label>วันจ่าย<input name="pay_date" type="date" required/></label>
    <label>ประเภท<select name="pay_type"><option value="salary">เงินเดือน</option><option value="daily">ค่าแรงรายวัน</option><option value="job">ค่าแรงตามงาน</option></select></label>
    <label>เงินเดือน/ค่าแรง<input name="base_amount" type="number" step="0.01" defaultValue="0"/></label>
    <label>OT<input name="overtime" type="number" step="0.01" defaultValue="0"/></label>
    <label>โบนัส<input name="bonus" type="number" step="0.01" defaultValue="0"/></label>
    <label>หัก<input name="deduction" type="number" step="0.01" defaultValue="0"/></label>
    <label>ช่องทาง<select name="payment_method"><option value="transfer">โอนเงิน</option><option value="cash">เงินสด</option><option value="promptpay">พร้อมเพย์</option></select></label>
    <label>สถานะ<select name="status"><option value="pending">รอจ่าย</option><option value="paid">จ่ายแล้ว</option></select></label>
    <label style={{gridColumn:"1/-1"}}>หมายเหตุ<textarea name="note"/></label>
    <div><button className="btn primary">บันทึกเงินเดือน</button></div>
   </form>
  </section>
  <div className="table-wrap"><table><thead><tr><th>เลขที่</th><th>พนักงาน</th><th>รอบ</th><th>วันจ่าย</th><th>ฐาน</th><th>OT</th><th>โบนัส</th><th>หัก</th><th>สุทธิ</th><th>สถานะ</th><th>หลักฐาน</th></tr></thead><tbody>
   {rows.map((r:any)=><tr key={r.id}><td>{r.payroll_no}</td><td>{r.employees?.full_name||"-"}</td><td>{r.period}</td><td>{r.pay_date}</td><td>{Number(r.base_amount).toLocaleString()}</td><td>{Number(r.overtime).toLocaleString()}</td><td>{Number(r.bonus).toLocaleString()}</td><td>{Number(r.deduction).toLocaleString()}</td><td><b>{Number(r.net_amount).toLocaleString()}</b></td><td>{r.status}</td><td><PayrollProofUpload organizationId={m.organization_id} payrollId={r.id}/>{r.payment_proof_path&&<div><a className="btn light" target="_blank" href={"/api/private-file?bucket=business-documents&path="+encodeURIComponent(r.payment_proof_path)}>เปิดหลักฐาน</a></div>}</td></tr>)}
  </tbody></table>{!rows.length&&<div className="empty">ยังไม่มีรายการเงินเดือน</div>}</div>
 </AppShell>
}
