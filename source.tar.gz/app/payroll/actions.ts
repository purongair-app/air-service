"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function savePayroll(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager"].includes(m.role))throw new Error("ไม่มีสิทธิ์จัดการเงินเดือน");
 const supabase=await createClient();
 const employeeId=String(formData.get("employee_id")||"");
 const {data:e}=await supabase.from("employees").select("full_name,payroll_bank_name,payroll_account_name,payroll_account_number").eq("id",employeeId).single();
 if(!e)throw new Error("ไม่พบพนักงาน");

 const payrollNo=`PAY-${new Date().toISOString().slice(2,7).replace("-","")}-${Date.now().toString().slice(-5)}`;
 const {error}=await supabase.from("payroll_records").insert({
   organization_id:m.organization_id,payroll_no:payrollNo,employee_id:employeeId,
   period:String(formData.get("period")||""),pay_date:String(formData.get("pay_date")||""),
   pay_type:String(formData.get("pay_type")||"salary"),
   base_amount:Number(formData.get("base_amount")||0),
   overtime:Number(formData.get("overtime")||0),
   bonus:Number(formData.get("bonus")||0),
   deduction:Number(formData.get("deduction")||0),
   status:String(formData.get("status")||"pending"),
   payment_method:String(formData.get("payment_method")||"transfer"),
   bank_name:e.payroll_bank_name,bank_account_name:e.payroll_account_name,
   bank_account_number:e.payroll_account_number,
   note:String(formData.get("note")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/payroll");
}
