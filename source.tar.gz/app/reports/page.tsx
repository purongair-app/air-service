import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function Reports({searchParams}:{searchParams:Promise<{from?:string,to?:string}>}){
 const p=await searchParams; const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:k,error:kError},{data:staff=[]}]=await Promise.all([
  supabase.rpc("management_kpis",{p_org:m.organization_id,p_from:p.from||null,p_to:p.to||null}),
  supabase.from("employee_job_performance").select("*").eq("organization_id",m.organization_id).order("completed_jobs",{ascending:false})
 ]);
 const cash=Number(k?.cash_received||0),expenses=Number(k?.expenses||0);
 const qs=new URLSearchParams(); if(p.from)qs.set("from",p.from); if(p.to)qs.set("to",p.to);

 return <AppShell><h1 className="page-title">รายงานผู้บริหาร</h1>
  <p className="muted">KPI ตามช่วงวันที่จริง {p.from||"ทั้งหมด"} ถึง {p.to||"ปัจจุบัน"}</p>
  <section className="card" style={{marginBottom:16}}>
   <form method="get" className="actions">
    <label>จาก<input type="date" name="from" defaultValue={p.from||""}/></label>
    <label>ถึง<input type="date" name="to" defaultValue={p.to||""}/></label>
    <button className="btn primary">คำนวณ</button>
    <a className="btn light" href={"/reports/export?"+qs.toString()}>Export Jobs CSV</a>
   </form>
  </section>
  {kError?<div className="card">{kError.message}</div>:<>
  <section className="grid cards">
   <div className="card"><div className="muted">ลูกค้าใหม่</div><div className="kpi">{k?.new_customers||0}</div></div>
   <div className="card"><div className="muted">งานทั้งหมด</div><div className="kpi">{k?.jobs_total||0}</div></div>
   <div className="card"><div className="muted">งานเสร็จ</div><div className="kpi">{k?.jobs_completed||0}</div></div>
   <div className="card"><div className="muted">ยอดเอกสารขาย</div><div className="kpi">{Number(k?.sales_total||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">รับเงินจริง</div><div className="kpi">{cash.toLocaleString()}</div></div>
   <div className="card"><div className="muted">รายจ่าย</div><div className="kpi">{expenses.toLocaleString()}</div></div>
   <div className="card"><div className="muted">กระแสสุทธิ</div><div className="kpi">{(cash-expenses).toLocaleString()}</div></div>
   <div className="card"><div className="muted">กำไรขั้นต้น Job</div><div className="kpi">{Number(k?.gross_profit_jobs||0).toLocaleString()}</div></div>
   <div className="card"><div className="muted">PM เสร็จ</div><div className="kpi">{k?.pm_completed||0}</div></div>
  </section>
  <section className="card" style={{marginTop:16}}><h3>ผลงานทีมช่าง (สะสม)</h3><div className="table-wrap"><table><thead><tr><th>พนักงาน</th><th>ได้รับมอบหมาย</th><th>รับงาน</th><th>งานเสร็จ</th><th>รายได้งานเสร็จ</th></tr></thead><tbody>
   {staff.map((x:any)=><tr key={x.employee_id}><td>{x.full_name}</td><td>{x.assigned_jobs}</td><td>{x.accepted_jobs}</td><td>{x.completed_jobs}</td><td>{Number(x.completed_revenue||0).toLocaleString()}</td></tr>)}
  </tbody></table></div></section>
  </>}
 </AppShell>
}
