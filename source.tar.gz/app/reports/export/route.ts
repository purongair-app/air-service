import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

function csvEscape(v:any){
 const s=String(v??"");
 return `"${s.replaceAll('"','""')}"`;
}

export async function GET(req:NextRequest){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))return new NextResponse("Forbidden",{status:403});
 const from=req.nextUrl.searchParams.get("from");
 const to=req.nextUrl.searchParams.get("to");
 const supabase=await createClient();

 let q=supabase.from("jobs").select("work_no,customer_name_snapshot,service_name,status,appointment_date,estimated_revenue,labor_cost,misc_cost,created_at")
  .eq("organization_id",m.organization_id).order("created_at");
 if(from)q=q.gte("created_at",from+"T00:00:00");
 if(to)q=q.lte("created_at",to+"T23:59:59");
 const {data=[],error}=await q;
 if(error)return new NextResponse(error.message,{status:500});

 const headers=["work_no","customer","service","status","appointment_date","estimated_revenue","labor_cost","misc_cost","created_at"];
 const lines=[headers.join(","),...data.map((x:any)=>[
  x.work_no,x.customer_name_snapshot,x.service_name,x.status,x.appointment_date,
  x.estimated_revenue,x.labor_cost,x.misc_cost,x.created_at
 ].map(csvEscape).join(","))];

 await supabase.from("report_exports").insert({
  organization_id:m.organization_id,report_type:"jobs_csv",
  date_from:from||null,date_to:to||null,filters:{}
 });

 return new NextResponse("\uFEFF"+lines.join("\n"),{
  headers:{
   "Content-Type":"text/csv; charset=utf-8",
   "Content-Disposition":`attachment; filename="airfriend-jobs-${from||"all"}-${to||"all"}.csv"`
  }
 });
}
