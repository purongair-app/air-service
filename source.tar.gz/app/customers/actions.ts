"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function createCustomer(formData: FormData) {
  const member = await getCurrentMembership();
  if (!member) throw new Error("ไม่พบองค์กรของผู้ใช้");
  const supabase = await createClient();

  const firstName = String(formData.get("first_name")||"").trim();
  const phone = String(formData.get("phone")||"").trim();
  if (!firstName || !phone) throw new Error("กรุณาระบุชื่อลูกค้าและเบอร์โทร");

  const customerNo = "C-" + Date.now().toString().slice(-8);
  const { error } = await supabase.from("customers").insert({
    organization_id: member.organization_id,
    customer_no: customerNo,
    customer_type: String(formData.get("customer_type")||"บุคคลทั่วไป"),
    first_name: firstName,
    last_name: String(formData.get("last_name")||"").trim(),
    phone,
    email: String(formData.get("email")||"").trim() || null,
    area: String(formData.get("area")||"").trim() || null,
    notes: String(formData.get("notes")||"").trim() || null
  });
  if(error) throw new Error(error.message);
  revalidatePath("/customers");
}
