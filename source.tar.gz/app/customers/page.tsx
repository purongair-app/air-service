import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { createCustomer } from "./actions";

export default async function CustomersPage() {
  const member=await getCurrentMembership();
  const supabase=await createClient();
  const {data=[]}=member?await supabase.from("customers")
    .select("id,customer_no,first_name,last_name,organization_name,phone,area,customer_type")
    .eq("organization_id",member.organization_id)
    .order("created_at",{ascending:false}).limit(100):{data:[]};

  return <AppShell>
    <div className="topbar"><div><h1 className="page-title">ลูกค้า</h1><div className="muted">ทะเบียนลูกค้าและสถานที่ให้บริการ</div></div></div>
    <div className="card" style={{marginBottom:16}}>
      <form action={createCustomer} className="form-grid">
        <label>ประเภทลูกค้า<select name="customer_type"><option>บุคคลทั่วไป</option><option>ร้านค้า</option><option>บริษัท</option><option>หน่วยงานราชการ</option></select></label>
        <label>ชื่อ<input name="first_name" required /></label>
        <label>นามสกุล<input name="last_name" /></label>
        <label>เบอร์โทร<input name="phone" required /></label>
        <label>อีเมล<input name="email" type="email" /></label>
        <label>พื้นที่<input name="area" /></label>
        <label style={{gridColumn:"1/-1"}}>หมายเหตุ<textarea name="notes"/></label>
        <div><button className="btn primary">เพิ่มลูกค้า</button></div>
      </form>
    </div>
    <div className="table-wrap"><table>
      <thead><tr><th>รหัส</th><th>ลูกค้า</th><th>ประเภท</th><th>โทรศัพท์</th><th>พื้นที่</th></tr></thead>
      <tbody>{data.map((x:any)=><tr key={x.id}><td>{x.customer_no}</td><td>{x.organization_name||[x.first_name,x.last_name].filter(Boolean).join(" ")}</td><td>{x.customer_type}</td><td>{x.phone}</td><td>{x.area||"-"}</td></tr>)}</tbody>
    </table>{!data.length&&<div className="empty">ยังไม่มีข้อมูลลูกค้า</div>}</div>
  </AppShell>
}
