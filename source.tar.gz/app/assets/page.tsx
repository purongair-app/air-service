import AssetReturnForm from "@/components/asset-return-form";
import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { saveAsset,issueAsset } from "./actions";

export default async function Assets(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:assets=[]},{data:employees=[]},{data:issues=[]}]=await Promise.all([
  supabase.from("assets").select("*,employees:holder_employee_id(full_name)").eq("organization_id",m.organization_id).order("created_at",{ascending:false}),
  supabase.from("employees").select("id,full_name").eq("organization_id",m.organization_id).neq("employment_status","resigned").order("full_name"),
  supabase.from("asset_issues").select("*").eq("organization_id",m.organization_id).order("created_at",{ascending:false}).limit(100)
 ]);
 return <AppShell><h1 className="page-title">ทรัพย์สินและเครื่องมือช่าง</h1>
 <div className="grid">
  <section className="card"><h3>เพิ่มทรัพย์สิน</h3><form action={saveAsset} className="form-grid">
   <label>ชื่อ<input name="name" required/></label><label>หมวดหมู่<input name="category"/></label>
   <label>ยี่ห้อ/รุ่น<input name="brand_model"/></label><label>Serial<input name="serial_no"/></label>
   <label>วันซื้อ<input type="date" name="purchase_date"/></label><label>ราคาซื้อ<input type="number" step="0.01" name="purchase_cost"/></label>
   <label>สถานที่เก็บ<input name="location"/></label><label>หมายเหตุ<input name="note"/></label>
   <div><button className="btn primary">เพิ่มทรัพย์สิน</button></div></form></section>
  <section className="card"><h3>เบิก/ยืม</h3><form action={issueAsset} className="form-grid">
   <label>ทรัพย์สิน<select name="asset_id">{assets.filter((a:any)=>a.status==="พร้อมใช้").map((a:any)=><option key={a.id} value={a.id}>{a.asset_no} · {a.name}</option>)}</select></label>
   <label>พนักงาน<select name="employee_id">{employees.map((e:any)=><option key={e.id} value={e.id}>{e.full_name}</option>)}</select></label>
   <label>ประเภท<select name="issue_type"><option>ยืม</option><option>เบิกใช้</option></select></label>
   <label>วันที่<input type="date" name="issue_date" required/></label>
   <label>กำหนดคืน<input type="date" name="due_date"/></label><label>หมายเหตุ<input name="note"/></label>
   <div><button className="btn primary">บันทึก</button></div></form></section>
  <section className="table-wrap"><table><thead><tr><th>รหัส</th><th>ชื่อ</th><th>หมวด</th><th>สภาพ</th><th>สถานะ</th><th>ผู้ถือครอง</th><th>สถานที่</th></tr></thead><tbody>
   {assets.map((a:any)=><tr key={a.id}><td>{a.asset_no}</td><td>{a.name}</td><td>{a.category||"-"}</td><td>{a.condition||"-"}</td><td>{a.status||"-"}</td><td>{a.employees?.full_name||"-"}</td><td>{a.location||"-"}</td></tr>)}
  </tbody></table></section>
  <section className="card"><h3>คืนเครื่องมือ</h3>
   <div className="grid">{issues.filter((x:any)=>x.status!=="คืนแล้ว").map((x:any)=>{
    const items=Array.isArray(x.items)?x.items:[];
    return <div className="card" key={x.id}><b>{x.issue_no}</b><div className="muted">{x.issue_type} · {x.issue_date}</div><AssetReturnForm issueId={x.id} items={items}/></div>
   })}
   {!issues.filter((x:any)=>x.status!=="คืนแล้ว").length&&<div className="muted">ไม่มีรายการค้างคืน</div>}</div>
  </section>
 </div></AppShell>
}
