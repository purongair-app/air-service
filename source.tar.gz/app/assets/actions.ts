"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function saveAsset(formData:FormData){
 const m=await getCurrentMembership(); if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient();
 const assetNo=`AST-${Date.now().toString().slice(-7)}`;
 const {data:{user}}=await supabase.auth.getUser();
 const {data:a,error}=await supabase.from("assets").insert({
   organization_id:m.organization_id,asset_no:assetNo,name:String(formData.get("name")||""),
   category:String(formData.get("category")||""),brand_model:String(formData.get("brand_model")||""),
   serial_no:String(formData.get("serial_no")||""),purchase_date:String(formData.get("purchase_date")||"")||null,
   purchase_cost:Number(formData.get("purchase_cost")||0),condition:"ปกติ",status:"พร้อมใช้",
   location:String(formData.get("location")||""),note:String(formData.get("note")||"")
 }).select("*").single();
 if(error)throw new Error(error.message);
 await supabase.from("asset_timeline").insert({
   organization_id:m.organization_id,asset_id:a.id,event:"เพิ่มทรัพย์สิน",
   detail:"สร้างทะเบียนทรัพย์สินใหม่",actor_user_id:user?.id,actor_name:user?.email
 });
 revalidatePath("/assets");
}

export async function issueAsset(formData:FormData){
 const m=await getCurrentMembership(); if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient(); const assetId=String(formData.get("asset_id")||"");
 const employeeId=String(formData.get("employee_id")||"");
 const {data:e}=await supabase.from("employees").select("full_name").eq("id",employeeId).single();
 const {data:a}=await supabase.from("assets").select("*").eq("id",assetId).single();
 if(!a||!e)throw new Error("ไม่พบข้อมูล");
 const items=[{assetId:a.id,assetNo:a.asset_no,assetName:a.name,conditionOut:a.condition||"ปกติ"}];
 const borrowers=[{id:employeeId,name:e.full_name}];
 const {error}=await supabase.from("asset_issues").insert({
  organization_id:m.organization_id,issue_no:`AIO-${Date.now().toString().slice(-7)}`,
  issue_type:String(formData.get("issue_type")||"ยืม"),issue_date:String(formData.get("issue_date")||""),
  due_date:String(formData.get("due_date")||"")||null,status:"กำลังยืม",
  items,borrowers,note:String(formData.get("note")||"")
 });
 if(error)throw new Error(error.message);
 await supabase.from("assets").update({holder_employee_id:employeeId,status:"ถูกยืม"}).eq("id",assetId);
 revalidatePath("/assets");
}


export async function returnAsset(formData:FormData){
 const m=await getCurrentMembership(); if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient(); const issueId=String(formData.get("issue_id")||"");
 const condition=String(formData.get("condition")||"ปกติ");
 const note=String(formData.get("return_note")||"");
 const {data:{user}}=await supabase.auth.getUser();
 const {data:issue}=await supabase.from("asset_issues").select("*").eq("id",issueId).single();
 if(!issue)throw new Error("ไม่พบรายการยืม");
 const items=Array.isArray(issue.items)?issue.items:[];
 for(const item of items){
  await supabase.from("assets").update({
    holder_employee_id:null,
    status:condition==="ปกติ"?"พร้อมใช้":condition,
    condition
  }).eq("id",item.assetId);
 }
 const {error}=await supabase.from("asset_issues").update({
  status:"คืนแล้ว",return_date:new Date().toISOString().slice(0,10),
  returned_by:user?.id,note:[issue.note,note].filter(Boolean).join(" · ")
 }).eq("id",issueId);
 if(error)throw new Error(error.message);
 revalidatePath("/assets");
}
