"use server";
import crypto from "node:crypto";
import { revalidatePath } from "next/cache";
import { createAdminClient } from "@/lib/supabase/admin";
import { resolveSupplierToken } from "@/lib/supplier-portal";

export async function submitSupplierQuote(formData:FormData){
 const token=String(formData.get("token")||"");
 const t=await resolveSupplierToken(token);
 if(!t)throw new Error("ลิงก์หมดอายุหรือไม่ถูกต้อง");
 const admin=createAdminClient();

 const {data:rfq}=await admin.from("rfqs").select("*").eq("id",t.rfq_id).single();
 if(!rfq||!["open","evaluating"].includes(rfq.status))throw new Error("RFQ ปิดรับราคาแล้ว");
 if(rfq.quote_due_date && rfq.quote_due_date < new Date().toISOString().slice(0,10))throw new Error("พ้นกำหนดรับราคาแล้ว");

 const {data:reqItems=[]}=await admin.from("purchase_request_items").select("*").eq("purchase_request_id",rfq.purchase_request_id).order("sort_order");
 const {data:q,error}=await admin.from("supplier_quotes").upsert({
  organization_id:t.organization_id,rfq_id:t.rfq_id,supplier_id:t.supplier_id,
  quote_reference:String(formData.get("quote_reference")||""),
  quote_date:String(formData.get("quote_date")||new Date().toISOString().slice(0,10)),
  valid_until:String(formData.get("valid_until")||"")||null,
  lead_time_days:Number(formData.get("lead_time_days")||0)||null,
  vat_rate:Number(formData.get("vat_rate")||0),
  payment_terms:String(formData.get("payment_terms")||""),
  note:String(formData.get("note")||""),
  status:"submitted"
 },{onConflict:"rfq_id,supplier_id"}).select("id").single();
 if(error)throw new Error(error.message);

 await admin.from("supplier_quote_items").delete().eq("supplier_quote_id",q.id);
 const rows=reqItems.map((x:any)=>({
  organization_id:t.organization_id,supplier_quote_id:q.id,purchase_request_item_id:x.id,
  inventory_item_id:x.inventory_item_id,description:x.description,quantity:x.quantity,unit:x.unit,
  unit_cost:Number(formData.get("cost_"+x.id)||0),
  discount:Number(formData.get("discount_"+x.id)||0)
 }));
 const {error:ierr}=await admin.from("supplier_quote_items").insert(rows);
 if(ierr)throw new Error(ierr.message);

 const attachment=formData.get("attachment");
 if(attachment instanceof File && attachment.size>0){
   const max=15*1024*1024;
   const allowed=new Set(["application/pdf","image/jpeg","image/png","image/webp"]);
   if(attachment.size>max)throw new Error("ไฟล์ต้องไม่เกิน 15 MB");
   if(!allowed.has(attachment.type))throw new Error("รองรับ PDF/JPG/PNG/WEBP เท่านั้น");

   const ext=(attachment.name.split(".").pop()||"bin").replace(/[^A-Za-z0-9]/g,"").slice(0,8)||"bin";
   const bytes=Buffer.from(await attachment.arrayBuffer());
   const sha256=crypto.createHash("sha256").update(bytes).digest("hex");
   const safeName=attachment.name.replace(/[^A-Za-z0-9._-]+/g,"-").slice(0,100);
   const path=`${t.organization_id}/supplier-quotes/${t.rfq_id}/${t.supplier_id}/${q.id}/${Date.now()}-${safeName||("quote."+ext)}`;

   const {error:uploadError}=await admin.storage.from("business-documents").upload(path,bytes,{
     contentType:attachment.type,upsert:false
   });
   if(uploadError)throw new Error(uploadError.message);

   const {error:attErr}=await admin.from("supplier_quote_attachments").insert({
     organization_id:t.organization_id,supplier_quote_id:q.id,supplier_id:t.supplier_id,rfq_id:t.rfq_id,
     storage_path:path,original_name:attachment.name,mime_type:attachment.type,file_size:attachment.size,sha256,
     uploaded_via:"supplier_portal"
   });
   if(attErr)throw new Error(attErr.message);

   await admin.from("supplier_quotes").update({attachment_path:path}).eq("id",q.id);
 }

 // Recalculate without exposing privileged RPC to anon: admin key executes it.
 const {error:rerr}=await admin.rpc("recalculate_supplier_quote",{p_quote:q.id});
 if(rerr)throw new Error(rerr.message);
 await admin.from("rfq_suppliers").update({status:"responded"}).eq("rfq_id",t.rfq_id).eq("supplier_id",t.supplier_id);
 await admin.from("rfqs").update({status:"evaluating"}).eq("id",t.rfq_id).eq("status","open");
 await admin.from("supplier_portal_tokens").update({submitted_at:new Date().toISOString()}).eq("id",t.id);

 revalidatePath("/supplier/rfq/"+token);
}
