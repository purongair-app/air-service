import { notFound } from "next/navigation";
import { createAdminClient } from "@/lib/supabase/admin";
import { resolveSupplierToken } from "@/lib/supplier-portal";
import { submitSupplierQuote } from "./actions";

export default async function SupplierRfq({params}:{params:Promise<{token:string}>}){
 const {token}=await params;
 const t=await resolveSupplierToken(token); if(!t)notFound();
 const admin=createAdminClient();
 const [{data:rfq},{data:supplier},{data:invite},{data:existing}]=await Promise.all([
  admin.from("rfqs").select("*,purchase_requests(*)").eq("id",t.rfq_id).single(),
  admin.from("suppliers").select("name,contact_name").eq("id",t.supplier_id).single(),
  admin.from("rfq_suppliers").select("*").eq("rfq_id",t.rfq_id).eq("supplier_id",t.supplier_id).single(),
  admin.from("supplier_quotes").select("*").eq("rfq_id",t.rfq_id).eq("supplier_id",t.supplier_id).maybeSingle()
 ]);
 if(!rfq||!supplier)notFound();
 const {data:items=[]}=await admin.from("purchase_request_items").select("*").eq("purchase_request_id",rfq.purchase_request_id).order("sort_order");
 let existingItems:any[]=[];
 if(existing){
  const q=await admin.from("supplier_quote_items").select("*").eq("supplier_quote_id",existing.id);
  existingItems=q.data||[];
 }
 const itemMap=new Map(existingItems.map((x:any)=>[x.purchase_request_item_id,x]));
 const expired=rfq.quote_due_date?rfq.quote_due_date<new Date().toISOString().slice(0,10):false;
 const closed=!["open","evaluating"].includes(rfq.status)||expired;

 return <main className="login-page">
  <div className="login-card" style={{maxWidth:900,width:"96%"}}>
   <div className="brand">AIRFRIEND SERVICE</div>
   <h1>{rfq.rfq_no} — ขอใบเสนอราคา</h1>
   <p><b>Supplier:</b> {supplier.name}</p>
   <p className="muted">{rfq.title} · กำหนดส่งราคา {rfq.quote_due_date||"-"}</p>
   {t.submitted_at&&<div className="badge">ส่งราคาแล้ว {new Date(t.submitted_at).toLocaleString("th-TH")}</div>}
   {closed?<div className="card">RFQ นี้ปิดรับราคาแล้ว</div>:<form action={submitSupplierQuote} className="grid">
    <input type="hidden" name="token" value={token}/>
    <div className="form-grid">
     <label>เลขใบเสนอราคาของ Supplier<input name="quote_reference" defaultValue={existing?.quote_reference||""}/></label>
     <label>วันที่เสนอราคา<input type="date" name="quote_date" defaultValue={existing?.quote_date||new Date().toISOString().slice(0,10)} required/></label>
     <label>ราคาใช้ได้ถึง<input type="date" name="valid_until" defaultValue={existing?.valid_until||""}/></label>
     <label>Lead time (วัน)<input type="number" min="0" name="lead_time_days" defaultValue={existing?.lead_time_days||""}/></label>
     <label>VAT %<input type="number" min="0" step="0.01" name="vat_rate" defaultValue={existing?.vat_rate??7}/></label>
     <label>เงื่อนไขชำระ<input name="payment_terms" defaultValue={existing?.payment_terms||""}/></label>
    </div>
    <div className="table-wrap"><table><thead><tr><th>รายการ</th><th>จำนวน</th><th>ราคา/หน่วย</th><th>ส่วนลด</th></tr></thead><tbody>
     {items.map((x:any)=>{const e:any=itemMap.get(x.id);return <tr key={x.id}><td>{x.description}</td><td>{x.quantity} {x.unit||""}</td><td><input style={{width:130}} type="number" min="0" step="0.01" name={"cost_"+x.id} defaultValue={e?.unit_cost??x.estimated_unit_cost??0} required/></td><td><input style={{width:110}} type="number" min="0" step="0.01" name={"discount_"+x.id} defaultValue={e?.discount??0}/></td></tr>})}
    </tbody></table></div>
    <label>แนบใบเสนอราคา (PDF/JPG/PNG/WEBP, สูงสุด 15MB)<input type="file" name="attachment" accept="application/pdf,image/jpeg,image/png,image/webp"/></label>
    <label>หมายเหตุ<textarea name="note" defaultValue={existing?.note||""}/></label>
    <button className="btn primary">บันทึก / ส่งราคา</button>
   </form>}
   <p className="muted" style={{marginTop:18}}>ลิงก์นี้เป็นลิงก์เฉพาะ Supplier และมีวันหมดอายุ กรุณาไม่ส่งต่อ</p>
  </div>
 </main>
}
