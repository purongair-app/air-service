import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function ServiceQuality(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:k},{data:months=[]},{data:techs=[]},{data:feedback=[]}]=await Promise.all([
  supabase.from("service_quality_summary").select("*").eq("organization_id",m.organization_id).maybeSingle(),
  supabase.from("service_quality_monthly").select("*").eq("organization_id",m.organization_id).order("month",{ascending:false}).limit(12),
  supabase.from("technician_service_quality").select("*").eq("organization_id",m.organization_id).order("avg_technician_rating",{ascending:false,nullsFirst:false}),
  supabase.from("service_surveys").select("*,jobs(work_no,service_name),customers(first_name,last_name,organization_name)").eq("organization_id",m.organization_id).eq("status","submitted").order("submitted_at",{ascending:false}).limit(100)
 ]);
 return <AppShell>
  <h1 className="page-title">Service Quality / Customer Experience</h1>
  <section className="grid cards">
   <div className="card"><div className="muted">Survey Response</div><div className="kpi">{Number(k?.response_rate_pct||0).toFixed(1)}%</div></div>
   <div className="card"><div className="muted">Service Rating</div><div className="kpi">{k?.avg_service_rating==null?"-":Number(k.avg_service_rating).toFixed(2)}</div></div>
   <div className="card"><div className="muted">Technician Rating</div><div className="kpi">{k?.avg_technician_rating==null?"-":Number(k.avg_technician_rating).toFixed(2)}</div></div>
   <div className="card"><div className="muted">NPS</div><div className="kpi">{k?.nps==null?"-":Number(k.nps).toFixed(1)}</div></div>
   <div className="card"><div className="muted">Response SLA</div><div className="kpi">{k?.response_sla_compliance_pct==null?"-":Number(k.response_sla_compliance_pct).toFixed(1)+"%"}</div></div>
   <div className="card"><div className="muted">Resolution SLA</div><div className="kpi">{k?.resolution_sla_compliance_pct==null?"-":Number(k.resolution_sla_compliance_pct).toFixed(1)+"%"}</div></div>
   <div className="card"><div className="muted">ยังไม่แก้ปัญหา</div><div className="kpi">{k?.unresolved_feedback||0}</div></div>
   <div className="card"><div className="muted">Low Feedback</div><div className="kpi">{k?.low_feedback||0}</div></div>
  </section>

  <section className="card" style={{marginTop:16}}><h3>แนวโน้มรายเดือน</h3><div className="table-wrap"><table><thead><tr><th>เดือน</th><th>Responses</th><th>Service</th><th>Technician</th><th>NPS</th><th>Unresolved</th><th>Low</th></tr></thead><tbody>
   {months.map((x:any)=><tr key={x.month}><td>{x.month}</td><td>{x.responses}</td><td>{x.avg_service_rating}</td><td>{x.avg_technician_rating}</td><td>{x.nps}</td><td>{x.unresolved_count}</td><td>{x.low_feedback_count}</td></tr>)}
  </tbody></table></div></section>

  <section className="card" style={{marginTop:16}}><h3>คุณภาพทีมช่าง</h3><div className="table-wrap"><table><thead><tr><th>ช่าง</th><th>งานเสร็จ</th><th>Surveys</th><th>Service</th><th>Tech Rating</th><th>NPS</th><th>Unresolved</th><th>Low</th></tr></thead><tbody>
   {techs.map((x:any)=><tr key={x.employee_id}><td>{x.full_name}</td><td>{x.completed_jobs}</td><td>{x.survey_responses}</td><td>{x.avg_service_rating??"-"}</td><td>{x.avg_technician_rating??"-"}</td><td>{x.nps??"-"}</td><td>{x.unresolved_feedback}</td><td>{x.low_feedback}</td></tr>)}
  </tbody></table></div></section>

  <section className="card" style={{marginTop:16}}><h3>Feedback ล่าสุด</h3><div className="grid">
   {feedback.map((x:any)=><article className="card" key={x.id}><div className="actions"><b>{x.jobs?.work_no||"-"} · {x.customers?.organization_name||[x.customers?.first_name,x.customers?.last_name].filter(Boolean).join(" ")}</b><span className="badge">NPS {x.nps_score}</span></div><div>บริการ {x.service_rating}/5 · ช่าง {x.technician_rating}/5 · {x.issue_resolved?"Resolved":"ยังไม่เรียบร้อย"}</div><p>{x.comment||""}</p><div className="actions">{(x.tags||[]).map((t:string)=><span className="badge" key={t}>{t}</span>)}</div></article>)}
  </div></section>
 </AppShell>
}
