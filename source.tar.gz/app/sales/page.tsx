import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

const labels:any={quote:"ใบเสนอราคา",invoice:"ใบแจ้งหนี้",billing:"ใบวางบิล",purchase_order:"ใบสั่งซื้อ",receipt:"ใบเสร็จ",cash_receipt:"ใบเสร็จเงินสด",credit_note:"ใบลดหนี้",debit_note:"ใบเพิ่มหนี้"};

export default async function SalesPage(){
 const member=await getCurrentMembership(); const supabase=await createClient();
 const {data=[]}=member?await supabase.from("sales_documents")
  .select("id,document_no,document_type,status,document_date,total,jobs(work_no),customers(first_name,last_name,organization_name)")
  .eq("organization_id",member.organization_id).order("created_at",{ascending:false}).limit(200):{data:[]};
 return <AppShell>
  <h1 className="page-title">เอกสารขาย</h1><p className="muted">ใบเสนอราคา ใบแจ้งหนี้ และใบเสร็จจากใบงาน</p>
  <div className="table-wrap"><table><thead><tr><th>เลขเอกสาร</th><th>ประเภท</th><th>ลูกค้า</th><th>ใบงาน</th><th>วันที่</th><th>ยอด</th><th>สถานะ</th></tr></thead>
  <tbody>{data.map((d:any)=>{const c=d.customers||{};return <tr key={d.id}><td><a href={"/sales/"+d.id}><b>{d.document_no}</b></a></td><td>{labels[d.document_type]||d.document_type}</td><td>{c.organization_name||[c.first_name,c.last_name].filter(Boolean).join(" ")||"-"}</td><td>{d.jobs?.work_no||"-"}</td><td>{d.document_date}</td><td>{Number(d.total||0).toLocaleString()}</td><td>{d.status}</td></tr>})}</tbody>
  </table>{!data.length&&<div className="empty">ยังไม่มีเอกสารขาย</div>}</div>
 </AppShell>
}
