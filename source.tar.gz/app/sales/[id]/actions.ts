"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

async function staff(){
 const m=await getCurrentMembership();
 if(!m || !["owner","manager","admin"].includes(m.role)) throw new Error("ไม่มีสิทธิ์จัดการเอกสาร");
 return m;
}

export async function collectPayment(formData:FormData){
 const m=await staff(); const supabase=await createClient();
 const id=String(formData.get("document_id")||"");
 const {data:doc}=await supabase.from("sales_documents").select("id,total,status").eq("id",id).single();
 if(!doc) throw new Error("ไม่พบเอกสาร");
 const {data:bal}=await supabase.from("sales_document_balance").select("*").eq("document_id",id).maybeSingle();
 const balance=Number(bal?.balance ?? doc.total);

 const methods=["cash","transfer","promptpay","credit_card","cheque","other"];
 const channels=methods.map(method=>({
  method,amount:Number(formData.get(`amount_${method}`)||0),
  bank:String(formData.get(`bank_${method}`)||"").trim(),
  reference:String(formData.get(`reference_${method}`)||"").trim()
 })).filter(x=>x.amount>0);

 const withholding=Number(formData.get("withholding")||0);
 const discount=Number(formData.get("discount_adjustment")||0);
 const increase=Number(formData.get("increase_adjustment")||0);
 const applied=channels.reduce((s,x)=>s+x.amount,0)+withholding+discount-increase;
 if(applied<=0) throw new Error("ยอดรับชำระต้องมากกว่า 0");
 if(applied>balance+0.005) throw new Error("ยอดรับชำระเกินยอดคงเหลือ");

 const {data:{user}}=await supabase.auth.getUser();
 const paymentNo=`PAY-${new Date().toISOString().slice(0,10).replaceAll("-","")}-${Date.now().toString().slice(-6)}`;
 const {data:receipt,error}=await supabase.from("payment_receipts").insert({
   organization_id:m.organization_id,
   sales_document_id:id,
   payment_no:paymentNo,
   paid_at:new Date().toISOString(),
   withholding,
   discount_adjustment:discount,
   increase_adjustment:increase,
   note:String(formData.get("note")||""),
   received_by:user?.id
 }).select("id").single();
 if(error) throw new Error(error.message);

 if(channels.length){
   const {error:ce}=await supabase.from("payment_channels").insert(channels.map(x=>({...x,payment_receipt_id:receipt.id})));
   if(ce) throw new Error(ce.message);
 }

 const remaining=Math.max(0,balance-applied);
 await supabase.from("sales_documents").update({status:remaining<=0.005?"paid":"partially_paid"}).eq("id",id);
 revalidatePath("/sales/"+id); revalidatePath("/sales");
}

export async function changeDocumentStatus(formData:FormData){
 await staff(); const supabase=await createClient();
 const id=String(formData.get("document_id")||"");
 const status=String(formData.get("status")||"");
 const allowed=["draft","approved","issued","cancelled"];
 if(!allowed.includes(status)) throw new Error("สถานะไม่ถูกต้อง");

 if(status==="issued"){
   const {error}=await supabase.rpc("issue_sales_document",{p_document:id});
   if(error)throw new Error(error.message);
 }else{
   const patch:any={status};
   if(status==="cancelled")patch.cancelled_at=new Date().toISOString();
   const {error}=await supabase.from("sales_documents").update(patch).eq("id",id);
   if(error)throw new Error(error.message);
 }
 revalidatePath("/sales/"+id); revalidatePath("/sales");
}

export async function createAdjustment(formData:FormData){
 const m=await staff(); const supabase=await createClient();
 const sourceId=String(formData.get("document_id")||"");
 const type=String(formData.get("adjustment_type")||"");
 if(!["credit_note","debit_note"].includes(type)) throw new Error("ประเภทเอกสารไม่ถูกต้อง");
 const amount=Number(formData.get("amount")||0);
 const reason=String(formData.get("reason")||"").trim();
 if(amount<=0||!reason) throw new Error("กรุณาระบุยอดและเหตุผล");

 const {data:source}=await supabase.from("sales_documents").select("*").eq("id",sourceId).single();
 if(!source) throw new Error("ไม่พบเอกสารต้นทาง");
 const {data:no,error:noErr}=await supabase.rpc("next_document_number",{p_org:m.organization_id,p_type:type});
 if(noErr) throw new Error(noErr.message);

 const {data:{user}}=await supabase.auth.getUser();
 const {error}=await supabase.from("sales_documents").insert({
   organization_id:m.organization_id,
   document_type:type,
   document_no:no,
   customer_id:source.customer_id,
   job_id:source.job_id,
   source_document_id:source.id,
   status:"issued",
   document_date:new Date().toISOString().slice(0,10),
   subtotal:amount,total:amount,
   reference_data:{reason,source_document_no:source.document_no},
   created_by:user?.id
 });
 if(error) throw new Error(error.message);
 revalidatePath("/sales/"+sourceId); revalidatePath("/sales");
}


export async function updateTaxSettings(formData:FormData){
 await staff(); const supabase=await createClient();
 const id=String(formData.get("document_id")||"");
 const taxInvoice=formData.get("tax_invoice")==="on";
 const vatRate=taxInvoice?Number(formData.get("vat_rate")||7):0;
 const amountBeforeTax=Number(formData.get("amount_before_tax")||0);
 const vatAmount=taxInvoice?Math.round(amountBeforeTax*vatRate)/100:0;
 const total=amountBeforeTax+vatAmount;
 const dueDate=String(formData.get("due_date")||"")||null;
 const {error}=await supabase.from("sales_documents").update({
  tax_invoice:taxInvoice,vat_rate:vatRate,amount_before_tax:amountBeforeTax,
  vat_amount:vatAmount,total,due_date:dueDate
 }).eq("id",id).in("status",["draft","approved"]);
 if(error)throw new Error(error.message);
 revalidatePath("/sales/"+id);
}
