import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";

const title:any={quote:"ใบเสนอราคา",invoice:"ใบแจ้งหนี้",billing:"ใบวางบิล",purchase_order:"ใบสั่งซื้อ",receipt:"ใบเสร็จรับเงิน",cash_receipt:"ใบเสร็จรับเงินสด",credit_note:"ใบลดหนี้",debit_note:"ใบเพิ่มหนี้"};

export default async function PrintDoc({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const supabase=await createClient();
 const [{data:d},{data:items=[]},{data:branding}] = await Promise.all([
  supabase.from("sales_documents").select("*,customers(*),organizations(*)").eq("id",id).maybeSingle(),
  supabase.from("sales_document_items").select("*").eq("document_id",id).order("sort_order"),
  supabase.from("sales_documents").select("organization_id").eq("id",id).single().then(async x=>{
    if(!x.data) return {data:null};
    return supabase.from("document_branding").select("*").eq("organization_id",x.data.organization_id).maybeSingle();
  })
 ]);
 if(!d) notFound(); const c:any=d.customers||{}; const org:any=d.organizations||{};
 return <main style={{maxWidth:850,margin:"30px auto",background:"#fff",padding:38,color:"#111"}}>
  <style>{`@media print{button{display:none!important} body{background:#fff!important} main{margin:0!important;max-width:none!important}} table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #ddd;padding:10px;text-align:left}`}</style>
  <div style={{float:"right",fontSize:12}}>ใช้คำสั่ง Print ของเบราว์เซอร์เพื่อพิมพ์หรือบันทึก PDF</div>
  <h2>{org.name||"AIRFRIEND SERVICE"}</h2><div>{org.address||""}</div><div>{org.phone||""} {org.email||""}</div>
  <hr/><h1>{title[d.document_type]||d.document_type}</h1>
  <div>เลขที่: <b>{d.document_no}</b></div><div>วันที่: {d.document_date}</div>
  <h3>ลูกค้า</h3><div>{c.organization_name||[c.first_name,c.last_name].filter(Boolean).join(" ")}</div><div>{c.phone||""}</div><div>{[c.house_no,c.village,c.road,c.subdistrict,c.district,c.province,c.postal_code].filter(Boolean).join(" ")}</div>
  <table style={{marginTop:24}}><thead><tr><th>รายการ</th><th>จำนวน</th><th>ราคาต่อหน่วย</th><th>ส่วนลด</th><th>รวม</th></tr></thead><tbody>
   {items.map((x:any)=><tr key={x.id}><td>{x.description}</td><td>{x.quantity}</td><td>{Number(x.unit_price).toLocaleString()}</td><td>{Number(x.discount).toLocaleString()}</td><td>{(Number(x.quantity)*Number(x.unit_price)-Number(x.discount)).toLocaleString()}</td></tr>)}
  </tbody></table>
  <div style={{textAlign:"right",fontSize:22,fontWeight:700,marginTop:24}}>ยอดรวม {Number(d.total||0).toLocaleString()} บาท</div>
  <div style={{marginTop:34}}><b>การชำระเงิน</b><div>{branding?.bank_name||""} {branding?.account_name||""} {branding?.account_number||""}</div><div>{branding?.promptpay_name||""} {branding?.promptpay_number||""}</div></div>
  <div style={{marginTop:70,display:"flex",justifyContent:"space-between"}}><div>____________________<br/>ผู้รับเอกสาร</div><div>____________________<br/>ผู้มีอำนาจลงนาม</div></div>
 </main>
}
