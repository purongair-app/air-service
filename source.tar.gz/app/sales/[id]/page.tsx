import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { collectPayment,changeDocumentStatus,createAdjustment,updateTaxSettings } from "./actions";
import { generatePdfArchive } from "./archive-actions";

const methodLabel:any={cash:"เงินสด",transfer:"โอนเงิน",promptpay:"พร้อมเพย์",credit_card:"บัตรเครดิต",cheque:"เช็ค",other:"อื่น ๆ"};

export default async function SalesDetail({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const supabase=await createClient();
 const [{data:doc},{data:items=[]},{data:balance},{data:receipts=[]},{data:adjustments=[]},{data:archives=[]}] = await Promise.all([
  supabase.from("sales_documents").select("*,customers(*),jobs(work_no)").eq("id",id).maybeSingle(),
  supabase.from("sales_document_items").select("*").eq("document_id",id).order("sort_order"),
  supabase.from("sales_document_balance").select("*").eq("document_id",id).maybeSingle(),
  supabase.from("payment_receipts").select("*,payment_channels(*)").eq("sales_document_id",id).order("paid_at",{ascending:false}),
  supabase.from("sales_documents").select("id,document_no,document_type,total,status,document_date,reference_data").eq("source_document_id",id).order("created_at",{ascending:false}),
  supabase.from("document_archives").select("*").eq("sales_document_id",id).order("version",{ascending:false})
 ]);
 if(!doc) notFound(); const c:any=doc.customers||{};
 return <AppShell>
  <div className="topbar"><div><h1 className="page-title">{doc.document_no}</h1><div className="muted">{doc.document_type} · {c.organization_name||[c.first_name,c.last_name].filter(Boolean).join(" ")}</div></div><span className="badge">{doc.status}</span></div>
  <div className="grid">
   <section className="card">
    <div className="form-grid"><div><b>วันที่</b><p>{doc.document_date}</p></div><div><b>ใบงาน</b><p>{doc.jobs?.work_no||"-"}</p></div></div>
    <div className="table-wrap"><table><thead><tr><th>รายการ</th><th>จำนวน</th><th>ราคา</th><th>ส่วนลด</th></tr></thead><tbody>{items.map((x:any)=><tr key={x.id}><td>{x.description}</td><td>{x.quantity}</td><td>{Number(x.unit_price).toLocaleString()}</td><td>{Number(x.discount).toLocaleString()}</td></tr>)}</tbody></table></div>
    <div className="grid cards" style={{marginTop:16}}>
      <div className="card"><div className="muted">ยอดเอกสาร</div><div className="kpi">{Number(doc.total||0).toLocaleString()}</div></div>
      <div className="card"><div className="muted">รับเงินแล้ว</div><div className="kpi">{Number(balance?.cash_received||0).toLocaleString()}</div></div>
      <div className="card"><div className="muted">หัก ณ ที่จ่าย</div><div className="kpi">{Number(balance?.withholding||0).toLocaleString()}</div></div>
      <div className="card"><div className="muted">คงเหลือ</div><div className="kpi">{Number(balance?.balance??doc.total).toLocaleString()}</div></div>
    </div>
   </section>

   <section className="card">
    <h3>รับชำระ</h3>
    <form action={collectPayment} className="form">
      <input type="hidden" name="document_id" value={doc.id}/>
      <div className="form-grid">
       {Object.entries(methodLabel).map(([value,label])=><div key={value} className="card">
        <b>{label as string}</b>
        <label>จำนวน<input type="number" min="0" step="0.01" name={`amount_${value}`} defaultValue="0"/></label>
        <label>ธนาคาร/ช่องทาง<input name={`bank_${value}`}/></label>
        <label>เลขอ้างอิง<input name={`reference_${value}`}/></label>
       </div>)}
      </div>
      <div className="form-grid">
       <label>หัก ณ ที่จ่าย<input type="number" name="withholding" min="0" step="0.01" defaultValue="0"/></label>
       <label>ส่วนลดเพิ่มเติม<input type="number" name="discount_adjustment" min="0" step="0.01" defaultValue="0"/></label>
       <label>เพิ่มยอด<input type="number" name="increase_adjustment" min="0" step="0.01" defaultValue="0"/></label>
      </div>
      <label>หมายเหตุ<textarea name="note"/></label>
      <div><button className="btn primary">บันทึกรับชำระ</button></div>
    </form>
   </section>

   <section className="card">
    <h3>ประวัติรับเงิน</h3>
    <div className="grid">{receipts.map((r:any)=><div className="card" key={r.id}>
      <b>{r.payment_no}</b><div className="muted">{new Date(r.paid_at).toLocaleString("th-TH")}</div>
      {(r.payment_channels||[]).map((x:any)=><div key={x.id}>{methodLabel[x.method]||x.method}: {Number(x.amount).toLocaleString()} {x.reference?`· ${x.reference}`:""}</div>)}
      {Number(r.withholding)>0&&<div>หัก ณ ที่จ่าย: {Number(r.withholding).toLocaleString()}</div>}
    </div>)}{!receipts.length&&<div className="muted">ยังไม่มีการรับชำระ</div>}</div>
   </section>

   <section className="card">
    <h3>ภาษี / วันครบกำหนด</h3>
    <form action={updateTaxSettings} className="form-grid">
      <input type="hidden" name="document_id" value={doc.id}/>
      <label><span><input type="checkbox" name="tax_invoice" defaultChecked={doc.tax_invoice}/> เอกสารภาษี</span></label>
      <label>VAT %<input type="number" min="0" max="100" step="0.01" name="vat_rate" defaultValue={doc.vat_rate||7}/></label>
      <label>มูลค่าก่อนภาษี<input type="number" min="0" step="0.01" name="amount_before_tax" defaultValue={doc.amount_before_tax||doc.subtotal||0}/></label>
      <label>วันครบกำหนด<input type="date" name="due_date" defaultValue={doc.due_date||""}/></label>
      <div><button className="btn light" disabled={!["draft","approved"].includes(doc.status)}>บันทึกภาษี</button></div>
    </form>
    <p className="muted">ข้อมูลนี้เป็นโครงระบบเอกสารและภาษี ควรให้ผู้ทำบัญชีตรวจรูปแบบ/ข้อความก่อนใช้ออกเอกสารภาษีจริง</p>
   </section>

   <section className="card">
    <h3>สถานะเอกสาร</h3>
    <form action={changeDocumentStatus} className="actions">
      <input type="hidden" name="document_id" value={doc.id}/>
      <button className="btn light" name="status" value="draft">Draft</button>
      <button className="btn primary" name="status" value="approved">อนุมัติ</button>
      <button className="btn primary" name="status" value="issued">ออกเอกสาร</button>
      <button className="btn danger" name="status" value="cancelled">ยกเลิก</button>
    </form>
   </section>

   {doc.document_type==="invoice"&&<section className="card">
    <h3>ใบลดหนี้ / ใบเพิ่มหนี้</h3>
    <form action={createAdjustment} className="form-grid">
      <input type="hidden" name="document_id" value={doc.id}/>
      <label>ประเภท<select name="adjustment_type"><option value="credit_note">ใบลดหนี้</option><option value="debit_note">ใบเพิ่มหนี้</option></select></label>
      <label>จำนวนเงิน<input name="amount" type="number" min="0.01" step="0.01" required/></label>
      <label style={{gridColumn:"1/-1"}}>เหตุผล<textarea name="reason" required/></label>
      <div><button className="btn primary">สร้างเอกสารปรับหนี้</button></div>
    </form>
    <div className="grid" style={{marginTop:16}}>{adjustments.map((a:any)=><div key={a.id} className="badge">{a.document_no} · {a.document_type} · {Number(a.total).toLocaleString()} · {a.status}</div>)}</div>
   </section>}

   <section className="card">
    <h3>PDF / Document Archive</h3>
    <div className="actions">
      <a className="btn light" href={"/sales/"+doc.id+"/print"} target="_blank">ตัวอย่างพิมพ์</a>
      <form action={generatePdfArchive}><input type="hidden" name="document_id" value={doc.id}/><button className="btn primary" disabled={!["issued","paid","partially_paid"].includes(doc.status)}>สร้าง PDF Archive ฝั่ง Server</button></form>
    </div>
    <div className="grid" style={{marginTop:12}}>
      {archives.map((a:any)=><div className="card" key={a.id}><b>Version {a.version}</b><div className="muted">{new Date(a.generated_at).toLocaleString("th-TH")} · SHA256 {String(a.sha256||"").slice(0,12)}…</div><a className="btn light" target="_blank" href={"/api/private-file?bucket=generated-documents&path="+encodeURIComponent(a.storage_path)}>เปิด PDF</a></div>)}
      {!archives.length&&<div className="muted">ยังไม่มี PDF Archive</div>}
    </div>
   </section>
  </div>
 </AppShell>
}
