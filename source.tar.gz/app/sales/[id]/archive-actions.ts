"use server";
import crypto from "node:crypto";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { renderSalesPdf } from "@/lib/documents/pdf";

export async function generatePdfArchive(formData:FormData){
 const id=String(formData.get("document_id")||"");
 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user)throw new Error("กรุณาเข้าสู่ระบบ");

 const [{data:doc,error:docErr},{data:items=[]},{data:balance}] = await Promise.all([
  supabase.from("sales_documents").select("*,customers(*),organizations(*)").eq("id",id).single(),
  supabase.from("sales_document_items").select("*").eq("document_id",id).order("sort_order"),
  supabase.from("sales_document_balance").select("*").eq("document_id",id).maybeSingle()
 ]);
 if(docErr||!doc)throw new Error(docErr?.message||"ไม่พบเอกสาร");
 if(!["issued","paid","partially_paid"].includes(doc.status))throw new Error("ต้องออกเอกสารก่อนสร้าง PDF Archive");

 const {data:branding}=await supabase.from("document_branding").select("*").eq("organization_id",doc.organization_id).maybeSingle();
 const buffer=await renderSalesPdf({doc,items,branding,balance});
 const sha256=crypto.createHash("sha256").update(buffer).digest("hex");

 const {data:last}=await supabase.from("document_archives").select("version")
   .eq("sales_document_id",id).order("version",{ascending:false}).limit(1).maybeSingle();
 const version=Number(last?.version||0)+1;
 const safeNo=String(doc.document_no).replace(/[^A-Za-z0-9._-]+/g,"-");
 const path=`${doc.organization_id}/sales/${doc.id}/${safeNo}-v${version}.pdf`;

 const {error:upErr}=await supabase.storage.from("generated-documents").upload(path,buffer,{
  contentType:"application/pdf",upsert:false
 });
 if(upErr)throw new Error(upErr.message);

 const snapshot={
  document:{...doc,customers:undefined,organizations:undefined},
  customer:doc.customer_snapshot,
  issuer:doc.issuer_snapshot,
  items,
  balance
 };
 const {error:archiveErr}=await supabase.from("document_archives").insert({
  organization_id:doc.organization_id,sales_document_id:doc.id,document_no:doc.document_no,
  version,storage_path:path,file_size:buffer.length,sha256,snapshot,generated_by:user.id
 });
 if(archiveErr)throw new Error(archiveErr.message);

 await supabase.from("sales_documents").update({archive_path:path,archive_version:version}).eq("id",id);
 revalidatePath("/sales/"+id);
 revalidatePath("/portal/documents");
}
