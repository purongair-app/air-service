"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

export async function setJobStatus(formData:FormData){
 const jobId=String(formData.get("job_id")||"");
 const status=String(formData.get("status")||"");
 const allowed=["traveling","in_progress","waiting_parts","technician_submitted"];
 if(!allowed.includes(status)) throw new Error("สถานะไม่ถูกต้อง");

 const supabase=await createClient();
 const {error}=await supabase.rpc("technician_set_job_status",{
   p_job:jobId,
   p_status:status
 });
 if(error){
   if(error.message.includes("invalid_status_transition"))throw new Error("ไม่สามารถเปลี่ยนสถานะข้ามลำดับงานได้");
   if(error.message.includes("forbidden"))throw new Error("กรุณารับงานก่อนเปลี่ยนสถานะ");
   throw new Error(error.message);
 }
 revalidatePath("/technician/jobs/"+jobId);
 revalidatePath("/technician");
}
