import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { notFound } from "next/navigation";
import { setJobStatus } from "./actions";
import { saveInspection } from "./inspection-actions";
import GpsCheckin from "@/components/gps-checkin";
import JobPhotoUpload from "@/components/job-photo-upload";

export default async function TechnicianJobPage({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const member=await getCurrentMembership(); const supabase=await createClient();
 if(!member?.employee_id) notFound();

 const [{data:assignment},{data:inspections=[]},{data:photos=[]},{data:checkins=[]},{data:timeline=[]}] = await Promise.all([
   supabase.from("job_assignments").select("accepted_at,jobs(*)").eq("job_id",id).eq("employee_id",member.employee_id).maybeSingle(),
   supabase.from("field_inspections").select("*").eq("job_id",id).order("inspected_at",{ascending:false}),
   supabase.from("job_photos").select("id,category,label,storage_path,uploaded_at").eq("job_id",id).order("uploaded_at",{ascending:false}),
   supabase.from("job_checkins").select("latitude,longitude,accuracy_m,checked_in_at").eq("job_id",id).order("checked_in_at",{ascending:false}),
   supabase.from("job_timeline").select("detail,actor_name,occurred_at").eq("job_id",id).order("occurred_at",{ascending:false}).limit(30)
 ]);

 if(!assignment?.jobs) notFound();
 const j:any=assignment.jobs;

 return <AppShell>
  <h1 className="page-title">{j.work_no}</h1><p className="muted">{j.customer_name_snapshot} · {j.service_name}</p>

  <div className="grid">
   <div className="card">
    <b>สถานที่</b><p>{j.address_snapshot||"-"}</p>
    <b>นัดหมาย</b><p>{j.appointment_date||"-"} {j.appointment_time_label||""}</p>
    <b>รายละเอียด</b><p>{j.note||"-"}</p>
   </div>

   <div className="card">
    <h3>สถานะงาน</h3>
    <form action={setJobStatus} className="actions">
     <input type="hidden" name="job_id" value={j.id}/>
     <button className="btn light" name="status" value="traveling">กำลังเดินทาง</button>
     <button className="btn primary" name="status" value="in_progress">เริ่มงาน</button>
     <button className="btn light" name="status" value="waiting_parts">รออะไหล่</button>
     <button className="btn primary" name="status" value="technician_submitted">ส่งงานตรวจรับ</button>
    </form>
   </div>

   <GpsCheckin jobId={j.id} organizationId={member.organization_id}/>
   <JobPhotoUpload jobId={j.id} organizationId={member.organization_id}/>

   <div className="card">
    <h3>บันทึกตรวจซ่อมหน้างาน</h3>
    <form action={saveInspection} className="form-grid">
      <input type="hidden" name="job_id" value={j.id}/>
      <label>สถานที่<input name="location" defaultValue={j.address_snapshot||""}/></label>
      <label>ยี่ห้อ<input name="brand" placeholder="DAIKIN" required/></label>
      <label>BTU<input name="btu" inputMode="numeric"/></label>
      <label>รุ่น<input name="model"/></label>
      <label>ชนิดน้ำยา<input name="refrigerant" placeholder="R32"/></label>
      <label>แรงดัน PSI<input name="pressure_psi" inputMode="decimal"/></label>
      <label>กระแส Amp<input name="current_amp" inputMode="decimal"/></label>
      <label>แรงดันไฟ Volt<input name="voltage" inputMode="decimal"/></label>
      <label>อุณหภูมิ Inlet คอยล์เย็น<input name="indoor_inlet_temp" inputMode="decimal"/></label>
      <label>อุณหภูมิ Outlet คอยล์เย็น<input name="indoor_outlet_temp" inputMode="decimal"/></label>
      <label>อุณหภูมิ Inlet คอยล์ร้อน<input name="outdoor_inlet_temp" inputMode="decimal"/></label>
      <label>อุณหภูมิ Outlet คอยล์ร้อน<input name="outdoor_outlet_temp" inputMode="decimal"/></label>
      <label style={{gridColumn:"1/-1"}}>โค้ด/อาการเสีย<textarea name="fault_code"/></label>
      <label>ผลตรวจ<select name="result_status"><option>ตรวจสอบแล้ว</option><option>ซ่อมเสร็จ</option><option>รออะไหล่</option><option>ต้องเสนอราคา</option></select></label>
      <label style={{gridColumn:"1/-1"}}>รายละเอียดการตรวจซ่อม<textarea name="repair_note"/></label>
      <div><button className="btn primary">บันทึกผลตรวจ</button></div>
    </form>
   </div>

   <div className="card">
    <h3>ข้อมูลล่าสุด</h3>
    <div className="grid">
      <div><b>เช็กอิน:</b> {checkins.length} ครั้ง</div>
      <div><b>บันทึกตรวจซ่อม:</b> {inspections.length} รายการ</div>
      <div><b>รูปหน้างาน:</b> {photos.length} รูป</div>
    </div>
   </div>

   <div className="card">
    <h3>Timeline</h3>
    <div className="grid">{timeline.map((t:any,i:number)=><div key={i} style={{borderBottom:"1px solid #e5e7eb",paddingBottom:10}}>
      <div>{t.detail}</div><small className="muted">{t.actor_name||"-"} · {new Date(t.occurred_at).toLocaleString("th-TH")}</small>
    </div>)}{!timeline.length&&<div className="muted">ยังไม่มี Timeline</div>}</div>
   </div>
  </div>
 </AppShell>
}
