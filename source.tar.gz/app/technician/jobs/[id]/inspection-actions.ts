"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

function n(v:FormDataEntryValue|null){
 const s=String(v||"").trim();
 return s===""?null:Number(s);
}

export async function saveInspection(formData:FormData){
 const member=await getCurrentMembership(); if(!member?.employee_id) throw new Error("บัญชีนี้ยังไม่เชื่อมข้อมูลพนักงาน");
 const supabase=await createClient();
 const jobId=String(formData.get("job_id")||"");
 const brand=String(formData.get("brand")||"").trim().toUpperCase();
 if(!brand) throw new Error("กรุณาระบุยี่ห้อ");

 const {data:{user}}=await supabase.auth.getUser();
 const payload={
  organization_id:member.organization_id,
  job_id:jobId,
  location:String(formData.get("location")||""),
  brand,
  btu:n(formData.get("btu")),
  fault_code:String(formData.get("fault_code")||""),
  model:String(formData.get("model")||"").toUpperCase(),
  refrigerant:String(formData.get("refrigerant")||""),
  pressure_psi:n(formData.get("pressure_psi")),
  current_amp:n(formData.get("current_amp")),
  voltage:n(formData.get("voltage")),
  indoor_inlet_temp:n(formData.get("indoor_inlet_temp")),
  indoor_outlet_temp:n(formData.get("indoor_outlet_temp")),
  outdoor_inlet_temp:n(formData.get("outdoor_inlet_temp")),
  outdoor_outlet_temp:n(formData.get("outdoor_outlet_temp")),
  result_status:String(formData.get("result_status")||"ตรวจสอบแล้ว"),
  repair_note:String(formData.get("repair_note")||""),
  recorder_user_id:user?.id,
  recorder_employee_id:member.employee_id,
  inspected_at:new Date().toISOString()
 };
 const {error}=await supabase.from("field_inspections").insert(payload);
 if(error) throw new Error(error.message);
 await supabase.from("job_timeline").insert({
   organization_id:member.organization_id,
   job_id:jobId,
   detail:`บันทึกผลตรวจซ่อมหน้างาน: ${payload.result_status}`,
   actor_user_id:user?.id,
   actor_name:user?.email||"ทีมช่าง",
   occurred_at:new Date().toISOString()
 });
 revalidatePath("/technician/jobs/"+jobId);
}
