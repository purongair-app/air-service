import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { acceptJob } from "./actions";

export default async function TechnicianPage(){
 const member=await getCurrentMembership(); const supabase=await createClient();
 let rows:any[]=[];
 if(member?.employee_id){
   const {data}=await supabase.from("job_assignments")
     .select("id,accepted_at,role_label,jobs(id,work_no,customer_name_snapshot,service_name,address_snapshot,appointment_date,appointment_time_label,status,note)")
     .eq("employee_id",member.employee_id).order("assigned_at",{ascending:false});
   rows=data||[];
 }
 return <AppShell>
  <h1 className="page-title">งานของทีมช่าง</h1><p className="muted">รับงาน ดูสถานที่ และดำเนินงานภาคสนาม</p>
  <div className="grid">{rows.map((a:any)=>{const j=a.jobs;return <article key={a.id} className="card tech-job">
   <div><b>{j.work_no}</b> · {j.customer_name_snapshot}</div>
   <div>{j.service_name} · {j.appointment_date||"-"} {j.appointment_time_label||""}</div>
   <div className="muted">{j.address_snapshot||"-"}</div>
   <div className="actions">
    {!a.accepted_at?<form action={acceptJob}><input type="hidden" name="job_id" value={j.id}/><button className="btn primary">รับงาน</button></form>:<span className="badge">รับงานแล้ว</span>}
    <a className="btn light" href={"/technician/jobs/"+j.id}>เปิดใบงาน</a>
   </div>
  </article>})}{!rows.length&&<div className="card empty">ยังไม่มีงานที่มอบหมายให้บัญชีนี้</div>}</div>
 </AppShell>
}
