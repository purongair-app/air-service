"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function acceptJob(formData:FormData){
 const member=await getCurrentMembership();
 if(!member?.employee_id||member.role!=="technician")throw new Error("บัญชีนี้ยังไม่เชื่อมพนักงานช่าง");
 const jobId=String(formData.get("job_id")||"");
 const supabase=await createClient();
 const {error}=await supabase.rpc("technician_accept_job",{p_job:jobId});
 if(error)throw new Error(error.message);
 revalidatePath("/technician");
 revalidatePath("/technician/jobs/"+jobId);
}
