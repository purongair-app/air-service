import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { saveSupplier } from "./actions";

export default async function Suppliers(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const {data=[]}=await supabase.from("suppliers").select("*").eq("organization_id",m.organization_id).order("name");
 return <AppShell>
  <h1 className="page-title">ผู้ขาย / Supplier</h1>
  <section className="card" style={{marginBottom:16}}>
   <form action={saveSupplier} className="form-grid">
    <label>ชื่อผู้ขาย<input name="name" required/></label><label>ผู้ติดต่อ<input name="contact_name"/></label>
    <label>โทรศัพท์<input name="phone"/></label><label>Email<input type="email" name="email"/></label>
    <label>เลขภาษี<input name="tax_id"/></label><label>สาขา<input name="branch_no"/></label>
    <label>เครดิต (วัน)<input type="number" min="0" name="payment_terms_days" defaultValue="0"/></label>
    <label>ธนาคาร<input name="bank_name"/></label><label>ชื่อบัญชี<input name="bank_account_name"/></label>
    <label>เลขบัญชี<input name="bank_account_number"/></label>
    <label style={{gridColumn:"1/-1"}}>ที่อยู่<textarea name="address"/></label>
    <label style={{gridColumn:"1/-1"}}>หมายเหตุ<textarea name="note"/></label>
    <div><button className="btn primary">เพิ่มผู้ขาย</button></div>
   </form>
  </section>
  <div className="table-wrap"><table><thead><tr><th>รหัส</th><th>ผู้ขาย</th><th>ผู้ติดต่อ</th><th>โทร</th><th>เครดิต</th><th>ภาษี</th><th>สถานะ</th></tr></thead><tbody>
   {data.map((s:any)=><tr key={s.id}><td>{s.supplier_no}</td><td><b>{s.name}</b></td><td>{s.contact_name||"-"}</td><td>{s.phone||"-"}</td><td>{s.payment_terms_days} วัน</td><td>{s.tax_id||"-"}</td><td>{s.active?"Active":"Off"}</td></tr>)}
  </tbody></table>{!data.length&&<div className="empty">ยังไม่มีผู้ขาย</div>}</div>
 </AppShell>
}
