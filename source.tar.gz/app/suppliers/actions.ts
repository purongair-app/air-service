"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function saveSupplier(formData:FormData){
 const m=await getCurrentMembership();
 if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient();
 const {data:no,error:noErr}=await supabase.rpc("next_procurement_number",{p_org:m.organization_id,p_code:"SUP"});
 if(noErr)throw new Error(noErr.message);
 const {error}=await supabase.from("suppliers").insert({
  organization_id:m.organization_id,supplier_no:no,
  name:String(formData.get("name")||""),contact_name:String(formData.get("contact_name")||""),
  phone:String(formData.get("phone")||""),email:String(formData.get("email")||""),
  tax_id:String(formData.get("tax_id")||""),branch_no:String(formData.get("branch_no")||""),
  address:String(formData.get("address")||""),
  payment_terms_days:Number(formData.get("payment_terms_days")||0),
  bank_name:String(formData.get("bank_name")||""),
  bank_account_name:String(formData.get("bank_account_name")||""),
  bank_account_number:String(formData.get("bank_account_number")||""),
  note:String(formData.get("note")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/suppliers");
}
