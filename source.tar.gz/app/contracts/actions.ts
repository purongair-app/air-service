"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function saveContract(formData:FormData){
 const m=await getCurrentMembership(); if(!m||!["owner","manager","admin"].includes(m.role))throw new Error("ไม่มีสิทธิ์");
 const supabase=await createClient();
 const {error}=await supabase.from("service_contracts").insert({
  organization_id:m.organization_id,contract_no:`CTR-${Date.now().toString().slice(-7)}`,
  customer_id:String(formData.get("customer_id")||""),package_name:String(formData.get("package_name")||""),
  service_count:Number(formData.get("service_count")||1),used_count:0,
  contract_value:Number(formData.get("contract_value")||0),
  start_date:String(formData.get("start_date")||""),end_date:String(formData.get("end_date")||""),
  next_service_date:String(formData.get("next_service_date")||"")||null,status:"active",
  schedule_mode:String(formData.get("schedule_mode")||"manual"),note:String(formData.get("note")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/contracts");
}

export async function createServiceVisit(formData:FormData){
 const m=await getCurrentMembership(); if(!m)throw new Error("ไม่มี membership");
 const supabase=await createClient(); const contractId=String(formData.get("contract_id")||"");
 const {data:c}=await supabase.from("service_contracts").select("customer_id").eq("id",contractId).single();
 if(!c)throw new Error("ไม่พบสัญญา");
 const {error}=await supabase.from("service_visits").insert({
   organization_id:m.organization_id,contract_id:contractId,customer_id:c.customer_id,
   scheduled_date:String(formData.get("scheduled_date")||""),service_type:String(formData.get("service_type")||"PM"),
   status:"scheduled",note:String(formData.get("note")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/contracts");
}


export async function createJobFromVisit(formData:FormData){
 const supabase=await createClient();
 const visitId=String(formData.get("visit_id")||"");
 const {data,error}=await supabase.rpc("create_job_from_service_visit",{p_visit:visitId});
 if(error)throw new Error(error.message);
 revalidatePath("/contracts");
 revalidatePath("/jobs");
}


export async function completeServiceVisit(formData:FormData){
 const supabase=await createClient();
 const visitId=String(formData.get("visit_id")||"");
 const note=String(formData.get("note")||"");
 const {error}=await supabase.rpc("complete_service_visit",{p_visit:visitId,p_note:note});
 if(error)throw new Error(error.message);
 revalidatePath("/contracts");
 revalidatePath("/portal/contracts");
}
