import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { saveContract,createServiceVisit,createJobFromVisit,completeServiceVisit } from "./actions";

export default async function Contracts(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:contracts=[]},{data:customers=[]},{data:visits=[]}]=await Promise.all([
   supabase.from("service_contracts").select("*,customers(first_name,last_name,organization_name)").eq("organization_id",m.organization_id).order("created_at",{ascending:false}),
   supabase.from("customers").select("id,customer_no,first_name,last_name,organization_name").eq("organization_id",m.organization_id).order("created_at",{ascending:false}).limit(500),
   supabase.from("service_visits").select("*,customers(first_name,last_name,organization_name)").eq("organization_id",m.organization_id).order("scheduled_date")
 ]);
 return <AppShell><h1 className="page-title">สัญญาบริการ / PM</h1>
 <div className="grid">
  <section className="card"><h3>สร้างสัญญา</h3><form action={saveContract} className="form-grid">
   <label>ลูกค้า<select name="customer_id">{customers.map((c:any)=><option key={c.id} value={c.id}>{c.customer_no} · {c.organization_name||[c.first_name,c.last_name].filter(Boolean).join(" ")}</option>)}</select></label>
   <label>ชื่อแพ็กเกจ<input name="package_name" required/></label><label>จำนวนครั้ง<input type="number" name="service_count" defaultValue="4"/></label>
   <label>มูลค่าสัญญา<input type="number" step="0.01" name="contract_value"/></label>
   <label>วันเริ่ม<input type="date" name="start_date" required/></label><label>วันสิ้นสุด<input type="date" name="end_date" required/></label>
   <label>บริการถัดไป<input type="date" name="next_service_date"/></label><label>รอบ<select name="schedule_mode"><option value="manual">กำหนดเอง</option><option value="every3months">ทุก 3 เดือน</option></select></label>
   <label style={{gridColumn:"1/-1"}}>หมายเหตุ<textarea name="note"/></label><div><button className="btn primary">สร้างสัญญา</button></div>
  </form></section>
  <section className="card"><h3>สร้างนัด PM</h3><form action={createServiceVisit} className="form-grid">
   <label>สัญญา<select name="contract_id">{contracts.map((x:any)=><option key={x.id} value={x.id}>{x.contract_no} · {x.package_name}</option>)}</select></label>
   <label>วันที่<input type="date" name="scheduled_date" required/></label><label>บริการ<input name="service_type" defaultValue="PM"/></label>
   <label>หมายเหตุ<input name="note"/></label><div><button className="btn primary">เพิ่มนัดบริการ</button></div>
  </form></section>
  <section className="table-wrap"><table><thead><tr><th>สัญญา</th><th>ลูกค้า</th><th>แพ็กเกจ</th><th>ใช้แล้ว</th><th>สิ้นสุด</th><th>บริการถัดไป</th><th>สถานะ</th></tr></thead><tbody>
   {contracts.map((x:any)=><tr key={x.id}><td>{x.contract_no}</td><td>{x.customers?.organization_name||[x.customers?.first_name,x.customers?.last_name].filter(Boolean).join(" ")}</td><td>{x.package_name}</td><td>{x.used_count}/{x.service_count}</td><td>{x.end_date}</td><td>{x.next_service_date||"-"}</td><td>{x.status}</td></tr>)}
  </tbody></table></section>
  <section className="card"><h3>นัด PM / Service Visits</h3>
   <div className="table-wrap"><table><thead><tr><th>วันที่</th><th>ลูกค้า</th><th>บริการ</th><th>สถานะ</th><th>Job</th></tr></thead><tbody>
    {visits.map((v:any)=><tr key={v.id}><td>{v.scheduled_date||"-"}</td><td>{v.customers?.organization_name||[v.customers?.first_name,v.customers?.last_name].filter(Boolean).join(" ")}</td><td>{v.service_type||"-"}</td><td>{v.status}</td><td>{v.status==="completed"?"เสร็จแล้ว":<div className="actions">{v.job_id?<span className="badge">มีใบงานแล้ว</span>:<form action={createJobFromVisit}><input type="hidden" name="visit_id" value={v.id}/><button className="btn light">สร้างใบงาน</button></form>}<form action={completeServiceVisit}><input type="hidden" name="visit_id" value={v.id}/><button className="btn primary">ปิด PM</button></form></div>}</td></tr>)}
   </tbody></table></div>
  </section>
 </div></AppShell>
}
