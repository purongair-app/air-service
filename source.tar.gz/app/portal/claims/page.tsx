import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";
import { createWarrantyClaim } from "./actions";

export default async function PortalClaims(){
 const m=await getCustomerMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:claims=[]},{data:equipment=[]}]=await Promise.all([
  supabase.from("warranty_claim_sla_status").select("*").eq("customer_id",m.customer_id).order("warranty_claim_id",{ascending:false}),
  supabase.from("customer_equipment").select("id,equipment_no,brand,model,btu,install_location").eq("customer_id",m.customer_id).order("created_at",{ascending:false})
 ]);
 return <CustomerShell>
  <h1 className="page-title">แจ้งปัญหา / เคลม</h1>
  <section className="card" style={{marginBottom:16}}>
   <form action={createWarrantyClaim} className="form-grid">
    <label>เครื่องแอร์<select name="equipment_id"><option value="">ไม่ระบุเครื่อง</option>{equipment.map((e:any)=><option key={e.id} value={e.id}>{e.equipment_no} · {e.brand||"-"} {e.model||""} · {e.install_location||"-"}</option>)}</select></label>
    <label>ความเร่งด่วน<select name="priority"><option value="low">ไม่เร่งด่วน</option><option value="normal">ปกติ</option><option value="high">เร่งด่วน</option><option value="urgent">เร่งด่วนมาก</option></select></label>
    <label>หัวข้อ<input name="subject" required/></label>
    <label>ช่องทางติดต่อที่สะดวก<select name="preferred_contact"><option value="phone">โทรศัพท์</option><option value="line">LINE</option><option value="email">Email</option></select></label>
    <label>วันที่สะดวกให้เข้าตรวจ<input type="date" name="preferred_visit_date"/></label>
    <label style={{gridColumn:"1/-1"}}>รายละเอียดอาการ<textarea name="description" required/></label>
    <label style={{gridColumn:"1/-1"}}>รูป/ไฟล์หลักฐาน สูงสุด 5 ไฟล์<input type="file" name="attachments" multiple accept="image/jpeg,image/png,image/webp,application/pdf"/></label>
    <div><button className="btn primary">ส่งเรื่อง</button></div>
   </form>
  </section>
  <div className="grid">{claims.map((c:any)=><a className="card" href={"/portal/claims/"+c.warranty_claim_id} key={c.warranty_claim_id}>
   <div className="actions"><b>{c.claim_no}</b><span className="badge">{c.status}</span></div>
   <h3>{c.subject}</h3>
   <div className="muted">Priority {c.priority} · Escalation L{c.escalation_level}</div>
   <div>Response SLA: {c.response_sla_breached?"เกิน SLA":c.first_responded_at?"ตอบรับแล้ว":`${c.response_hours_remaining??"-"} ชม.`}</div>
   <div>Resolution SLA: {c.resolution_sla_breached?"เกิน SLA":`${c.resolution_hours_remaining??"-"} ชม.`}</div>
  </a>)}{!claims.length&&<div className="card empty">ยังไม่มีรายการแจ้งปัญหา</div>}</div>
 </CustomerShell>
}
