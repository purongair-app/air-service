import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";

export default async function PortalClaim({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const supabase=await createClient();
 const [{data:c},{data:events=[]},{data:attachments=[]}]=await Promise.all([
  supabase.from("warranty_claims").select("*,customer_equipment(equipment_no,brand,model,btu,install_location),jobs(work_no,status,appointment_date,appointment_time_label)").eq("id",id).maybeSingle(),
  supabase.from("warranty_claim_events").select("*").eq("warranty_claim_id",id).eq("visibility","customer").order("occurred_at"),
  supabase.from("warranty_claim_attachments").select("*").eq("warranty_claim_id",id).order("uploaded_at")
 ]);
 if(!c)notFound();
 return <CustomerShell>
  <div className="actions"><div><h1 className="page-title">{c.claim_no}</h1><p className="muted">{c.status} · Priority {c.priority}</p></div><a className="btn light" href="/portal/claims">กลับ</a></div>
  <section className="grid">
   <div className="card"><h3>{c.subject}</h3><p>{c.description}</p><div className="muted">เครื่อง: {c.customer_equipment?`${c.customer_equipment.equipment_no} · ${c.customer_equipment.brand||"-"} ${c.customer_equipment.model||""}`:"ไม่ระบุ"}</div>{c.jobs&&<p>ใบงาน: <a href={"/portal/jobs/"+c.job_id}>{c.jobs.work_no}</a> · {c.jobs.status}</p>}</div>
   <div className="card"><h3>SLA</h3><div>Response Due: {c.response_due_at?new Date(c.response_due_at).toLocaleString("th-TH"):"-"}</div><div>Resolution Due: {c.resolution_due_at?new Date(c.resolution_due_at).toLocaleString("th-TH"):"-"}</div><div>Escalation: Level {c.escalation_level}</div></div>
   <div className="card"><h3>ไฟล์หลักฐาน</h3>{attachments.map((a:any)=><div key={a.id}><a className="btn light" target="_blank" href={"/api/private-file?bucket=business-documents&path="+encodeURIComponent(a.storage_path)}>{a.original_name||"เปิดไฟล์"}</a></div>)}{!attachments.length&&<div className="muted">ไม่มีไฟล์แนบ</div>}</div>
   <div className="card"><h3>ความคืบหน้า</h3>{events.map((e:any)=><div key={e.id} style={{borderBottom:"1px solid #eee",padding:"8px 0"}}><b>{e.event}</b><div>{e.detail||"-"}</div><small className="muted">{new Date(e.occurred_at).toLocaleString("th-TH")}</small></div>)}</div>
  </section>
 </CustomerShell>
}
