"use server";
import crypto from "node:crypto";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getCustomerMembership } from "@/lib/customer";

const allowed=new Set(["image/jpeg","image/png","image/webp","application/pdf"]);
const maxBytes=15*1024*1024;

async function uploadClaimFile(claim:any,file:File,userId:string){
 if(file.size<=0)return;
 if(file.size>maxBytes)throw new Error("ไฟล์ต้องไม่เกิน 15 MB");
 if(!allowed.has(file.type))throw new Error("รองรับ PDF/JPG/PNG/WEBP เท่านั้น");

 const admin=createAdminClient();
 const bytes=Buffer.from(await file.arrayBuffer());
 const sha256=crypto.createHash("sha256").update(bytes).digest("hex");
 const safe=file.name.replace(/[^A-Za-z0-9._-]+/g,"-").slice(0,100)||"evidence";
 const path=`${claim.organization_id}/warranty-claims/${claim.customer_id}/${claim.id}/${Date.now()}-${safe}`;

 const {error:up}=await admin.storage.from("business-documents").upload(path,bytes,{
  contentType:file.type,upsert:false
 });
 if(up)throw new Error(up.message);

 const {error:meta}=await admin.from("warranty_claim_attachments").insert({
  organization_id:claim.organization_id,warranty_claim_id:claim.id,customer_id:claim.customer_id,
  storage_path:path,original_name:file.name,mime_type:file.type,file_size:file.size,
  sha256,category:"customer_evidence",uploaded_by:userId
 });
 if(meta)throw new Error(meta.message);
}

export async function createWarrantyClaim(formData:FormData){
 const m=await getCustomerMembership(); if(!m)throw new Error("ไม่พบบัญชีลูกค้า");
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
 const equipmentId=String(formData.get("equipment_id")||"")||null;
 const {data:claim,error}=await supabase.rpc("customer_create_warranty_claim",{
  p_org:m.organization_id,p_equipment:equipmentId,
  p_subject:String(formData.get("subject")||""),
  p_description:String(formData.get("description")||""),
  p_priority:String(formData.get("priority")||"normal"),
  p_preferred_contact:String(formData.get("preferred_contact")||""),
  p_preferred_visit_date:String(formData.get("preferred_visit_date")||"")||null
 });
 if(error)throw new Error(error.message);

 const files=formData.getAll("attachments").filter((x):x is File=>x instanceof File&&x.size>0).slice(0,5);
 for(const f of files)await uploadClaimFile(claim,f,user!.id);

 redirect("/portal/claims/"+claim.id);
}
