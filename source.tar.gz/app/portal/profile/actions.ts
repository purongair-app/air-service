"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";

export async function saveContact(formData:FormData){
 const m=await getCustomerMembership(); if(!m)throw new Error("ไม่พบบัญชีลูกค้า");
 const supabase=await createClient();
 const {error}=await supabase.rpc("customer_update_my_contact",{
  p_org:m.organization_id,
  p_phone:String(formData.get("phone")||""),
  p_phone_secondary:String(formData.get("phone_secondary")||""),
  p_email:String(formData.get("email")||""),
  p_notes:String(formData.get("notes")||"")
 });
 if(error)throw new Error(error.message);
 revalidatePath("/portal/profile");
}
