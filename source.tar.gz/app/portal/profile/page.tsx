import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";
import { saveContact } from "./actions";

export default async function Profile(){
 const m=await getCustomerMembership(); const supabase=await createClient();
 const {data:c}=m?await supabase.from("customers").select("*").eq("id",m.customer_id).maybeSingle():{data:null};
 if(!c)return <CustomerShell><div className="card empty">ไม่พบข้อมูลลูกค้า</div></CustomerShell>;
 return <CustomerShell><h1 className="page-title">ข้อมูลติดต่อ</h1>
 <section className="card"><div className="form-grid"><div><b>รหัสลูกค้า</b><p>{c.customer_no}</p></div><div><b>ชื่อ</b><p>{c.organization_name||[c.first_name,c.last_name].filter(Boolean).join(" ")}</p></div><div><b>เลขประจำตัวผู้เสียภาษี</b><p>{c.tax_id||"-"}</p></div><div><b>สาขา</b><p>{c.branch_name||c.branch_no||"-"}</p></div></div>
 <form action={saveContact} className="form-grid">
  <label>โทรศัพท์หลัก<input name="phone" defaultValue={c.phone||""}/></label>
  <label>โทรศัพท์สำรอง<input name="phone_secondary" defaultValue={c.phone_secondary||""}/></label>
  <label>อีเมล<input name="email" type="email" defaultValue={c.email||""}/></label>
  <label style={{gridColumn:"1/-1"}}>หมายเหตุ<textarea name="notes" defaultValue={c.notes||""}/></label>
  <div><button className="btn primary">บันทึกข้อมูลติดต่อ</button></div>
 </form></section></CustomerShell>
}
