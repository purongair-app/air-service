import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";
import { markRead } from "@/app/notifications/actions";

export default async function PortalNotifications(){
 const m=await getCustomerMembership(); if(!m)return null; const supabase=await createClient();
 const {data=[]}=await supabase.from("notifications").select("*").eq("customer_id",m.customer_id).order("created_at",{ascending:false}).limit(100);
 return <CustomerShell><h1 className="page-title">การแจ้งเตือน</h1><div className="grid">
 {data.map((n:any)=><article className="card" key={n.id}><b>{n.title}</b><p>{n.body}</p><div className="actions">{n.action_url&&<a className="btn light" href={n.action_url}>เปิด</a>}{n.status!=="read"&&<form action={markRead}><input type="hidden" name="id" value={n.id}/><button className="btn primary">อ่านแล้ว</button></form>}</div></article>)}
 {!data.length&&<div className="card empty">ยังไม่มีการแจ้งเตือน</div>}</div></CustomerShell>
}
