import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";

export default async function PortalWht(){
 const m=await getCustomerMembership(); if(!m)return null; const supabase=await createClient();
 const {data=[]}=await supabase.from("withholding_certificates")
  .select("id,certificate_no,certificate_date,income_type,gross_amount,withholding_rate,withholding_amount,archive_path")
  .eq("customer_id",m.customer_id).order("certificate_date",{ascending:false});
 return <CustomerShell><h1 className="page-title">หัก ณ ที่จ่าย</h1>
  <div className="table-wrap"><table><thead><tr><th>เลขที่</th><th>วันที่</th><th>ประเภท</th><th>ฐาน</th><th>หัก</th><th>PDF</th></tr></thead><tbody>
   {data.map((x:any)=><tr key={x.id}><td>{x.certificate_no}</td><td>{x.certificate_date}</td><td>{x.income_type||"-"}</td><td>{Number(x.gross_amount||0).toLocaleString()}</td><td>{Number(x.withholding_amount||0).toLocaleString()}</td><td>{x.archive_path?<a className="btn light" target="_blank" href={"/api/private-file?bucket=generated-documents&path="+encodeURIComponent(x.archive_path)}>เปิด</a>:"-"}</td></tr>)}
  </tbody></table>{!data.length&&<div className="empty">ยังไม่มีข้อมูลหัก ณ ที่จ่าย</div>}</div>
 </CustomerShell>
}
