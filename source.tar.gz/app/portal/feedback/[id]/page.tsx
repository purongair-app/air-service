import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { submitFeedback } from "../actions";

export default async function FeedbackDetail({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const supabase=await createClient();
 const {data:s}=await supabase.from("service_surveys").select("*,jobs(work_no,service_name,completed_at)").eq("id",id).maybeSingle();
 if(!s)notFound();
 return <CustomerShell>
  <div className="actions"><div><h1 className="page-title">ประเมิน {s.jobs?.work_no}</h1><p className="muted">{s.jobs?.service_name||"งานบริการ"}</p></div><a className="btn light" href="/portal/feedback">กลับ</a></div>
  {s.status==="submitted"?<section className="card"><h3>ขอบคุณสำหรับความคิดเห็น</h3><p>บริการ {s.service_rating}/5 · ทีมช่าง {s.technician_rating}/5 · แนะนำต่อ {s.nps_score}/10</p><p>{s.comment||""}</p></section>:
  <section className="card"><form action={submitFeedback} className="form-grid">
   <input type="hidden" name="survey_id" value={s.id}/>
   <label>คะแนนบริการ (1–5)<input type="number" min="1" max="5" name="service_rating" required/></label>
   <label>คะแนนทีมช่าง (1–5)<input type="number" min="1" max="5" name="technician_rating" required/></label>
   <label>มีโอกาสแนะนำ AIRFRIEND ให้คนรู้จักแค่ไหน? (0–10)<input type="number" min="0" max="10" name="nps_score" required/></label>
   <label>ปัญหาได้รับการแก้ไขหรือไม่?<select name="issue_resolved" defaultValue="yes"><option value="yes">แก้ไขแล้ว</option><option value="no">ยังไม่เรียบร้อย</option></select></label>
   <div style={{gridColumn:"1/-1"}}><b>สิ่งที่พบ</b><div className="actions">
    {["ตรงเวลา","สุภาพ","งานเรียบร้อย","อธิบายชัดเจน","สะอาด","ต้องปรับปรุง"].map(t=><label key={t}><span><input type="checkbox" name="tags" value={t}/> {t}</span></label>)}
   </div></div>
   <label style={{gridColumn:"1/-1"}}>ความคิดเห็นเพิ่มเติม<textarea name="comment"/></label>
   <div><button className="btn primary">ส่งแบบประเมิน</button></div>
  </form></section>}
 </CustomerShell>
}
