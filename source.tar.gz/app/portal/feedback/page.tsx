import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";

export default async function Feedback(){
 const m=await getCustomerMembership(); if(!m)return null; const supabase=await createClient();
 const {data=[]}=await supabase.from("service_surveys")
  .select("*,jobs(work_no,service_name,completed_at)")
  .eq("customer_id",m.customer_id).order("created_at",{ascending:false});
 return <CustomerShell>
  <h1 className="page-title">ประเมินบริการ</h1>
  <div className="grid">{data.map((s:any)=><a className="card" href={"/portal/feedback/"+s.id} key={s.id}>
   <div className="actions"><b>{s.jobs?.work_no||"-"}</b><span className="badge">{s.status}</span></div>
   <h3>{s.jobs?.service_name||"งานบริการ"}</h3>
   <div className="muted">{s.jobs?.completed_at?new Date(s.jobs.completed_at).toLocaleString("th-TH"):"-"}</div>
   {s.status==="submitted"&&<div>คะแนนบริการ {s.service_rating}/5 · NPS {s.nps_score}/10</div>}
  </a>)}{!data.length&&<div className="card empty">ยังไม่มีแบบประเมิน</div>}</div>
 </CustomerShell>
}
