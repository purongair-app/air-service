"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function submitFeedback(formData:FormData){
 const supabase=await createClient();
 const surveyId=String(formData.get("survey_id")||"");
 const tags=formData.getAll("tags").map(String).filter(Boolean).slice(0,8);
 const {error}=await supabase.rpc("customer_submit_service_feedback",{
  p_survey:surveyId,
  p_service_rating:Number(formData.get("service_rating")||0),
  p_technician_rating:Number(formData.get("technician_rating")||0),
  p_nps_score:Number(formData.get("nps_score")||0),
  p_issue_resolved:formData.get("issue_resolved")==="yes",
  p_comment:String(formData.get("comment")||""),
  p_tags:tags
 });
 if(error)throw new Error(error.message);
 revalidatePath("/portal/feedback");
 redirect("/portal/feedback");
}
