import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";

export default async function PortalJob({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const supabase=await createClient();
 const [{data:j},{data:timeline=[]},{data:eq=[]}] = await Promise.all([
  supabase.from("jobs").select("*").eq("id",id).maybeSingle(),
  supabase.from("job_timeline").select("detail,actor_name,occurred_at").eq("job_id",id).order("occurred_at"),
  supabase.from("job_equipment").select("customer_equipment(equipment_no,brand,model,btu,install_location)").eq("job_id",id)
 ]);
 if(!j)notFound();
 return <CustomerShell>
  <h1 className="page-title">{j.work_no}</h1><p className="muted">{j.service_name}</p>
  <div className="grid">
   <section className="card"><b>นัดหมาย</b><p>{j.appointment_date||"-"} {j.appointment_time_label||""}</p><b>สถานที่</b><p>{j.address_snapshot||"-"}</p><b>รายละเอียด</b><p>{j.note||"-"}</p></section>
   <section className="card"><h3>เครื่องที่ให้บริการ</h3>{eq.map((x:any,i:number)=>{const e=x.customer_equipment||{};return <div className="badge" key={i}>{e.equipment_no||"-"} · {e.brand||"-"} {e.model||""} · {e.btu||"-"} BTU · {e.install_location||"-"}</div>})}{!eq.length&&<div className="muted">ไม่ได้ระบุเครื่อง</div>}</section>
   <section className="card"><h3>ความคืบหน้า</h3><div className="grid">{timeline.map((t:any,i:number)=><div key={i} style={{borderBottom:"1px solid #e5e7eb",paddingBottom:10}}><div>{t.detail}</div><small className="muted">{new Date(t.occurred_at).toLocaleString("th-TH")}</small></div>)}</div></section>
  </div>
 </CustomerShell>
}
