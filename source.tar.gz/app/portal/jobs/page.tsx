import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";

const label:any={new:"รับงานใหม่",awaiting_confirmation:"รอยืนยัน",scheduled:"นัดหมายแล้ว",assigned:"มอบหมายช่างแล้ว",traveling:"ช่างกำลังเดินทาง",in_progress:"กำลังดำเนินงาน",waiting_parts:"รออะไหล่",technician_submitted:"ช่างส่งงานแล้ว",under_review:"รอตรวจสอบ",completed:"เสร็จสิ้น",cancelled:"ยกเลิก"};

export default async function PortalJobs(){
 const m=await getCustomerMembership(); const supabase=await createClient();
 const {data=[]}=m?await supabase.from("jobs")
  .select("id,work_no,service_name,appointment_date,appointment_time_label,status,completed_at")
  .eq("customer_id",m.customer_id).order("created_at",{ascending:false}):{data:[]};
 return <CustomerShell>
  <h1 className="page-title">งานบริการ</h1>
  <div className="grid">{data.map((j:any)=><a href={"/portal/jobs/"+j.id} key={j.id} className="card">
    <div className="actions"><b>{j.work_no}</b><span className="badge">{label[j.status]||j.status}</span></div>
    <h3>{j.service_name}</h3>
    <div className="muted">{j.appointment_date||"-"} {j.appointment_time_label||""}</div>
  </a>)}{!data.length&&<div className="card empty">ยังไม่มีประวัติงาน</div>}</div>
 </CustomerShell>
}
