import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";

export default async function Contracts(){
 const m=await getCustomerMembership(); const supabase=await createClient();
 const {data=[]}=m?await supabase.from("service_contracts").select("*").eq("customer_id",m.customer_id).order("created_at",{ascending:false}):{data:[]};
 return <CustomerShell><h1 className="page-title">สัญญาบริการ</h1>
 <div className="grid">{data.map((x:any)=><div className="card" key={x.id}><div className="actions"><b>{x.contract_no||"-"}</b><span className="badge">{x.status||"-"}</span></div><h3>{x.package_name}</h3><div>ใช้แล้ว {x.used_count}/{x.service_count} ครั้ง</div><div>สัญญา {x.start_date||"-"} ถึง {x.end_date||"-"}</div><div>บริการถัดไป {x.next_service_date||"-"}</div></div>)}
 {!data.length&&<div className="card empty">ยังไม่มีสัญญาบริการ</div>}</div></CustomerShell>
}
