import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";

export default async function Documents(){
 const m=await getCustomerMembership(); const supabase=await createClient();
 const {data=[]}=m?await supabase.from("sales_documents")
  .select("id,document_no,document_type,document_date,total,status,archive_path,archive_version")
  .eq("customer_id",m.customer_id).order("created_at",{ascending:false}):{data:[]};
 return <CustomerShell><h1 className="page-title">เอกสารของฉัน</h1>
 <div className="table-wrap"><table><thead><tr><th>เลขเอกสาร</th><th>ประเภท</th><th>วันที่</th><th>ยอด</th><th>สถานะ</th></tr></thead><tbody>
 {data.map((d:any)=><tr key={d.id}><td><b>{d.document_no}</b>{d.archive_path&&<div><a className="btn light" target="_blank" href={"/api/private-file?bucket=generated-documents&path="+encodeURIComponent(d.archive_path)}>PDF v{d.archive_version}</a></div>}</td><td>{d.document_type}</td><td>{d.document_date}</td><td>{Number(d.total||0).toLocaleString()}</td><td>{d.status}</td></tr>)}
 </tbody></table>{!data.length&&<div className="empty">ยังไม่มีเอกสาร</div>}</div></CustomerShell>
}
