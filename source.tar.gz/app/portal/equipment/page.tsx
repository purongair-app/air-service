import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";

export default async function Equipment(){
 const m=await getCustomerMembership(); const supabase=await createClient();
 const {data=[]}=m?await supabase.from("customer_equipment").select("*").eq("customer_id",m.customer_id).order("created_at"):{data:[]};
 return <CustomerShell><h1 className="page-title">เครื่องแอร์ของฉัน</h1>
 <div className="grid">{data.map((e:any)=><div className="card" key={e.id}><h3>{e.brand||"-"} {e.model||""}</h3><div>{e.btu||"-"} BTU · {e.product_type||"-"}</div><div className="muted">{e.install_location||"-"}</div><p>S/N Indoor: {e.indoor_serial||"-"}<br/>S/N Outdoor: {e.outdoor_serial||"-"}</p></div>)}
 {!data.length&&<div className="card empty">ยังไม่มีทะเบียนเครื่อง</div>}</div></CustomerShell>
}
