import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";

export default async function Warranty(){
 const m=await getCustomerMembership(); const supabase=await createClient();
 const {data=[]}=m?await supabase.from("warranties").select("*,customer_equipment(brand,model,equipment_no)").eq("customer_id",m.customer_id).order("warranty_end"):{data:[]};
 return <CustomerShell><h1 className="page-title">รับประกัน / PM</h1>
 <div className="grid">{data.map((x:any)=><div className="card" key={x.id}><b>{x.warranty_no||"-"}</b><h3>{x.customer_equipment?.brand||x.equipment||"-"} {x.customer_equipment?.model||""}</h3><div>ประกันถึง: {x.warranty_end||"-"}</div><div>PM ถัดไป: {x.next_pm||"-"}</div><p className="muted">{x.note||""}</p></div>)}
 {!data.length&&<div className="card empty">ยังไม่มีข้อมูลรับประกันหรือ PM</div>}</div></CustomerShell>
}
