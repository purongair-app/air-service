import CustomerShell from "@/components/customer-shell";
import { createClient } from "@/lib/supabase/server";
import { getCustomerMembership } from "@/lib/customer";

export default async function Portal(){
 const m=await getCustomerMembership(); const supabase=await createClient();
 if(!m)return <main className="login-page"><div className="login-card"><h1>ยังไม่เชื่อมบัญชีลูกค้า</h1><p className="muted">กรุณาติดต่อร้านเพื่อเชื่อมบัญชีของคุณ</p></div></main>;

 const [{data:customer},{count:jobs},{count:equipment},{data:docs=[]},{data:warranties=[]}]=await Promise.all([
  supabase.from("customers").select("*").eq("id",m.customer_id).maybeSingle(),
  supabase.from("jobs").select("*",{count:"exact",head:true}).eq("customer_id",m.customer_id),
  supabase.from("customer_equipment").select("*",{count:"exact",head:true}).eq("customer_id",m.customer_id),
  supabase.from("sales_documents").select("status,total").eq("customer_id",m.customer_id),
  supabase.from("warranties").select("warranty_end,next_pm").eq("customer_id",m.customer_id)
 ]);
 const outstanding=(docs||[]).filter((d:any)=>!["paid","cancelled"].includes(d.status)).reduce((s:number,d:any)=>s+Number(d.total||0),0);
 const nextPm=(warranties||[]).map((x:any)=>x.next_pm).filter(Boolean).sort()[0];

 return <CustomerShell>
  <h1 className="page-title">สวัสดี {customer?.organization_name||[customer?.first_name,customer?.last_name].filter(Boolean).join(" ")}</h1>
  <p className="muted">ติดตามงานและข้อมูลบริการของคุณ</p>
  <section className="grid cards">
   <div className="card"><div className="muted">งานบริการ</div><div className="kpi">{jobs||0}</div></div>
   <div className="card"><div className="muted">เครื่องแอร์</div><div className="kpi">{equipment||0}</div></div>
   <div className="card"><div className="muted">ยอดเอกสารค้าง</div><div className="kpi">{outstanding.toLocaleString()}</div></div>
   <div className="card"><div className="muted">PM ถัดไป</div><div className="kpi" style={{fontSize:20}}>{nextPm||"-"}</div></div>
  </section>
 </CustomerShell>
}
