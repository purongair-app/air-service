import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { markRead,savePreferences } from "./actions";

export default async function Notifications(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 const [{data:items=[]},{data:prefs}]=await Promise.all([
   supabase.from("notifications").select("*").eq("user_id",user!.id).order("created_at",{ascending:false}).limit(100),
   supabase.from("notification_preferences").select("*").eq("organization_id",m.organization_id).eq("user_id",user!.id).maybeSingle()
 ]);
 return <AppShell>
  <h1 className="page-title">การแจ้งเตือน</h1>
  <div className="grid">
   <section className="card"><h3>ตั้งค่า</h3><form action={savePreferences} className="form-grid">
    <label><span><input type="checkbox" name="in_app" defaultChecked={prefs?.in_app??true}/> ในระบบ</span></label>
    <label><span><input type="checkbox" name="email" defaultChecked={prefs?.email??true}/> Email</span></label>
    <label><span><input type="checkbox" name="line" defaultChecked={prefs?.line??false}/> LINE</span></label>
    <label>LINE User ID<input name="line_user_id" defaultValue={prefs?.line_user_id||""}/></label>
    <label>เตือนนัดล่วงหน้า (ชม.)<input type="number" name="appointment_hours_before" defaultValue={prefs?.appointment_hours_before||24}/></label>
    <label>เตือน PM ล่วงหน้า (วัน)<input type="number" name="pm_days_before" defaultValue={prefs?.pm_days_before||7}/></label>
    <label>เตือนชำระเงิน (วัน)<input type="number" name="payment_days_before" defaultValue={prefs?.payment_days_before||3}/></label>
    <div><button className="btn primary">บันทึก</button></div>
   </form></section>
   <section className="grid">{items.map((n:any)=><article className="card" key={n.id}>
     <div className="actions"><b>{n.title}</b><span className="badge">{n.kind}</span></div>
     <p>{n.body}</p>
     <div className="actions">{n.action_url&&<a className="btn light" href={n.action_url}>เปิด</a>}{n.status!=="read"&&<form action={markRead}><input type="hidden" name="id" value={n.id}/><button className="btn primary">อ่านแล้ว</button></form>}</div>
   </article>)}{!items.length&&<div className="card empty">ยังไม่มีการแจ้งเตือน</div>}</section>
  </div>
 </AppShell>
}
