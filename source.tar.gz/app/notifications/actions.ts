"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function markRead(formData:FormData){
 const supabase=await createClient();
 const id=String(formData.get("id")||"");
 const {error}=await supabase.rpc("mark_my_notification_read",{p_notification:id});
 if(error)throw new Error(error.message);
 revalidatePath("/notifications");
 revalidatePath("/portal/notifications");
}

export async function savePreferences(formData:FormData){
 const m=await getCurrentMembership(); if(!m)throw new Error("ไม่พบ membership");
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
 const {error}=await supabase.from("notification_preferences").upsert({
   organization_id:m.organization_id,user_id:user!.id,
   in_app:formData.get("in_app")==="on",
   email:formData.get("email")==="on",
   line:formData.get("line")==="on",
   line_user_id:String(formData.get("line_user_id")||"")||null,
   appointment_hours_before:Number(formData.get("appointment_hours_before")||24),
   pm_days_before:Number(formData.get("pm_days_before")||7),
   payment_days_before:Number(formData.get("payment_days_before")||3)
 },{onConflict:"organization_id,user_id"});
 if(error)throw new Error(error.message);
 revalidatePath("/notifications");
}
