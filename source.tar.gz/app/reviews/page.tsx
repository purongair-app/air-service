import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { reviewJob } from "./actions";

export default async function ReviewsPage(){
 const member=await getCurrentMembership(); const supabase=await createClient(); const org=member?.organization_id;
 const {data:jobs=[]}=org?await supabase.from("jobs")
   .select("id,work_no,customer_name_snapshot,service_name,status,technician_submitted_at")
   .eq("organization_id",org).in("status",["technician_submitted","under_review"])
   .order("technician_submitted_at",{ascending:true}):{data:[]};

 return <AppShell>
  <h1 className="page-title">ตรวจรับงานช่าง</h1>
  <p className="muted">ตรวจข้อมูล รูปหน้างาน และผลตรวจซ่อมก่อนปิดงาน</p>
  <div className="grid">
   {jobs.map((j:any)=><article className="card" key={j.id}>
    <h3>{j.work_no} · {j.customer_name_snapshot}</h3>
    <p>{j.service_name}</p>
    <form action={reviewJob} className="form">
      <input type="hidden" name="job_id" value={j.id}/>
      <div className="form-grid">
        <label><input type="checkbox" name="check_work"/> ตรวจข้อมูลงาน</label>
        <label><input type="checkbox" name="check_inspection"/> ตรวจผลตรวจซ่อม</label>
        <label><input type="checkbox" name="check_photos"/> ตรวจรูปภาพหน้างาน</label>
        <label><input type="checkbox" name="check_documents"/> ตรวจเอกสารประกอบ</label>
      </div>
      <label>สรุปผลงาน<textarea name="summary"/></label>
      <label>หมายเหตุแอดมิน<textarea name="admin_note"/></label>
      <div className="actions">
        <button className="btn primary" name="review_action" value="approve">อนุมัติ / ปิดงาน</button>
        <button className="btn danger" name="review_action" value="revision">ส่งกลับแก้ไข</button>
      </div>
    </form>
   </article>)}
   {!jobs.length&&<div className="card empty">ยังไม่มีงานรอตรวจรับ</div>}
  </div>
 </AppShell>
}
