"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export async function reviewJob(formData:FormData){
 const member=await getCurrentMembership(); if(!member) throw new Error("ไม่พบองค์กร");
 if(!["owner","manager","admin"].includes(member.role)) throw new Error("ไม่มีสิทธิ์ตรวจรับงาน");
 const supabase=await createClient();
 const jobId=String(formData.get("job_id")||"");
 const action=String(formData.get("review_action")||"");
 const note=String(formData.get("admin_note")||"").trim();
 const {data:{user}}=await supabase.auth.getUser();

 const {data:existing}=await supabase.from("technician_reviews").select("id").eq("job_id",jobId).maybeSingle();
 const payload={
   organization_id:member.organization_id,job_id:jobId,
   status:action==="approve"?"approved":"revision",
   check_work:formData.get("check_work")==="on",
   check_inspection:formData.get("check_inspection")==="on",
   check_photos:formData.get("check_photos")==="on",
   check_documents:formData.get("check_documents")==="on",
   summary:String(formData.get("summary")||""),
   admin_note:note,
   reviewer_user_id:user?.id,
   reviewed_at:new Date().toISOString()
 };
 if(action==="approve" && (!payload.check_work||!payload.check_inspection||!payload.check_photos||!payload.check_documents))
   throw new Error("กรุณาตรวจสอบรายการให้ครบก่อนอนุมัติ");
 if(action==="revision" && !note) throw new Error("กรุณาระบุสิ่งที่ต้องแก้ไข");

 if(existing?.id){
   const {error}=await supabase.from("technician_reviews").update(payload).eq("id",existing.id);
   if(error) throw new Error(error.message);
 } else {
   const {error}=await supabase.from("technician_reviews").insert(payload);
   if(error) throw new Error(error.message);
 }

 const nextStatus=action==="approve"?"completed":"in_progress";
 const patch:any={status:nextStatus};
 if(action==="approve") patch.completed_at=new Date().toISOString();
 await supabase.from("jobs").update(patch).eq("id",jobId);
 await supabase.from("job_timeline").insert({
   organization_id:member.organization_id,job_id:jobId,status:nextStatus,
   detail:action==="approve"?"แอดมินตรวจรับและรับรองสรุปงานแล้ว":`แอดมินส่งกลับให้ทีมช่างแก้ไข: ${note}`,
   actor_user_id:user?.id,actor_name:user?.email||"แอดมิน",occurred_at:new Date().toISOString()
 });
 revalidatePath("/reviews");
 revalidatePath("/technician");
}
