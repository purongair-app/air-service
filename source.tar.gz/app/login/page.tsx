"use client";
import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState("");

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true); setError("");
    const form = new FormData(e.currentTarget);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({
      email: String(form.get("email") || ""),
      password: String(form.get("password") || "")
    });
    if(error){ setError(error.message); setLoading(false); return; }
    window.location.href="/auth/continue";
  }

  return <main className="login-page">
    <section className="login-card">
      <h1>AIRFRIEND SERVICE</h1>
      <p className="muted">ระบบบริหารธุรกิจแอร์</p>
      <form className="form" onSubmit={submit}>
        <label>อีเมล<input name="email" type="email" required /></label>
        <label>รหัสผ่าน<input name="password" type="password" required /></label>
        {error && <div style={{color:"#c4372c"}}>{error}</div>}
        <button className="btn primary" disabled={loading}>{loading?"กำลังเข้าสู่ระบบ...":"เข้าสู่ระบบ"}</button>
      </form>
    </section>
  </main>
}
