import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";
import { syncCollections,logCollectionEvent } from "./actions";

export default async function Collections(){
 const m=await getCurrentMembership(); if(!m)return null; const supabase=await createClient();
 const [{data:aging=[]},{data:cases=[]}] = await Promise.all([
   supabase.from("accounts_receivable_aging").select("*").eq("organization_id",m.organization_id)
     .gt("balance",0).order("days_overdue",{ascending:false}),
   supabase.from("collection_cases").select("*,collection_events(*)").eq("organization_id",m.organization_id)
     .order("updated_at",{ascending:false})
 ]);
 const totals=(aging as any[]).reduce((a:any,x:any)=>{
   a.total+=Number(x.balance||0); a[x.aging_bucket]=(a[x.aging_bucket]||0)+Number(x.balance||0); return a;
 },{total:0,current:0,"1-30":0,"31-60":0,"61-90":0,"90+":0});
 const caseMap=new Map((cases as any[]).map((x:any)=>[x.sales_document_id,x]));

 return <AppShell>
  <div className="actions"><div><h1 className="page-title">ลูกหนี้ / ติดตามชำระ</h1><p className="muted">A/R Aging และประวัติติดตามหนี้</p></div>
   <form action={syncCollections}><button className="btn primary">Sync ลูกหนี้เกินกำหนด</button></form>
  </div>
  <section className="grid cards">
   <div className="card"><div className="muted">คงค้างรวม</div><div className="kpi">{totals.total.toLocaleString()}</div></div>
   <div className="card"><div className="muted">ยังไม่เกินกำหนด</div><div className="kpi">{totals.current.toLocaleString()}</div></div>
   <div className="card"><div className="muted">1–30 วัน</div><div className="kpi">{totals["1-30"].toLocaleString()}</div></div>
   <div className="card"><div className="muted">31–60 วัน</div><div className="kpi">{totals["31-60"].toLocaleString()}</div></div>
   <div className="card"><div className="muted">61–90 วัน</div><div className="kpi">{totals["61-90"].toLocaleString()}</div></div>
   <div className="card"><div className="muted">90+ วัน</div><div className="kpi">{totals["90+"].toLocaleString()}</div></div>
  </section>
  <div className="grid" style={{marginTop:16}}>
   {aging.map((a:any)=>{
    const cc:any=caseMap.get(a.document_id);
    return <article className="card" key={a.document_id}>
     <div className="actions"><div><b>{a.document_no}</b><div>{a.customer_name}</div></div><span className="badge">{a.aging_bucket}</span></div>
     <div className="form-grid">
      <div><b>ยอดคงเหลือ</b><p>{Number(a.balance||0).toLocaleString()} บาท</p></div>
      <div><b>ครบกำหนด</b><p>{a.due_date||"-"}</p></div>
      <div><b>เกินกำหนด</b><p>{a.days_overdue} วัน</p></div>
      <div><b>สถานะติดตาม</b><p>{cc?.status||"-"}</p></div>
     </div>
     {cc&&<form action={logCollectionEvent} className="form-grid">
       <input type="hidden" name="case_id" value={cc.id}/>
       <label>ช่องทาง<select name="channel"><option value="phone">โทรศัพท์</option><option value="line">LINE</option><option value="email">Email</option><option value="visit">เข้าพบ</option></select></label>
       <label>สถานะ<select name="status"><option value="contacted">ติดต่อแล้ว</option><option value="promised">นัดชำระ</option><option value="disputed">มีข้อโต้แย้ง</option><option value="closed">ปิดเคส</option></select></label>
       <label>ผลการติดต่อ<input name="outcome"/></label>
       <label>นัดชำระวันที่<input type="date" name="promise_date"/></label>
       <label>ยอดที่นัดชำระ<input type="number" step="0.01" name="promise_amount"/></label>
       <label>ติดตามครั้งถัดไป<input type="date" name="next_contact_date"/></label>
       <label style={{gridColumn:"1/-1"}}>รายละเอียด<textarea name="detail"/></label>
       <div><button className="btn light">บันทึกการติดตาม</button></div>
     </form>}
    </article>
   })}
   {!aging.length&&<div className="card empty">ไม่มีลูกหนี้คงค้าง</div>}
  </div>
 </AppShell>
}
