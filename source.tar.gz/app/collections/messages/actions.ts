"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

function applyTemplate(body:string,vars:Record<string,string>){
 return body.replace(/\{\{(\w+)\}\}/g,(_,k)=>vars[k]??"");
}

export async function seedTemplates(){
 const m=await getCurrentMembership(); if(!m)throw new Error("ไม่มี membership");
 const supabase=await createClient();
 const {error}=await supabase.rpc("seed_collection_templates",{p_org:m.organization_id});
 if(error)throw new Error(error.message);
 revalidatePath("/collections/messages");
}

export async function createDraft(formData:FormData){
 const m=await getCurrentMembership(); if(!m)throw new Error("ไม่มี membership");
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
 const caseId=String(formData.get("case_id")||"");
 const templateId=String(formData.get("template_id")||"");
 const {data:cc}=await supabase.from("collection_cases").select("*,customers(*),sales_documents(*)").eq("id",caseId).single();
 const {data:t}=await supabase.from("collection_message_templates").select("*").eq("id",templateId).single();
 if(!cc||!t)throw new Error("ไม่พบข้อมูล");

 const a:any=await supabase.from("accounts_receivable_aging").select("*").eq("document_id",cc.sales_document_id).maybeSingle();
 const aging=a.data;
 const vars={
  customer_name:aging?.customer_name||"",
  document_no:aging?.document_no||"",
  balance:Number(aging?.balance||0).toLocaleString("th-TH"),
  due_date:aging?.due_date||"-",
  days_overdue:String(aging?.days_overdue||0)
 };
 const recipient=t.channel==="email"?cc.customers?.email:cc.customers?.line_user_id;
 const {error}=await supabase.from("collection_message_drafts").insert({
  organization_id:m.organization_id,collection_case_id:cc.id,customer_id:cc.customer_id,
  sales_document_id:cc.sales_document_id,channel:t.channel,recipient,
  subject:t.subject_template?applyTemplate(t.subject_template,vars):null,
  body:applyTemplate(t.body_template,vars),status:"draft",created_by:user?.id
 });
 if(error)throw new Error(error.message);
 revalidatePath("/collections/messages");
}

export async function approveDraft(formData:FormData){
 const m=await getCurrentMembership(); if(!m)throw new Error("ไม่มี membership");
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser();
 const id=String(formData.get("id")||"");
 const {data:d}=await supabase.from("collection_message_drafts").select("*").eq("id",id).single();
 if(!d)throw new Error("ไม่พบ draft");
 if(!d.recipient)throw new Error("ไม่มีผู้รับสำหรับช่องทางนี้");

 const {data:n,error}=await supabase.from("notifications").insert({
  organization_id:m.organization_id,customer_id:d.customer_id,kind:"payment_due",
  title:d.subject||"แจ้งยอดค้างชำระ",body:d.body,action_url:"/portal/documents",
  channel:d.channel,status:"pending",scheduled_for:new Date().toISOString(),
  dedupe_key:`collection-draft:${d.id}`,
  metadata:d.channel==="email"?{email:d.recipient}:{line_user_id:d.recipient}
 }).select("id").single();
 if(error)throw new Error(error.message);

 await supabase.from("collection_message_drafts").update({
  status:"queued",approved_by:user?.id,approved_at:new Date().toISOString(),notification_id:n.id
 }).eq("id",id);
 revalidatePath("/collections/messages");
}
