import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const allowedBuckets=new Set([
 "job-photos","customer-equipment","employee-media","business-documents",
 "document-branding","generated-documents"
]);

export async function GET(req:NextRequest){
 const bucket=req.nextUrl.searchParams.get("bucket")||"";
 const path=req.nextUrl.searchParams.get("path")||"";
 if(!allowedBuckets.has(bucket)||!path)return new NextResponse("Bad request",{status:400});

 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user)return new NextResponse("Unauthorized",{status:401});

 // First require that storage RLS allows SELECT on this exact object.
 // list() is used only to authorize exact path metadata; signed URL remains short-lived.
 const slash=path.lastIndexOf("/");
 const folder=slash>=0?path.slice(0,slash):"";
 const name=slash>=0?path.slice(slash+1):path;
 const {data:list,error:listError}=await supabase.storage.from(bucket).list(folder,{
   search:name,limit:10
 });
 if(listError)return new NextResponse("Forbidden",{status:403});
 if(!(list||[]).some(x=>x.name===name))return new NextResponse("Not found",{status:404});

 const {data,error}=await supabase.storage.from(bucket).createSignedUrl(path,60);
 if(error||!data?.signedUrl)return new NextResponse("Cannot sign file",{status:403});
 return NextResponse.redirect(data.signedUrl,302);
}
