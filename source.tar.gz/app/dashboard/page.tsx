import AppShell from "@/components/app-shell";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMembership } from "@/lib/org";

export default async function Dashboard() {
  const member = await getCurrentMembership();
  const supabase = await createClient();
  const org = member?.organization_id;

  const [customers,jobs,openJobs,inventory] = org ? await Promise.all([
    supabase.from("customers").select("*",{count:"exact",head:true}).eq("organization_id",org),
    supabase.from("jobs").select("*",{count:"exact",head:true}).eq("organization_id",org),
    supabase.from("jobs").select("*",{count:"exact",head:true}).eq("organization_id",org).not("status","in","(completed,cancelled)"),
    supabase.from("inventory_items").select("quantity,reorder_point").eq("organization_id",org)
  ]) : [{count:0},{count:0},{count:0},{data:[]}];

  const lowStock=(inventory.data||[]).filter((x:any)=>Number(x.quantity)<=Number(x.reorder_point)).length;

  return <AppShell>
    <h1 className="page-title">แดชบอร์ด</h1>
    <p className="muted">ภาพรวมการดำเนินงานของร้าน</p>
    <section className="grid cards">
      <div className="card"><div className="muted">ลูกค้าทั้งหมด</div><div className="kpi">{customers.count||0}</div></div>
      <div className="card"><div className="muted">ใบงานทั้งหมด</div><div className="kpi">{jobs.count||0}</div></div>
      <div className="card"><div className="muted">งานที่ยังเปิดอยู่</div><div className="kpi">{openJobs.count||0}</div></div>
      <div className="card"><div className="muted">สินค้าใกล้หมด</div><div className="kpi">{lowStock}</div></div>
    </section>
  </AppShell>
}
