import { test, expect } from "@playwright/test";

const accounts=[
 {name:"owner",email:process.env.E2E_OWNER_EMAIL||"owner@airfriend.local",password:process.env.E2E_OWNER_PASSWORD||"Owner12345!",path:"/dashboard"},
 {name:"technician",email:process.env.E2E_TECH_EMAIL||"tech@airfriend.local",password:process.env.E2E_TECH_PASSWORD||"Tech12345!",path:"/dashboard"},
 {name:"customer",email:process.env.E2E_CUSTOMER_EMAIL||"customer@airfriend.local",password:process.env.E2E_CUSTOMER_PASSWORD||"Customer12345!",path:"/portal"}
];

for(const a of accounts){
 test(`${a.name} login routes correctly`,async({page})=>{
  await page.goto("/login");
  await page.getByLabel("อีเมล").fill(a.email);
  await page.getByLabel("รหัสผ่าน").fill(a.password);
  await page.getByRole("button",{name:"เข้าสู่ระบบ"}).click();
  await page.waitForURL(url=>url.pathname.startsWith(a.path),{timeout:15000});
  expect(page.url()).toContain(a.path);
 });
}

test("customer cannot remain on staff dashboard",async({page})=>{
 await page.goto("/login");
 await page.getByLabel("อีเมล").fill(process.env.E2E_CUSTOMER_EMAIL||"customer@airfriend.local");
 await page.getByLabel("รหัสผ่าน").fill(process.env.E2E_CUSTOMER_PASSWORD||"Customer12345!");
 await page.getByRole("button",{name:"เข้าสู่ระบบ"}).click();
 await page.goto("/dashboard");
 await page.waitForURL(/\/portal/);
});
