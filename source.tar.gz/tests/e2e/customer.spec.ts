import { test, expect } from "@playwright/test";

test.beforeEach(async({page})=>{
 await page.goto("/login");
 await page.getByLabel("อีเมล").fill(process.env.E2E_CUSTOMER_EMAIL||"customer@airfriend.local");
 await page.getByLabel("รหัสผ่าน").fill(process.env.E2E_CUSTOMER_PASSWORD||"Customer12345!");
 await page.getByRole("button",{name:"เข้าสู่ระบบ"}).click();
 await page.waitForURL(/\/portal/);
});

test("customer sees own equipment",async({page})=>{
 await page.goto("/portal/equipment");
 await expect(page.getByText("DAIKIN")).toBeVisible();
 await expect(page.getByText("TEST12")).toBeVisible();
});

test("customer sees own service job",async({page})=>{
 await page.goto("/portal/jobs");
 await expect(page.getByText("AF-TEST-001")).toBeVisible();
});
