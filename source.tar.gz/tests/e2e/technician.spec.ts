import { test, expect } from "@playwright/test";

test.beforeEach(async({page})=>{
 await page.goto("/login");
 await page.getByLabel("อีเมล").fill(process.env.E2E_TECH_EMAIL||"tech@airfriend.local");
 await page.getByLabel("รหัสผ่าน").fill(process.env.E2E_TECH_PASSWORD||"Tech12345!");
 await page.getByRole("button",{name:"เข้าสู่ระบบ"}).click();
 await page.waitForURL(/\/dashboard|\/technician/);
});

test("technician sees assigned work",async({page})=>{
 await page.goto("/technician");
 await expect(page.getByText("AF-TEST-001")).toBeVisible();
});

test("technician does not get finance navigation",async({page})=>{
 await page.goto("/dashboard");
 await expect(page.getByRole("link",{name:"การเงิน"})).toHaveCount(0);
});
